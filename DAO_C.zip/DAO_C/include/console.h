/*
 * console.h
 *
 *  Created on: 08 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */

#ifndef CONSOLE_H_
#define CONSOLE_H_
#include <stdint.h>
#include "pt.h"

#ifdef __cplusplus
 extern "C" {
#endif

#define  NUL             0        /* Not to be confused with NULL */
#define  SPACE          32

#define  ASCII_NUL       0               /* Ctrl+@, Null */
#define  ASCII_SOH       1               /* Ctrl+A, Start of Header */
#define  ASCII_ETX       3               /* Ctrl+C, End of Text */
#define  ASCII_EOT       4               /* Ctrl+D, End of Transmission */
#define  ASCII_ACK       6               /* Ctrl+F, Acknowledge */
#define  ASCII_BS        8               /* Ctrl+H, Backspace */
#define  ASCII_HT        9               /* Ctrl+I, Horizontal Tabulation */
#define  ASCII_TAB       9
#define  ASCII_LF       10
#define  ASCII_CR       13
#define  ASCII_DC2      18                /* Ctrl+R, Device Control 2 */
#define  ASCII_NAK      21                /* Ctrl+U, Negative Acknowledge */
#define  ASCII_CAN      24                /* Ctrl+X, Cancel line */
#define  ASCII_ESC      27                /* Ctrl+[, Escape */
#define  ASCII_FS       28                /* Ctrl+\, File Separator */
#define  ASCII_SP       32
#define  ASCII_DEL      127

#define CONSOLE_NEW_LINE        "\n\r"
#define CONSOLE_BACKSPACE       "\b \b"
#define CONSOLE_PROMT_LINE      CONSOLE_NEW_LINE"#"
#define CONSOLE_FUNC_NAME_MAX_LENGTH    (20)
#define CONSOLE_MAX_ARGC        (10)

#define CONSOLE_PUTS(pt, _s) {  pt->s = _s; while(*pt->s != 0){ PT_WAIT_WHILE(pt, pt->putch(*pt->s) == -1);pt->s++;} }


   typedef enum console_state_e {CONSOLE_NONE, CONSOLE_INIT, CONSOLE_PROCESS, CONSOLE_FAIL} console_state_t;
   typedef int (*console_init_fnc)(void);
   typedef int (*console_getchar_fnc)(void);
   typedef int (*console_putchar_fnc)(int);
   typedef struct console_handle_s console_handle_t;

   typedef struct console_cmd_fnc_handle_s {
     console_getchar_fnc        getch;          /// Get a char from line, -1 if empty
     console_putchar_fnc        putch;          /// Put a chat into line, -1 if busy
     const char*                s;
     void*                      p_hnd;          /// Private handle to command's data
     /* Protothreads */
     lc_t                       lc;
   } console_cmd_fnc_handle_t;

   typedef int (*console_cmd_fnc)(console_cmd_fnc_handle_t* pt, int argc, char* argv[]);

   typedef struct console_func_desc_s {
     const char*        name;
     console_cmd_fnc    func;
     const char*        help;
   } console_func_desc_t;

   struct console_handle_s {
     console_state_t            state;
     console_func_desc_t*       func_desc;
     char*                      buffer_in;
     unsigned                   buffer_in_sz;
     /* Driver functions */
     console_init_fnc           init;           /// Initialize
     console_getchar_fnc        getch;          /// Get a char from line, -1 if empty
     console_putchar_fnc        putch;          /// Put a chat into line, -1 if busy
     /* Internal data */
     unsigned                   buffer_in_index;
     const char*                s;

     int                        argc;
     char*                      argv[CONSOLE_MAX_ARGC];
     console_func_desc_t*       child_desc;
     console_cmd_fnc_handle_t   child;
     /* Protothreads */
     lc_t                       lc;
   };

   void console_init(console_handle_t* hnd);
   int console_process(console_handle_t* hnd);
   console_func_desc_t* console_find_function(console_func_desc_t* func_descs, const char* name);

#ifdef __cplusplus
 }
#endif

#endif /* CONSOLE_H_ */
