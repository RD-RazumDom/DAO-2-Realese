#ifndef __MODBUS_TCP_SERVER_H__
#define __MODBUS_TCP_SERVER_H__
#ifdef __cplusplus
 extern "C" {
#endif

#define MODBUS_TCP_PORT         (502)

#define MODBUS_TCP_MAKE_WORD(_data)               (((_data>>8) & 0x00FFU) | (((int)_data & 0x00FFU)<<8))

void modbus_tcp_server_init(uint8_t unit);
extern int config_get_allow_ip(struct ip_addr* ipaddr, unsigned index);

#ifdef __cplusplus
 }
#endif
#endif /* __MODBUS_TCP_SERVER_H__ */
