/**
  ******************************************************************************
  * @file    debug.h 
  * @author  Dmitry Rudakov
  * @brief   Provide API for debug functionality
  ******************************************************************************
 **/ 
#ifndef _DEBUG_H
#define _DEBUG_H
#include <stdio.h>
#include "diag/Trace.h"
#include "stm32f2xx.h"

#ifdef __cplusplus
 extern "C" {
#endif

#ifdef NDEBUG
	#define debug_init()					{}
	#define debug_printf(...)                               {}
        #define debug_puts(...)                                 {}
#else
        #define	debug_init()                                    {}
	#define debug_printf(...)       			{IWDG_ReloadCounter(); trace_printf(__VA_ARGS__);}
        #define debug_puts(...)                                 {IWDG_ReloadCounter(); trace_puts(__VA_ARGS__);};
#endif

#ifdef __cplusplus
 }
#endif

#endif //_DEBUG_H
