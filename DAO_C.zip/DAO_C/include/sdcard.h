/*
 * sdcard.h
 *
 *  Created on: 09 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */

#ifndef SDCARD_H_
#define SDCARD_H_
#include "diskio.h"

#ifdef __cplusplus
 extern "C" {
#endif

extern DSTATUS MMC_disk_initialize(void);
extern DSTATUS MMC_disk_status(void);
extern DRESULT MMC_disk_ioctl(BYTE cmd, char *buff);
extern DRESULT MMC_disk_read(BYTE *buff, DWORD sector, UINT count);
extern DRESULT MMC_disk_write(const BYTE *buff, DWORD sector, UINT count);

extern DWORD get_fattime ();

#ifdef __cplusplus
 }
#endif

#endif /* SDCARD_H_ */
