/*
 * ftp_client.h
 *
 *  Created on: 29 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */

#ifndef FTP_CLIENT_H_
#define FTP_CLIENT_H_

#include <stdint.h>
#include <stdbool.h>
#include "lwip/tcp.h"
#include "pt.h"

#define FTP_SERVER_PORT         (21)

#define FTPC_OK                 (0)
#define FTPC_ERR_MEMORY         (-1)
#define FTPC_ERR_CONNECT        (-2)
#define FTPC_ERR_INVALID_STATE  (-3)
#define FTPC_ERR_AUTHORIZATION  (-4)
#define FTPC_ERR_SETUP          (-5)
#define FTPC_ERR_EXEC           (-6)

#define FTPC_USER_SZ            (20)
#define FTPC_PASS_SZ            (20)

#ifdef __cplusplus
 extern "C" {
#endif

   typedef struct ftpc_config_s {
     struct ip_addr        ip_addr;
     char                  user[FTPC_USER_SZ];
     char                  pass[FTPC_PASS_SZ];
   } ftpc_config_t;

   typedef enum ftpc_state_e { FTPC_IDLE = 0, FTPC_WAIT_CONNECTION, FTPC_CONNECTED, FTPC_TIMEOUT, FTPC_READY,  FTPC_OPEN, /*FTPC_TRANSFERRING,*/ FTPC_ABORT, FTPC_CHANGING_DIR, FTPC_CLOSE, FTPC_NONE } ftpc_state_t;

   typedef struct ftpc_handle_s {
     ftpc_state_t               state;
     uint16_t                   flags;
     err_t                      error;

     struct tcp_pcb*            ctrl_pcb;        /// Pointer on the current tcp_pcb
     struct tcp_pcb*            data_pcb;        /// Pointer on the current tcp_pcb
     struct pbuf*               p_tx;            /// Pointer on pbuf to be transmitted
     struct pbuf*               p_rx;            /// Pointer on pbuf to be received

     int                        timeout;

     ftpc_config_t*             cfg;            /// Pointer to configuration
     char*                      filename;

     /* Protothreads */
     lc_t                       lc;
   } ftpc_handle_t;

   void ftpc_init(ftpc_handle_t* pt, ftpc_config_t* cfg);
   int  ftpc_process(ftpc_handle_t* pt);

   int  ftpc_connect(ftpc_handle_t* pt, struct ip_addr* dest_ip, char* user, char* pass);
   int  ftpc_cwd(ftpc_handle_t* pt, const char* path);
   int  ftpc_retrieve(ftpc_handle_t* pt, char* filename);
   int  ftpc_abort(ftpc_handle_t* pt);
   int  ftpc_data_close(ftpc_handle_t* pt);
   bool ftpc_is_busy(ftpc_handle_t* pt);
   void ftpc_close(ftpc_handle_t* pt);
   int  ftpc_disconnect(ftpc_handle_t* pt);

#ifdef __cplusplus
 }
#endif

#endif /* FTP_CLIENT_H_ */
