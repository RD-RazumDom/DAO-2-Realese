/*
 * media.h
 *
 *  Created on: 22 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */

#ifndef _MEDIA_H_
#define _MEDIA_H_

#include <stdint.h>
#include "pt.h"
#include "pt-sem.h"
#include "drv_vs1002.h"

#define MEDIA_FAIL              (-1)
#define MEDIA_OK                (0)

#define MEDIA_BUFFER_SZ         (512)

#ifdef __cplusplus
 extern "C" {
#endif


   typedef enum media_cmd_e { MEDIA_CMD_STOP = 0, MEDIA_CMD_PLAY, MEDIA_CMD_PAUSE } media_cmd_t;
   typedef enum media_state_e { MEDIA_STOPED = 0, MEDIA_PLAYING, MEDIA_PAUSED, MEDIA_INITIALIZED, MEDIA_FAILURE, MEDIA_NONE} media_state_t;

   typedef struct media_handle_s {
     media_state_t              state;
     uint8_t                    volume;
     uint16_t					bass_control;
     uint8_t                    earspeaker;

     uint32_t                   buffer[MEDIA_BUFFER_SZ / sizeof(uint32_t)];
     uint32_t                   buffer_sz;

     struct pt_sem              buffer_empty;
     struct pt_sem              buffer_full;


     /* Protothreads */
     lc_t                       lc;
     /* */
   } media_handle_t;

   int media_init(media_handle_t* pt);
   int media_process(media_handle_t* pt);
   int media_exec_cmd(media_handle_t* pt, media_cmd_t cmd);
   media_state_t media_get_state(media_handle_t* pt);
   int media_set_volume(media_handle_t* pt, uint8_t volume);
   uint8_t media_get_volume(media_handle_t* pt);
   int media_set_earspeaker(media_handle_t* pt, uint16_t control);
   uint16_t media_get_earspeaker(media_handle_t* pt);

   int media_set_bass_control(media_handle_t* pt, uint16_t control);
   uint16_t media_get_bass_control(media_handle_t* pt);

#ifdef __cplusplus
 }
#endif

#endif /* _MEDIA_H_ */
