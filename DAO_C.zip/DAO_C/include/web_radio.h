/*
 * web_radio.h
 *
 *  Created on: 22 янв. 2015 г.
 *      Author: Dmitry Rudakov
 */

#ifndef _WEB_RADIO_H_
#define _WEB_RADIO_H_
#include <stdint.h>
#include <stdbool.h>
#include "lwip/tcp.h"

struct tcp_pcb* web_radio_connect(struct ip_addr* dest_ip, uint16_t port, const char* url);

#endif //_WEB_RADIO_H_

