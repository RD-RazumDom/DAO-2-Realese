/**
  ******************************************************************************
  * @file    stm32f2x7_eth_conf_template.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    25-April-2011
  * @brief   Configuration file for the STM32F2x7 Ethernet driver.
  *          This file should be copied to the application folder and renamed to
  *          stm32f2x7_eth_conf.h    
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32F2x7_ETH_CONF_H
#define __STM32F2x7_ETH_CONF_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f2xx.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
#define DEVICE_UID_ADDR         ((0x1FFF7A10))
/* MAC ADDRESS: MAC_ADDR0:MAC_ADDR1:MAC_ADDR2:MAC_ADDR3:MAC_ADDR4:MAC_ADDR5 */
#define MAC_ADDR0   2
#define MAC_ADDR1   (((uint8_t*)DEVICE_UID_ADDR)[5])
#define MAC_ADDR2   (((uint8_t*)DEVICE_UID_ADDR)[4])
#define MAC_ADDR3   (((uint8_t*)DEVICE_UID_ADDR)[3])
#define MAC_ADDR4   (((uint8_t*)DEVICE_UID_ADDR)[2])
#define MAC_ADDR5   (((uint8_t*)DEVICE_UID_ADDR)[0])

/*Static IP ADDRESS: IP_ADDR0.IP_ADDR1.IP_ADDR2.IP_ADDR3 */
#define IP_ADDR0   192
#define IP_ADDR1   168
#define IP_ADDR2   0//1
#define IP_ADDR3   200

/*NETMASK*/
#define NETMASK_ADDR0   255
#define NETMASK_ADDR1   255
#define NETMASK_ADDR2   255
#define NETMASK_ADDR3   0

/*Gateway Address*/
#define GW_ADDR0   192
#define GW_ADDR1   168
#define GW_ADDR2   0
#define GW_ADDR3   7

#define USE_DHCP

/* MII and RMII mode selection, for STM322xG-EVAL Board(MB786) RevB ***********/
#define RMII_MODE  // User have to provide the 50 MHz clock by soldering a 50 MHz
                   // oscillator (ref SM7745HEV-50.0M or equivalent) on the U3
                   // footprint located under CN3 and also removing jumper on JP5.
                   // This oscillator is not provided with the board.
                   // For more details, please refer to STM3220G-EVAL evaluation
                   // board User manual (UM1057).


//#define MII_MODE

/* Uncomment the define below to clock the PHY from CPU -  25MHz or 50MHz  */
#define PHY_CLOCK_MCO

//#define PHY_DP83848
#define PHY_LAN8720

#ifndef PHY_ADDRESS
  #define PHY_ADDRESS             (0x00)
  #warning "Using default PHY_ADDRESS - 0"
#endif //#ifndef PHY_ADDRESS

/* Uncomment the line below when using time stamping and/or IPv4 checksum offload */
#define USE_ENHANCED_DMA_DESCRIPTORS

/* Uncomment the line below if you want to use user defined Delay function
   (for precise timing), otherwise default _eth_delay_ function defined within
   the Ethernet driver is used (less precise timing) */
#define USE_Delay

#ifdef USE_Delay
  #include "main.h"                /* Header file where the Delay function prototype is exported */  
  #define _eth_delay_    delay     /* User can provide more timing precise _eth_delay_ function */
   /* PHY Reset delay */
   #define PHY_RESET_DELAY    ((uint32_t)600)
   /* PHY Configuration delay */
   #define PHY_CONFIG_DELAY   ((uint32_t)100)
#else
  #define _eth_delay_    ETH_Delay /* Default _eth_delay_ function with less precise timing */
  /* PHY Reset delay */
  #define PHY_RESET_DELAY    ((uint32_t)0x000FFFFF)
  /* PHY Configuration delay */
  #define PHY_CONFIG_DELAY   ((uint32_t)0x00FFFFFF)
#endif

/* Uncomment the line below to allow custom configuration of the Ethernet driver buffers */    
//#define CUSTOM_DRIVER_BUFFERS_CONFIG

#ifdef  CUSTOM_DRIVER_BUFFERS_CONFIG
/* Redefinition of the Ethernet driver buffers size and count */   
 #define ETH_RX_BUF_SIZE    ETH_MAX_PACKET_SIZE /* buffer size for receive */
 #define ETH_TX_BUF_SIZE    ETH_MAX_PACKET_SIZE /* buffer size for transmit */
 #define ETH_RXBUFNB        10                  /* 20 Rx buffers of size ETH_RX_BUF_SIZE */
 #define ETH_TXBUFNB        10                   /* 5  Tx buffers of size ETH_TX_BUF_SIZE */
#endif


/* PHY configuration section **************************************************/

#ifdef PHY_DP83848
/* The PHY status register value change from a PHY to another, so the user have 
   to update this value depending on the used external PHY */
#define PHY_SR    ((uint16_t)16) /* Value for DP83848 PHY */

/* The Speed and Duplex mask values change from a PHY to another, so the user
   have to update this value depending on the used external PHY */
#define PHY_SPEED_STATUS            ((uint16_t)0x0002) /* Value for DP83848 PHY */
#define PHY_DUPLEX_STATUS           ((uint16_t)0x0004) /* Value for DP83848 PHY */
#endif //DP83848
#ifdef PHY_LAN8720
/* The PHY status register value change from a PHY to another, so the user have
   to update this value depending on the used external PHY */
#define PHY_SR    ((uint16_t)31) /* Value for LAN8720 PHY */

/* The Speed and Duplex mask values change from a PHY to another, so the user
   have to update this value depending on the used external PHY */
#define PHY_SPEED_STATUS             ((uint16_t)0x0004) /* Value for LAN8720 PHY */
#define PHY_DUPLEX_STATUS           ((uint16_t)0x0010) /* Value for LAN8720 PHY */

#endif
   
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */  

#ifdef __cplusplus
}
#endif

#endif /* __STM32F2x7_ETH_CONF_H */


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/

