#ifndef _MODBUS_H
#define _MODBUS_H
#include <stdint.h>

#ifndef MODBUS_PACKET_SZ
  #define MODBUS_PACKET_SZ              (256U)
#endif
#define MODBUS_MIN_PACKET_SZ            (4)
/// ModBus data size with CRC
#define MODBUS_DATA_SZ                  (MODBUS_PACKET_SZ-(4-2))
#define MODBUS_BROADCAST_ADDR                 (0x00)
#define MODBUS_BYTES2WORD(_data_0, _data_1)   ( (((int)_data_0)<<8) | _data_1 )

#if 0
  #define	MODBUS_MAKE_WORD(_data)		      (((_data>>8) & 0x00FFU) | (((int)_data & 0x00FFU)<<8))
#else
  #define	MODBUS_MAKE_WORD(_data)		      (_data)
#endif

#define MODBUS_DEFAULT_ADDRESS          (0x22)
/* Default baudrate for UART */
#define MODBUS_UART_BAUDRATE            (9600U)

#define MODBUS_FUNC_RD_COILS            (0x01)
#define MODBUS_FUNC_RD_DISCRETE_INPUTS  (0x02)
#define MODBUS_FUNC_RD_HOLDING_REGS     (0x03)
#define MODBUS_FUNC_RD_INPUT_REGS       (0x04)
#define MODBUS_FUNC_WR_SINGLE_COIL      (0x05)
#define MODBUS_FUNC_WR_SINGLE_REG       (0x06)

#define MODBUS_FUNC_WR_COILS            (0x0F)
#define MODBUS_FUNC_WR_REGS             (0x10)

#define MODBUS_ILLEGAL_FUNCTION         (0x01)
#define MODBUS_ILLEGAL_DATA_ADDR        (0x02)
#define MODBUS_ILLEGAL_DATA_VALUE       (0x03)

#define MODBUS_SERIAL_OPTION_2STOPS      (0x00)
#define MODBUS_SERIAL_OPTION_1STOPS      (0x01)
#define MODBUS_SERIAL_OPTION_PARITY_EVEN (0x02)
#define MODBUS_SERIAL_OPTION_PARITY_ODD  (0x04)
#define MODBUS_SERIAL_OPTION_PARITY_NO   (0x00)


#ifdef __cplusplus
 extern "C" {
#endif

typedef enum modbus_baudrate_e { Baud9600, Baud19200, Baud38400, Baud57600, Baud115200, Baud230400 } modbus_baudrate_t;

typedef struct modbus_packet_s {
  unsigned char   address;
  unsigned char   function;
  unsigned char   data[MODBUS_DATA_SZ];
} modbus_packet_t;

uint16_t modbus_calc_crc(uint8_t* packet, uint16_t  data_sz);
#ifdef __cplusplus
 }
#endif
#endif  //_MODBUS_H
