/*
 * media_buffer.h
 *
 *  Created on: 23 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */

#ifndef MEDIA_BUFFER_H_
#define MEDIA_BUFFER_H_
#include "media.h"
#include "ftp_client.h"
#include "ff.h"
#include "pt.h"
#include "lwip/tcp.h"

#define MEDIA_BUFFER_DEFAULT_RTS_PORT   (80)

#define MEDIA_MODE_SINGLE               (0)
#define MEDIA_MODE_REPEAT               (1)

#define MEDIA_ERR_MEMORY        (1)
/* Media non exist */
#define MEDIA_ERR_NONEXIST      (2)
#define MEDIA_ERR_CONFIG        (5)


#define MEDIA_DIR_SZ      (100)
#define MEDIA_FILE_SZ     (13)


#ifdef __cplusplus
 extern "C" {
#endif

   typedef enum media_buffer_source_e { MEDIA_SRC_SD, MEDIA_SRC_FTP, MEDIA_SRC_RTS, MEDIA_SRC_NONE} media_buffer_source_t;

   typedef struct media_buffer_cfg_s {
     media_buffer_source_t      source;
     uint8_t                    play_mode;
     char                       source_dir[MEDIA_DIR_SZ];
   } media_buffer_cfg_t;


   typedef struct media_buffer_handle_s {
     int16_t                    error;
     media_buffer_source_t      source;
     FIL                        mp3_file;
     char                       filename[MEDIA_FILE_SZ];

     ftpc_handle_t*             ftpc_hnd;

     struct tcp_pcb*            data_pcb;        /// Pointer on the current tcp_pcb
     struct pbuf*               p_tx;            /// Pointer on pbuf to be transmitted
     struct pbuf*               p_rx;            /// Pointer on pbuf to be received


     struct pt_sem              data_ready;

     media_handle_t*            hnd;
     const media_buffer_cfg_t*  cfg;

     /* Protothreads */
     lc_t                       lc;
     /* */
   } media_buffer_handle_t;

   int media_buffer_init(media_buffer_handle_t* pt, media_handle_t* hnd, ftpc_handle_t* ftpc_hnd);
   int media_buffer_process(media_buffer_handle_t* pt);
   int media_buffer_open(media_buffer_handle_t* pt,  media_buffer_cfg_t*  cfg, const char* url);
   int media_buffer_close(media_buffer_handle_t* pt);

#ifdef __cplusplus
 }
#endif


#endif /* MEDIA_BUFFER_H_ */
