/*************************************************************************
 *    File name   : drv_vs1002.h
 *    Description : VS1002 Driver include file
 **************************************************************************/
#ifndef  __DRV_VS1002_H
#define  __DRV_VS1002_H

#include <stdint.h>
#include <stdbool.h>
#include "drv_vs1002_cnfg.h"

#define MP3_ReadCmd     (0x03)
#define MP3_WriteCmd    (0x02)

#define MP3_VS1002_REV  (4)

#define VS1002_BUFFER_SIZE  (2048)


#define MAX(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; })

#define MIN(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a < _b ? _a : _b; })



#ifdef __cplusplus
 extern "C" {
#endif


typedef enum _Dma_BurstSize_t
{
  Dma_1_Transfer = 0, Dma_4_Transfer, Dma_8_Transfer, Dma_16_Transfer,
  Dma_32_Transfer, Dma_64_Transfer, Dma_128_Transfer, Dma_254_Transfer
} Dma_BurstSize_t;

typedef enum _Dma_Width_t
{
  Dma_Byte = 0, Dma_HalfWord, Dma_Word
} Dma_Width_t;

typedef struct _DmaLli_t
{
  uint32_t DMA_SrcAddr;
  uint32_t DMA_DstAddr;
  uint32_t DMA_NextLli;
  union
  {
    uint32_t DMA_Ctrl;
    struct
    {
      uint32_t TransferSize :12;
      uint32_t SBSize       : 3;
      uint32_t DBSize       : 3;
      uint32_t SWidth       : 3;
      uint32_t DWidth       : 3;
      uint32_t              : 2;
      uint32_t SInc         : 1;
      uint32_t DInc         : 1;
      uint32_t Prot0        : 1;
      uint32_t Prot1        : 1;
      uint32_t Prot2        : 1;
      uint32_t TermCntIE    : 1;
    };
  };
} DmaLli_t, *pDmaLli_t;

//#define MP3_VOL_STEP    2     // 0.5 dB

typedef enum _MP3_RegAddr_t
{
  MP3_MODE = 0, MP3_STATUS, MP3_BASS, MP3_CLOCKF, MP3_DECODE_TIME, MP3_AUDATA,
  MP3_WRAM, MP3_WRAMADDR, MP3_HDAT0, MP3_HDAT1, MP3_AIADDR, MP3_VOL,
  MP3_AICTRL0,MP3_AICTRL1, MP3_AICTRL2, MP3_AICTRL3
} MP3_RegAddr_t;

typedef enum _MP3_Status_t
{
  MP3_Pass = 0,
  MP3_Fault,
  MP3_WrongRev,
  MP3_NotComm,
} MP3_Status_t;

typedef enum _MP3_Cmd_t
{
  Mp3CmdPowerUp = 0, Mp3CmdPowerDown, Mp3CmdGetRevision , Mp3CmdSetClkReg,
  Mp3CmdSetModeReg, Mp3CmdSetVol, Mp3CmdTstSin, Mp3CmdPlay,
  Mp3CmdPlayStop, Mp3CmdWideStereo, Mp3CmdLoudness
} MP3_Cmd_t;

typedef enum Mp3TransferStatus_t
{
  Mp3NotDataTransfer = 0, Mp3DataTransferProgress,
  Mp3DataTransferComplete, Mp3DataTransferCompleteWithError,
} Mp3TransferStatus_t;

typedef enum _Mp3PlaySpeed_t
{
  Mp3PlayNorm = 0, Mp3PlayIncreaseSpeed, Mp3PlayDecreaseSpeed,
} Mp3PlaySpeed_t;

typedef struct _Mp3Stream_t
{
  uint32_t* pStream;
  uint32_t Size;
  Mp3PlaySpeed_t PlaySpeed;
} Mp3Stream_t, *pMp3Stream_t;

typedef enum _Mp3StreamId_t
{
  MPG_2_5_1_4a = 0, MPG_2_5_1_4b, MPG_2_0_1_2, ISO_11172_3_1_0
} Mp3StreamId_t;

//extern void Dly100us(void *arg);
extern void delay(uint32_t wait_ms);
#define Mp3SpiBufferDrainDly() for(volatile uint32_t drain_dly = 15; drain_dly; --drain_dly)

/*************************************************************************
 * Function Name: Mp3SendCmd
 * Parameters: MP3_Cmd_t Cmd, uint32_t* pData
 * Return: none
 *
 * Description: Send command to the MP3 module (VS1002)
 *
 *************************************************************************/
void Mp3SendCmd (MP3_Cmd_t Cmd, uint32_t* pData);
uint16_t MP3_TranserByte (uint8_t ch);

bool MP3_DReq (void);

#ifdef __cplusplus
}
#endif

#endif  /* __DRV_VS1002_H */
