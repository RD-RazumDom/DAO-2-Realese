/*
 * bsp.h
 *
 *  Created on: 17 окт. 2014 г.
 *      Author: Dmitry Rudakov
 */

#ifndef BSP_H_
#define BSP_H_

namespace BSP
{

//  typedef enum
//  {
//    PortA = 0, PortB, PortC
//  } CPort;

  typedef enum
  {
    IN = 0, OUT
  } Direction;

  template <class TPort>
  class CPort {
  public:

    TPort*        getPort();
  };

  template<class CPort, uint16_t pin>
    class CPin
    {
    public:
      static CPort       port;

    public:
      CPin() {

      }

      static void      setValue(bool value)
      {

      };

      static bool      getValue()
      {
          return false;
      };

      static void       setDirection(Direction dir)
      {

      };
    };

    template<class CPin>
    class COutputPin : public CPin
    {
      public:
        COutputPin() : CPin()
        {
          CPin::setDirection(Direction::OUT);
        }

    };

    template<class CPin>
    class CInputPin : public CPin
    {
      public:
        CInputPin() : CPin()
        {
          CPin::setDirection(Direction::IN);
        }

    };

    template<class CPin, bool inverted>
    class CLed : public COutputPin<CPin>
    {

    public:

      CLed() : COutputPin<CPin>() {

      }

      void setValue(bool value) {
        CPin::setValue((inverted) ? !value : value);
      }

      void toggleValue() {
        CPin::setValue(!CPin::getValue());
      }

    };

}

#endif /* BSP_H_ */
