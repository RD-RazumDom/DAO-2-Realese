/*
 * bsp.h
 *
 *  Created on: 17 окт. 2014 г.
 *      Author: Dmitry Rudakov
 */

#ifndef BSP_STM32_H_
#define BSP_STM32_H_

#include "bsp.hpp"
#include "stm32f2xx_conf.h"

namespace BSP
{
//  void USE_PORTA()                       { /* Enable clock */ RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);}
//  void USE_PORTB()                       { /* Enable clock */ RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);}
//  void USE_PORTC()                       { /* Enable clock */ RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);}
//
//  static GPIO_TypeDef* mapPort2Device[] =
//    { GPIOA, GPIOB, GPIOC };


  class CSTM32Port : CPort<GPIO_TypeDef*> {
  public:

  };

  class PortA : CSTM32Port {
  public:
    PortA() {
      /* Enable clock */
      RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    };

    GPIO_TypeDef*        getPort() {return GPIOA;};
  };

  class PortB : CSTM32Port {
  public:
    PortB() {
      /* Enable clock */
      RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    };

    GPIO_TypeDef*        getPort() {return GPIOB;};
  };

  class PortC : CSTM32Port {
  public:
    PortC() {
      /* Enable clock */
      RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    };

    GPIO_TypeDef*        getPort() {return GPIOC;};
  };

  class PortE : CSTM32Port {
    public:
      PortE() {
        /* Enable clock */
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
      };

      GPIO_TypeDef*        getPort() {return GPIOE;};
    };

  class PortD : CSTM32Port {
      public:
        PortD() {
          /* Enable clock */
          RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
        };

        GPIO_TypeDef*        getPort() {return GPIOD;};
      };


  template<class CPort, uint16_t pin>
  class CSTM32Pin : public CPin<CPort, pin>
    {

    public:
      CSTM32Pin() :CPin<CPort, pin>() {

      }

      static void setValue(bool value)
      {
        GPIO_WriteBit(CSTM32Pin::port.getPort(), pin, (value) ? Bit_SET : Bit_RESET);
      };

      static bool getValue()
      {
        return (GPIO_ReadInputDataBit(CSTM32Pin::port.getPort(), pin) == Bit_SET);
      };

      static void  setDirection(Direction dir)
      {
        GPIO_InitTypeDef GPIO_InitStructure;
        CPort& port = CSTM32Pin::port;

        switch(dir) {
        case OUT:
          GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
          GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
          GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
          break;
        case IN:
        default:
          GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
          GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
          GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
          break;
        }
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Pin = pin;
        GPIO_Init(port.getPort(), &GPIO_InitStructure);
      };

    };


};



#endif /* BSP_STM32_H_ */
