#ifndef _MODBUS_SLAVE_H
#define _MODBUS_SLAVE_H
#include "modbus.h"
#include <stdint.h>
#ifdef __cplusplus
 extern "C" {
#endif

#define MODBUS_HAS_RELAYS      (1)
#define MODBUS_USART            USART1
#define MODBUS_START_TRANSMITION(_ch)  {GPIOC->BSRRL = GPIO_Pin_13; USART_SendData(MODBUS_USART, _ch);}
#define MODBUS_STOP_TRANSMITION() {GPIOC->BSRRH = GPIO_Pin_13;}

typedef enum { IDLE, RECEIVE, CHECK_TIMEOUT, PROCESS, WAIT_TRANSMIT,  TRANSMIT } modbus_state_t;

/// Internal structure to represent Modbus packet
typedef struct modbus_rx_tx_s {
  modbus_packet_t   packet;
  volatile uint8_t  data_sz;
  volatile uint8_t  data_index;
} modbus_rx_tx_t;

typedef struct modbus_handle_s {
  volatile modbus_state_t       state;
  uint8_t                       address;
  union {
    modbus_rx_tx_t     state_tx;
    modbus_rx_tx_t     state_rx;
  };
} modbus_handle_t;


void  modbus_slave_init(uint8_t address, uint32_t baudrate, uint8_t port_options);
void  modbus_slave_process(void);
unsigned char modbus_slave_process_msg(modbus_packet_t*     state_rx, modbus_packet_t*     state_tx);

/// Interrupt driver - RX 
void  modbus_slave_rx_interrupt(uint8_t fib);
/// Interrupt driver - TX 
int  modbus_slave_tx_interrupt(void);

// External dependents
extern int  modbus_slave_get_input(uint16_t index, int16_t* value);
extern int  modbus_slave_get_input_register(uint16_t index, int16_t* value);
extern int  modbus_slave_get_holding_register(uint16_t index, int16_t* value);
extern int  modbus_slave_get_holding_registers(uint16_t index, uint16_t sz, int16_t* values);
extern int  modbus_slave_set_holding_register(uint16_t index, int16_t value);
#ifdef  MODBUS_HAS_RELAYS
extern int  modbus_slave_set_coil(uint16_t index, int16_t value);
extern int  modbus_slave_get_coil(uint16_t index, int16_t* value);
#endif  //MODBUS_HAS_RELAYS
void modbus_slave_timer_3_5(void);
void modbus_slave_timer_1_5(void);

#ifdef __cplusplus
 }
#endif

#endif //_MODBUS_SLAVE_H
