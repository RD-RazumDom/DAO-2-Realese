/*
 * stm32f2x7_bsp_rtc.h
 *
 *  Created on: 10 дек. 2014 г.
 *      Author: dimion
 */

#ifndef STM32F2X7_BSP_RTC_H_
#define STM32F2X7_BSP_RTC_H_

#include "stm32f2xx_conf.h"

#ifdef __cplusplus
 extern "C" {
#endif

   void RTC_Config(void);

#ifdef __cplusplus
 }
#endif
#endif /* STM32F2X7_BSP_RTC_H_ */
