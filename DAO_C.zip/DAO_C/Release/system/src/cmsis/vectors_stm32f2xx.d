system/src/cmsis/vectors_stm32f2xx.o: \
 ../system/src/cmsis/vectors_stm32f2xx.c \
 D:/RD/Work/DAO2/system/include/cortexm/ExceptionHandlers.h

D:/RD/Work/DAO2/system/include/cortexm/ExceptionHandlers.h:
