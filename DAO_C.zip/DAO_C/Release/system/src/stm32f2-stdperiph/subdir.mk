################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../system/src/stm32f2-stdperiph/misc.c \
../system/src/stm32f2-stdperiph/stm32f2xx_dma.c \
../system/src/stm32f2-stdperiph/stm32f2xx_exti.c \
../system/src/stm32f2-stdperiph/stm32f2xx_gpio.c \
../system/src/stm32f2-stdperiph/stm32f2xx_i2c.c \
../system/src/stm32f2-stdperiph/stm32f2xx_iwdg.c \
../system/src/stm32f2-stdperiph/stm32f2xx_pwr.c \
../system/src/stm32f2-stdperiph/stm32f2xx_rcc.c \
../system/src/stm32f2-stdperiph/stm32f2xx_rtc.c \
../system/src/stm32f2-stdperiph/stm32f2xx_sdio.c \
../system/src/stm32f2-stdperiph/stm32f2xx_spi.c \
../system/src/stm32f2-stdperiph/stm32f2xx_syscfg.c \
../system/src/stm32f2-stdperiph/stm32f2xx_tim.c \
../system/src/stm32f2-stdperiph/stm32f2xx_usart.c 

C_DEPS += \
./system/src/stm32f2-stdperiph/misc.d \
./system/src/stm32f2-stdperiph/stm32f2xx_dma.d \
./system/src/stm32f2-stdperiph/stm32f2xx_exti.d \
./system/src/stm32f2-stdperiph/stm32f2xx_gpio.d \
./system/src/stm32f2-stdperiph/stm32f2xx_i2c.d \
./system/src/stm32f2-stdperiph/stm32f2xx_iwdg.d \
./system/src/stm32f2-stdperiph/stm32f2xx_pwr.d \
./system/src/stm32f2-stdperiph/stm32f2xx_rcc.d \
./system/src/stm32f2-stdperiph/stm32f2xx_rtc.d \
./system/src/stm32f2-stdperiph/stm32f2xx_sdio.d \
./system/src/stm32f2-stdperiph/stm32f2xx_spi.d \
./system/src/stm32f2-stdperiph/stm32f2xx_syscfg.d \
./system/src/stm32f2-stdperiph/stm32f2xx_tim.d \
./system/src/stm32f2-stdperiph/stm32f2xx_usart.d 

OBJS += \
./system/src/stm32f2-stdperiph/misc.o \
./system/src/stm32f2-stdperiph/stm32f2xx_dma.o \
./system/src/stm32f2-stdperiph/stm32f2xx_exti.o \
./system/src/stm32f2-stdperiph/stm32f2xx_gpio.o \
./system/src/stm32f2-stdperiph/stm32f2xx_i2c.o \
./system/src/stm32f2-stdperiph/stm32f2xx_iwdg.o \
./system/src/stm32f2-stdperiph/stm32f2xx_pwr.o \
./system/src/stm32f2-stdperiph/stm32f2xx_rcc.o \
./system/src/stm32f2-stdperiph/stm32f2xx_rtc.o \
./system/src/stm32f2-stdperiph/stm32f2xx_sdio.o \
./system/src/stm32f2-stdperiph/stm32f2xx_spi.o \
./system/src/stm32f2-stdperiph/stm32f2xx_syscfg.o \
./system/src/stm32f2-stdperiph/stm32f2xx_tim.o \
./system/src/stm32f2-stdperiph/stm32f2xx_usart.o 


# Each subdirectory must supply rules for building sources it contributes
system/src/stm32f2-stdperiph/%.o: ../system/src/stm32f2-stdperiph/%.c system/src/stm32f2-stdperiph/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross ARM C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -O1 -Wall -Wextra -g -DSTM32F2XX -DUSE_STDPERIPH_DRIVER -DHSE_VALUE=25000000UL -DNDEBUG -DSYSCLK=120000000UL -DFATFS_USE_SDCARD=1 -I"D:/RD/Work/DAO2/include" -I"D:/RD/Work/DAO2/system/include" -I"D:/RD/Work/DAO2/system/include/cmsis" -I"D:/RD/Work/DAO2/system/include/stm32f2-stdperiph" -I"D:/RD/Work/DAO2/system/include/stm32f2-eth" -I"D:/RD/Work/DAO2/pt-1.4" -I"D:/RD/Work/DAO2/fatfs_v10c/src" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/Standalone" -I"D:/RD/Work/DAO2/httpserver_raw" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


