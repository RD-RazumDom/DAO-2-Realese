################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../system/src/diag/Trace.c \
../system/src/diag/trace_impl.c 

C_DEPS += \
./system/src/diag/Trace.d \
./system/src/diag/trace_impl.d 

OBJS += \
./system/src/diag/Trace.o \
./system/src/diag/trace_impl.o 


# Each subdirectory must supply rules for building sources it contributes
system/src/diag/%.o: ../system/src/diag/%.c system/src/diag/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross ARM C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -O1 -Wall -Wextra -g -DSTM32F2XX -DUSE_STDPERIPH_DRIVER -DHSE_VALUE=25000000UL -DNDEBUG -DSYSCLK=120000000UL -DFATFS_USE_SDCARD=1 -I"D:/RD/Work/DAO2/include" -I"D:/RD/Work/DAO2/system/include" -I"D:/RD/Work/DAO2/system/include/cmsis" -I"D:/RD/Work/DAO2/system/include/stm32f2-stdperiph" -I"D:/RD/Work/DAO2/system/include/stm32f2-eth" -I"D:/RD/Work/DAO2/pt-1.4" -I"D:/RD/Work/DAO2/fatfs_v10c/src" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/Standalone" -I"D:/RD/Work/DAO2/httpserver_raw" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


