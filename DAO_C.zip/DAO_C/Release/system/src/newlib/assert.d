system/src/newlib/assert.o: ../system/src/newlib/assert.c \
 D:/RD/Work/DAO2/system/include/diag/Trace.h

D:/RD/Work/DAO2/system/include/diag/Trace.h:
