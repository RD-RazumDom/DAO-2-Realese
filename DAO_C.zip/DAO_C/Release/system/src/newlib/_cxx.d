system/src/newlib/_cxx.o: ../system/src/newlib/_cxx.cpp \
 D:/RD/Work/DAO2/system/include/diag/Trace.h

D:/RD/Work/DAO2/system/include/diag/Trace.h:
