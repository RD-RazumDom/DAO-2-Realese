system/src/newlib/_write.o: ../system/src/newlib/_write.c \
 D:/RD/Work/DAO2/system/include/diag/Trace.h

D:/RD/Work/DAO2/system/include/diag/Trace.h:
