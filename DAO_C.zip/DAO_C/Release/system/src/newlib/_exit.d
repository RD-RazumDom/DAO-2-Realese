system/src/newlib/_exit.o: ../system/src/newlib/_exit.c \
 D:/RD/Work/DAO2/system/include/diag/Trace.h

D:/RD/Work/DAO2/system/include/diag/Trace.h:
