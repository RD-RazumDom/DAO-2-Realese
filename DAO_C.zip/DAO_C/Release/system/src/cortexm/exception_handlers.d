system/src/cortexm/exception_handlers.o: \
 ../system/src/cortexm/exception_handlers.c \
 D:/RD/Work/DAO2/system/include/cortexm/ExceptionHandlers.h

D:/RD/Work/DAO2/system/include/cortexm/ExceptionHandlers.h:
