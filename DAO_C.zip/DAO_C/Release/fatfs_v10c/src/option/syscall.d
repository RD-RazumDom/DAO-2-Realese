fatfs_v10c/src/option/syscall.o: ../fatfs_v10c/src/option/syscall.c \
 ../fatfs_v10c/src/option/../ff.h ../fatfs_v10c/src/option/../integer.h \
 ../fatfs_v10c/src/option/../ffconf.h

../fatfs_v10c/src/option/../ff.h:

../fatfs_v10c/src/option/../integer.h:

../fatfs_v10c/src/option/../ffconf.h:
