fatfs_v10c/src/option/unicode.o: ../fatfs_v10c/src/option/unicode.c \
 ../fatfs_v10c/src/option/../ff.h ../fatfs_v10c/src/option/../integer.h \
 ../fatfs_v10c/src/option/../ffconf.h

../fatfs_v10c/src/option/../ff.h:

../fatfs_v10c/src/option/../integer.h:

../fatfs_v10c/src/option/../ffconf.h:
