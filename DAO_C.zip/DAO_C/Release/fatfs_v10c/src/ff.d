fatfs_v10c/src/ff.o: ../fatfs_v10c/src/ff.c ../fatfs_v10c/src/ff.h \
 ../fatfs_v10c/src/integer.h ../fatfs_v10c/src/ffconf.h \
 ../fatfs_v10c/src/diskio.h

../fatfs_v10c/src/ff.h:

../fatfs_v10c/src/integer.h:

../fatfs_v10c/src/ffconf.h:

../fatfs_v10c/src/diskio.h:
