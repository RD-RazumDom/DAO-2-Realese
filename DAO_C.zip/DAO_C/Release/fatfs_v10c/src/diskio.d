fatfs_v10c/src/diskio.o: ../fatfs_v10c/src/diskio.c \
 ../fatfs_v10c/src/diskio.h ../fatfs_v10c/src/integer.h \
 D:/RD/Work/DAO2/include/sdcard.h D:/RD/Work/DAO2/fatfs_v10c/src/diskio.h

../fatfs_v10c/src/diskio.h:

../fatfs_v10c/src/integer.h:

D:/RD/Work/DAO2/include/sdcard.h:

D:/RD/Work/DAO2/fatfs_v10c/src/diskio.h:
