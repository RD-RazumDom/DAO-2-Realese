src/tftputils.o: ../src/tftputils.c D:/RD/Work/DAO2/include/tftputils.h \
 D:/RD/Work/DAO2/include/tftpserver.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/mem.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/opt.h \
 D:/RD/Work/DAO2/include/lwipopts.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/debug.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/arch.h \
 D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/arch/cc.h \
 D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/arch/cpu.h \
 D:/RD/Work/DAO2/system/include/diag/Trace.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/udp.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/pbuf.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/err.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/netif.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/ip_addr.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/def.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/ip.h

D:/RD/Work/DAO2/include/tftputils.h:

D:/RD/Work/DAO2/include/tftpserver.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/mem.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/opt.h:

D:/RD/Work/DAO2/include/lwipopts.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/debug.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/arch.h:

D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/arch/cc.h:

D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/arch/cpu.h:

D:/RD/Work/DAO2/system/include/diag/Trace.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/udp.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/pbuf.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/err.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/netif.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/ip_addr.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/def.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/ip.h:
