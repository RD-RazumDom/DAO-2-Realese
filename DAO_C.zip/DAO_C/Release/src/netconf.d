src/netconf.o: ../src/netconf.c \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/mem.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/opt.h \
 D:/RD/Work/DAO2/include/lwipopts.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/debug.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/arch.h \
 D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/arch/cc.h \
 D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/arch/cpu.h \
 D:/RD/Work/DAO2/system/include/diag/Trace.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/memp.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/memp_std.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/tcp.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/pbuf.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/err.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/ip.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/def.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/ip_addr.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/netif.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/icmp.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/udp.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/netif/etharp.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/dhcp.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/timers.h \
 D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/init.h \
 D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/Standalone/ethernetif.h \
 D:/RD/Work/DAO2/include/main.h \
 D:/RD/Work/DAO2/system/include/cmsis/stm32f2xx.h \
 D:/RD/Work/DAO2/system/include/cmsis/core_cm3.h \
 D:/RD/Work/DAO2/system/include/cmsis/core_cmInstr.h \
 D:/RD/Work/DAO2/system/include/cmsis/core_cmFunc.h \
 D:/RD/Work/DAO2/system/include/cmsis/system_stm32f2xx.h \
 D:/RD/Work/DAO2/include/stm32f2xx_conf.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_adc.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_can.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_crc.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_cryp.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_dac.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_dbgmcu.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_dcmi.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_dma.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_exti.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_flash.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_fsmc.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_hash.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_gpio.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_i2c.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_iwdg.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_pwr.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_rcc.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_rng.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_rtc.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_sdio.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_spi.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_syscfg.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_tim.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_usart.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_wwdg.h \
 D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/misc.h \
 D:/RD/Work/DAO2/include/stm32f2x7_eth_bsp.h \
 D:/RD/Work/DAO2/include/netconf.h \
 D:/RD/Work/DAO2/include/stm32f2x7_eth_conf.h \
 D:/RD/Work/DAO2/include/main.h D:/RD/Work/DAO2/include/debug.h

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/mem.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/opt.h:

D:/RD/Work/DAO2/include/lwipopts.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/debug.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/arch.h:

D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/arch/cc.h:

D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/arch/cpu.h:

D:/RD/Work/DAO2/system/include/diag/Trace.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/memp.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/memp_std.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/tcp.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/pbuf.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/err.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/ip.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/def.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/ip_addr.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/netif.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4/lwip/icmp.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/udp.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/netif/etharp.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/dhcp.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/timers.h:

D:/RD/Work/DAO2/lwip-1.4.1/src/include/lwip/init.h:

D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/Standalone/ethernetif.h:

D:/RD/Work/DAO2/include/main.h:

D:/RD/Work/DAO2/system/include/cmsis/stm32f2xx.h:

D:/RD/Work/DAO2/system/include/cmsis/core_cm3.h:

D:/RD/Work/DAO2/system/include/cmsis/core_cmInstr.h:

D:/RD/Work/DAO2/system/include/cmsis/core_cmFunc.h:

D:/RD/Work/DAO2/system/include/cmsis/system_stm32f2xx.h:

D:/RD/Work/DAO2/include/stm32f2xx_conf.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_adc.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_can.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_crc.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_cryp.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_dac.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_dbgmcu.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_dcmi.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_dma.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_exti.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_flash.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_fsmc.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_hash.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_gpio.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_i2c.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_iwdg.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_pwr.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_rcc.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_rng.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_rtc.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_sdio.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_spi.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_syscfg.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_tim.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_usart.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/stm32f2xx_wwdg.h:

D:/RD/Work/DAO2/system/include/stm32f2-stdperiph/misc.h:

D:/RD/Work/DAO2/include/stm32f2x7_eth_bsp.h:

D:/RD/Work/DAO2/include/netconf.h:

D:/RD/Work/DAO2/include/stm32f2x7_eth_conf.h:

D:/RD/Work/DAO2/include/main.h:

D:/RD/Work/DAO2/include/debug.h:
