################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../src/main.cpp 

C_SRCS += \
../src/console.c \
../src/drv_vs1002.c \
../src/ftp_client.c \
../src/media.c \
../src/media_buffer.c \
../src/modbus.c \
../src/modbus_slave.c \
../src/modbus_tcp_server.c \
../src/netconf.c \
../src/sdcard.c \
../src/stm32f2x7_bsp_i2c_ee.c \
../src/stm32f2x7_bsp_rtc.c \
../src/stm32f2x7_bsp_sdio_sd.c \
../src/stm32f2x7_eth_bsp.c \
../src/stm32f2xx_it.c \
../src/tftpserver.c \
../src/tftputils.c \
../src/web_radio.c 

C_DEPS += \
./src/console.d \
./src/drv_vs1002.d \
./src/ftp_client.d \
./src/media.d \
./src/media_buffer.d \
./src/modbus.d \
./src/modbus_slave.d \
./src/modbus_tcp_server.d \
./src/netconf.d \
./src/sdcard.d \
./src/stm32f2x7_bsp_i2c_ee.d \
./src/stm32f2x7_bsp_rtc.d \
./src/stm32f2x7_bsp_sdio_sd.d \
./src/stm32f2x7_eth_bsp.d \
./src/stm32f2xx_it.d \
./src/tftpserver.d \
./src/tftputils.d \
./src/web_radio.d 

OBJS += \
./src/console.o \
./src/drv_vs1002.o \
./src/ftp_client.o \
./src/main.o \
./src/media.o \
./src/media_buffer.o \
./src/modbus.o \
./src/modbus_slave.o \
./src/modbus_tcp_server.o \
./src/netconf.o \
./src/sdcard.o \
./src/stm32f2x7_bsp_i2c_ee.o \
./src/stm32f2x7_bsp_rtc.o \
./src/stm32f2x7_bsp_sdio_sd.o \
./src/stm32f2x7_eth_bsp.o \
./src/stm32f2xx_it.o \
./src/tftpserver.o \
./src/tftputils.o \
./src/web_radio.o 

CPP_DEPS += \
./src/main.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross ARM C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -O1 -Wall -Wextra -g -DSTM32F2XX -DUSE_STDPERIPH_DRIVER -DHSE_VALUE=25000000UL -DNDEBUG -DSYSCLK=120000000UL -DFATFS_USE_SDCARD=1 -I"D:/RD/Work/DAO2/include" -I"D:/RD/Work/DAO2/system/include" -I"D:/RD/Work/DAO2/system/include/cmsis" -I"D:/RD/Work/DAO2/system/include/stm32f2-stdperiph" -I"D:/RD/Work/DAO2/system/include/stm32f2-eth" -I"D:/RD/Work/DAO2/pt-1.4" -I"D:/RD/Work/DAO2/fatfs_v10c/src" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/Standalone" -I"D:/RD/Work/DAO2/httpserver_raw" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/%.o: ../src/%.cpp src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross ARM C++ Compiler'
	arm-none-eabi-g++ -mcpu=cortex-m3 -mthumb -O1 -Wall -Wextra -g -DSTM32F2XX -DUSE_STDPERIPH_DRIVER -DHSE_VALUE=25000000UL -DNDEBUG -DSYSCLK=120000000UL -DFATFS_USE_SDCARD=1 -I"D:/RD/Work/DAO2/include" -I"D:/RD/Work/DAO2/system/include" -I"D:/RD/Work/DAO2/system/include/cmsis" -I"D:/RD/Work/DAO2/system/include/stm32f2-stdperiph" -I"D:/RD/Work/DAO2/system/include/stm32f2-eth" -I"D:/RD/Work/DAO2/pt-1.4" -I"D:/RD/Work/DAO2/fatfs_v10c/src" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/Standalone" -I"D:/RD/Work/DAO2/httpserver_raw" -std=gnu++11 -fabi-version=0 -fno-exceptions -fno-rtti -fno-use-cxa-atexit -fno-threadsafe-statics -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


