src/modbus.o: ../src/modbus.c D:/RD/Work/DAO2/include/modbus.h

D:/RD/Work/DAO2/include/modbus.h:
