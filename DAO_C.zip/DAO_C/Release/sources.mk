################################################################################
# Automatically-generated file. Do not edit!
################################################################################

C++M_SRCS := 
ASM_SRCS := 
CPP_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
ELF_SRCS := 
C_UPPER_SRCS := 
CXX_SRCS := 
CCM_SRCS := 
C++_SRCS := 
OBJ_SRCS := 
SX_SRCS := 
CC_SRCS := 
C_SRCS := 
CXXM_SRCS := 
CCM_DEPS := 
C_UPPER_DEPS := 
SECONDARY_SIZE := 
CXXM_DEPS := 
C_DEPS := 
CC_DEPS := 
SX_DEPS := 
C++_DEPS := 
OBJS := 
CXX_DEPS := 
SECONDARY_FLASH := 
ASM_DEPS := 
S_UPPER_DEPS := 
C++M_DEPS := 
CPP_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
fatfs_v10c/src \
fatfs_v10c/src/option \
httpserver_raw \
lwip-1.4.1/port/STM32F2x7/Standalone \
lwip-1.4.1/src/api \
lwip-1.4.1/src/core \
lwip-1.4.1/src/core/ipv4 \
lwip-1.4.1/src/netif \
src \
system/src/cmsis \
system/src/cortexm \
system/src/diag \
system/src/newlib \
system/src/stm32f2-eth \
system/src/stm32f2-stdperiph \

