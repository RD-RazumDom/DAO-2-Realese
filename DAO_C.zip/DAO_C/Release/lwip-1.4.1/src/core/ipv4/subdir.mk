################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lwip-1.4.1/src/core/ipv4/autoip.c \
../lwip-1.4.1/src/core/ipv4/icmp.c \
../lwip-1.4.1/src/core/ipv4/igmp.c \
../lwip-1.4.1/src/core/ipv4/inet.c \
../lwip-1.4.1/src/core/ipv4/inet_chksum.c \
../lwip-1.4.1/src/core/ipv4/ip.c \
../lwip-1.4.1/src/core/ipv4/ip_addr.c \
../lwip-1.4.1/src/core/ipv4/ip_frag.c 

C_DEPS += \
./lwip-1.4.1/src/core/ipv4/autoip.d \
./lwip-1.4.1/src/core/ipv4/icmp.d \
./lwip-1.4.1/src/core/ipv4/igmp.d \
./lwip-1.4.1/src/core/ipv4/inet.d \
./lwip-1.4.1/src/core/ipv4/inet_chksum.d \
./lwip-1.4.1/src/core/ipv4/ip.d \
./lwip-1.4.1/src/core/ipv4/ip_addr.d \
./lwip-1.4.1/src/core/ipv4/ip_frag.d 

OBJS += \
./lwip-1.4.1/src/core/ipv4/autoip.o \
./lwip-1.4.1/src/core/ipv4/icmp.o \
./lwip-1.4.1/src/core/ipv4/igmp.o \
./lwip-1.4.1/src/core/ipv4/inet.o \
./lwip-1.4.1/src/core/ipv4/inet_chksum.o \
./lwip-1.4.1/src/core/ipv4/ip.o \
./lwip-1.4.1/src/core/ipv4/ip_addr.o \
./lwip-1.4.1/src/core/ipv4/ip_frag.o 


# Each subdirectory must supply rules for building sources it contributes
lwip-1.4.1/src/core/ipv4/%.o: ../lwip-1.4.1/src/core/ipv4/%.c lwip-1.4.1/src/core/ipv4/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross ARM C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -O1 -Wall -Wextra -g -DSTM32F2XX -DUSE_STDPERIPH_DRIVER -DHSE_VALUE=25000000UL -DNDEBUG -DSYSCLK=120000000UL -DFATFS_USE_SDCARD=1 -I"D:/RD/Work/DAO2/include" -I"D:/RD/Work/DAO2/system/include" -I"D:/RD/Work/DAO2/system/include/cmsis" -I"D:/RD/Work/DAO2/system/include/stm32f2-stdperiph" -I"D:/RD/Work/DAO2/system/include/stm32f2-eth" -I"D:/RD/Work/DAO2/pt-1.4" -I"D:/RD/Work/DAO2/fatfs_v10c/src" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/Standalone" -I"D:/RD/Work/DAO2/httpserver_raw" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


