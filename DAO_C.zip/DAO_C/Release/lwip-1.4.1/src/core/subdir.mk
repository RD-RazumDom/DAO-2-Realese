################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lwip-1.4.1/src/core/def.c \
../lwip-1.4.1/src/core/dhcp.c \
../lwip-1.4.1/src/core/dns.c \
../lwip-1.4.1/src/core/init.c \
../lwip-1.4.1/src/core/mem.c \
../lwip-1.4.1/src/core/memp.c \
../lwip-1.4.1/src/core/netif.c \
../lwip-1.4.1/src/core/pbuf.c \
../lwip-1.4.1/src/core/raw.c \
../lwip-1.4.1/src/core/stats.c \
../lwip-1.4.1/src/core/sys.c \
../lwip-1.4.1/src/core/tcp.c \
../lwip-1.4.1/src/core/tcp_in.c \
../lwip-1.4.1/src/core/tcp_out.c \
../lwip-1.4.1/src/core/timers.c \
../lwip-1.4.1/src/core/udp.c 

C_DEPS += \
./lwip-1.4.1/src/core/def.d \
./lwip-1.4.1/src/core/dhcp.d \
./lwip-1.4.1/src/core/dns.d \
./lwip-1.4.1/src/core/init.d \
./lwip-1.4.1/src/core/mem.d \
./lwip-1.4.1/src/core/memp.d \
./lwip-1.4.1/src/core/netif.d \
./lwip-1.4.1/src/core/pbuf.d \
./lwip-1.4.1/src/core/raw.d \
./lwip-1.4.1/src/core/stats.d \
./lwip-1.4.1/src/core/sys.d \
./lwip-1.4.1/src/core/tcp.d \
./lwip-1.4.1/src/core/tcp_in.d \
./lwip-1.4.1/src/core/tcp_out.d \
./lwip-1.4.1/src/core/timers.d \
./lwip-1.4.1/src/core/udp.d 

OBJS += \
./lwip-1.4.1/src/core/def.o \
./lwip-1.4.1/src/core/dhcp.o \
./lwip-1.4.1/src/core/dns.o \
./lwip-1.4.1/src/core/init.o \
./lwip-1.4.1/src/core/mem.o \
./lwip-1.4.1/src/core/memp.o \
./lwip-1.4.1/src/core/netif.o \
./lwip-1.4.1/src/core/pbuf.o \
./lwip-1.4.1/src/core/raw.o \
./lwip-1.4.1/src/core/stats.o \
./lwip-1.4.1/src/core/sys.o \
./lwip-1.4.1/src/core/tcp.o \
./lwip-1.4.1/src/core/tcp_in.o \
./lwip-1.4.1/src/core/tcp_out.o \
./lwip-1.4.1/src/core/timers.o \
./lwip-1.4.1/src/core/udp.o 


# Each subdirectory must supply rules for building sources it contributes
lwip-1.4.1/src/core/%.o: ../lwip-1.4.1/src/core/%.c lwip-1.4.1/src/core/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross ARM C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -O1 -Wall -Wextra -g -DSTM32F2XX -DUSE_STDPERIPH_DRIVER -DHSE_VALUE=25000000UL -DNDEBUG -DSYSCLK=120000000UL -DFATFS_USE_SDCARD=1 -I"D:/RD/Work/DAO2/include" -I"D:/RD/Work/DAO2/system/include" -I"D:/RD/Work/DAO2/system/include/cmsis" -I"D:/RD/Work/DAO2/system/include/stm32f2-stdperiph" -I"D:/RD/Work/DAO2/system/include/stm32f2-eth" -I"D:/RD/Work/DAO2/pt-1.4" -I"D:/RD/Work/DAO2/fatfs_v10c/src" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7" -I"D:/RD/Work/DAO2/lwip-1.4.1/src/include/ipv4" -I"D:/RD/Work/DAO2/lwip-1.4.1/port/STM32F2x7/Standalone" -I"D:/RD/Work/DAO2/httpserver_raw" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


