@echo off
cd /d %~dp0
set PERL_BIN=D:\Tool\common\Perl\bin
set PATH=%PATH%;%PERL_BIN%
perl makefsdata ../../httpserver_raw/fs
