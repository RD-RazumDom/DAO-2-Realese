/**
  ******************************************************************************
  * @file    modbus_slave.c 
  * @author  Dmitry Rudakov
  * @brief   Provide API for ModBus slave functionality
  ******************************************************************************
 **/ 

#include "modbus_slave.h"
#include "stm32f2xx_conf.h"

#define MODBUS_PRESCALER    (256U)
#if (MODBUS_UART_BAUDRATE > 9600)
  // Try to set timer OCR to 1,750ms
  #define   OCR_VALUE_3_5   (SYSCLK/MODBUS_PRESCALER/571-1)
  // Try to set timer OCR to 0,750ms
  #define   OCR_VALUE_1_5   (SYSCLK/MODBUS_PRESCALER/1333-1)
#else
  // Try to set timer OCR to 3.5T
  #define   OCR_VALUE_3_5   (SYSCLK/MODBUS_PRESCALER*39/MODBUS_UART_BAUDRATE-1)
  // Try to set timer OCR to 1.5Tms
  #define   OCR_VALUE_1_5   (SYSCLK/MODBUS_PRESCALER*17/MODBUS_UART_BAUDRATE-1)
#endif

#if (OCR_VALUE_3_5 > (65535/2)) || (OCR_VALUE_3_5 < 1)
  #error "Wrong frequency for OCR_VALUE_3_5!"
#endif

#if (OCR_VALUE_1_5 > (65535/2)) || (OCR_VALUE_1_5 < 1)
  #error "Wrong frequency for OCR_VALUE_1_5!"
#endif



static modbus_handle_t  _modbus_handle = { IDLE, MODBUS_BROADCAST_ADDR };
static modbus_handle_t*  modbus_handle = &_modbus_handle;
/// 
static unsigned char modbus_slave_send_exception(modbus_packet_t*     packet_tx, unsigned char exp);
static unsigned char modbus_slave_read_input_registers(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx);
static unsigned char modbus_slave_read_holding_registers(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx);
static unsigned char modbus_slave_write_holding_register(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx);
static unsigned char modbus_slave_write_holding_registers(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx);
static unsigned char modbus_slave_read_inputs(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx);
#ifdef  MODBUS_HAS_RELAYS
  static unsigned char modbus_write_single_coil(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx);
  static unsigned char modbus_slave_read_coils(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx);
  static unsigned char modbus_slave_write_coils(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx);
#endif  //MODBUS_HAS_RELAYS


static void     _modbus_hal_init(uint32_t baudrate, uint8_t port_options) {
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  USART_InitTypeDef USART_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  /* Enable GPIO clock */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC, ENABLE);

    /* Enable UART clock */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    /* Connect PXx to USARTx_Tx */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_USART1);

    /* Connect PXx to USARTx_Rx */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_USART1);

    /* Configure USART Tx as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /* Configure USART Rx as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    /* Configure the RT pin */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* USART configuration */
    USART_InitStructure.USART_BaudRate = baudrate;//MODBUS_UART_BAUDRATE;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = (port_options & MODBUS_SERIAL_OPTION_1STOPS) ? USART_StopBits_1 : USART_StopBits_2;
    USART_InitStructure.USART_Parity = (port_options & MODBUS_SERIAL_OPTION_PARITY_EVEN) ? USART_Parity_Even : ((port_options & MODBUS_SERIAL_OPTION_PARITY_ODD) ? USART_Parity_Odd : USART_Parity_No);
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(MODBUS_USART, &USART_InitStructure);
    /* Enable the COM1 Transmoit/Receive interrupt: this interrupt is generated when the
      COM1 transmit data register is empty */
    /* NVIC configuration */
    /* Enable the USARTx Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_ITConfig(MODBUS_USART, USART_IT_TC, ENABLE);
    USART_ITConfig(MODBUS_USART, USART_IT_TXE, DISABLE);
    USART_ITConfig(MODBUS_USART, USART_IT_RXNE, ENABLE);
    //USART_ITConfig(MODBUS_USART, USART_IT_LBD, ENABLE);
    /* Set RT pin to receive mode */
    MODBUS_STOP_TRANSMITION();

    /* Enable the TIM6 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM6_DAC_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    /* Enable the TIM7 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    // Setup timer 6
    /* TIM6 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Period = OCR_VALUE_3_5;
    TIM_TimeBaseStructure.TIM_Prescaler = MODBUS_PRESCALER;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM6, &TIM_TimeBaseStructure);
    TIM_ARRPreloadConfig(TIM6, ENABLE);
    TIM_ITConfig(TIM6, TIM_IT_Update, ENABLE);
    // Setup timer 7
    /* TIM7 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Period = OCR_VALUE_1_5;
    TIM_TimeBaseStructure.TIM_Prescaler = MODBUS_PRESCALER;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM7, &TIM_TimeBaseStructure);
    TIM_ARRPreloadConfig(TIM7, ENABLE);
    TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);
    /* TIM6 enable counter */
    TIM_Cmd(TIM6, ENABLE);
    /* TIM7 enable counter */
    TIM_Cmd(TIM7, ENABLE);
    /* Enable USART */
    USART_Cmd(MODBUS_USART, ENABLE);

}

static void     _modbus_hal_reset_timers(void) {
  // If were are pending IRQ - clear
  TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
  TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
  TIM_SetCounter(TIM6, 0);
  TIM_SetCounter(TIM7, 0);
}

/// ModBus driver initialization
void  modbus_slave_init(uint8_t address, uint32_t baudrate, uint8_t port_options) {

  // Save our address
  if(address == 0  || address == 0xFF)
    modbus_handle->address = MODBUS_DEFAULT_ADDRESS;
  else
    modbus_handle->address = address;

  _modbus_hal_init(baudrate, port_options);
}

/// Main-loop polling function
void  modbus_slave_process(void) {
  if(modbus_handle->state != PROCESS)
    return;

  if( modbus_handle->state_rx.data_sz < MODBUS_MIN_PACKET_SZ
     || (modbus_calc_crc((uint8_t*)&modbus_handle->state_rx.packet, modbus_handle->state_rx.data_sz) != 0)
       || !(modbus_handle->state_rx.packet.address == MODBUS_BROADCAST_ADDR || modbus_handle->state_rx.packet.address == modbus_handle->address)) {
      modbus_handle->state = IDLE;
  } else {
    uint8_t data_sz;

    data_sz = modbus_slave_process_msg(&modbus_handle->state_rx.packet, &modbus_handle->state_tx.packet);

    // Where are data to send?
    if((data_sz > 0) && (modbus_handle->state_tx.packet.address != MODBUS_BROADCAST_ADDR)){
      unsigned int crc = modbus_calc_crc((uint8_t*)&modbus_handle->state_tx.packet, data_sz+2 /* include address and function*/);
      modbus_handle->state = TRANSMIT;
      // Assign CRC
      modbus_handle->state_tx.packet.data[data_sz++] = (crc);
      modbus_handle->state_tx.packet.data[data_sz++] = (crc>>8);
      // Clear current index in transmit buffer
      modbus_handle->state_tx.data_index = 0;
      // Set number of bytes in packet include address and function
      modbus_handle->state_tx.data_sz = data_sz+2;
      // Send initial address
      MODBUS_START_TRANSMITION(modbus_handle->state_tx.packet.address);
    } else
      modbus_handle->state = IDLE;
  }
}

unsigned char modbus_slave_process_msg(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint8_t data_sz;

  // Assign address and function for answer
  packet_tx->address = packet_rx->address;
  packet_tx->function = packet_rx->function;

  switch(packet_rx->function) {
      case MODBUS_FUNC_RD_DISCRETE_INPUTS:
        data_sz = modbus_slave_read_inputs(packet_rx, packet_tx);
        break;
      case MODBUS_FUNC_RD_INPUT_REGS:
        data_sz = modbus_slave_read_input_registers(packet_rx, packet_tx);
        break;
      case MODBUS_FUNC_RD_HOLDING_REGS:
        data_sz = modbus_slave_read_holding_registers(packet_rx, packet_tx);
        break;
      case MODBUS_FUNC_WR_SINGLE_REG:
        data_sz = modbus_slave_write_holding_register(packet_rx, packet_tx);
        break;
      case MODBUS_FUNC_WR_REGS:
        data_sz = modbus_slave_write_holding_registers(packet_rx, packet_tx);
        break;
  #ifdef  MODBUS_HAS_RELAYS
      case MODBUS_FUNC_RD_COILS:
        data_sz = modbus_slave_read_coils(packet_rx, packet_tx);
        break;
      case MODBUS_FUNC_WR_SINGLE_COIL:
        data_sz = modbus_write_single_coil(packet_rx, packet_tx);
        break;
      case MODBUS_FUNC_WR_COILS:
        data_sz = modbus_slave_write_coils(packet_rx, packet_tx);
        break;
  #endif //MODBUS_HAS_RELAYS
      default:
        data_sz = modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_FUNCTION);
        break;
      }
  return data_sz;
}


/// Interrupt driver - RX 
void  modbus_slave_rx_interrupt(uint8_t fib) {

  switch(modbus_handle->state)   {
  case IDLE:
    // Skip bytes if we in IDLE
    break;
  case RECEIVE:
    if(modbus_handle->state_rx.data_index >= (MODBUS_PACKET_SZ-1))
      modbus_handle->state = IDLE;
    else
      ((uint8_t*)&modbus_handle->state_rx.packet)[modbus_handle->state_rx.data_index++] = fib;
    break;
  case CHECK_TIMEOUT:
    modbus_handle->state = IDLE;
    break;
  case PROCESS:
    // Something wrong happens...
    break;
  case WAIT_TRANSMIT:
    // Something wrong happens...
    break;
  case TRANSMIT:
    // Checking for collision...
    if(fib != ((uint8_t*)&modbus_handle->state_tx.packet)[modbus_handle->state_tx.data_index])
      modbus_handle->state = IDLE;
    break;
  default:
    modbus_handle->state = IDLE;
    break;
  }
  _modbus_hal_reset_timers();
  //  Clear byte counter
  if(modbus_handle->state == IDLE)
    modbus_handle->state_rx.data_index = 0;
}

/// Interrupt driver - TX 
int  modbus_slave_tx_interrupt(void) {
  int res = -1;

  if(modbus_handle->state != TRANSMIT)
    return res;

  if(++modbus_handle->state_tx.data_index >= modbus_handle->state_tx.data_sz) {
      modbus_handle->state = IDLE;
      modbus_handle->state_tx.data_index = 0;
  } else {
    res = ((uint8_t*)&modbus_handle->state_tx.packet)[modbus_handle->state_tx.data_index];
  }
  _modbus_hal_reset_timers();
  return res;
}

/// IRQ TIMER6 handler - for 3,5T
void modbus_slave_timer_3_5(void)
{
  switch(modbus_handle->state)   {
  case IDLE:
    modbus_handle->state = RECEIVE;
    break;
  case RECEIVE:
    break;
  case CHECK_TIMEOUT:
    modbus_handle->state = (modbus_handle->state_rx.data_index >= MODBUS_MIN_PACKET_SZ) ? PROCESS : IDLE;
    modbus_handle->state_rx.data_sz = modbus_handle->state_rx.data_index;
    modbus_handle->state_rx.data_index = 0;
    break;
  case PROCESS:
    break;
  case WAIT_TRANSMIT:
    break;
  case TRANSMIT:
    break;
  }

}

/// IRQ TIMER6 handler - for 1,5T
void modbus_slave_timer_1_5(void)
{
  switch(modbus_handle->state)   {
  case IDLE:
    break;
  case RECEIVE:
    if(modbus_handle->state_rx.data_index != 0){
        modbus_handle->state = CHECK_TIMEOUT;
    }
    break;
  case CHECK_TIMEOUT:
    break;
  case PROCESS:
    break;
  case WAIT_TRANSMIT:
    break;
  case TRANSMIT:
    break;
  } 
}
/// Send exception in answer
static unsigned char modbus_slave_send_exception(modbus_packet_t*     packet_tx, unsigned char exp) {
  uint8_t data_sz  = 1;
  packet_tx->function |= 0x80;
  packet_tx->data[0] = exp;
  return data_sz;
}
/// Function to generate answer to modbus read input registers command
static unsigned char modbus_slave_read_input_registers(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint16_t      offset =  MODBUS_BYTES2WORD(packet_rx->data[0], packet_rx->data[1]);
  uint16_t      numbers = MODBUS_BYTES2WORD(packet_rx->data[2], packet_rx->data[3]);
  int16_t       value;
  uint8_t      data_sz = 0;
  unsigned      index;

  // Check registers numbers
  if(numbers == 0 || numbers >0x7DU)
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_VALUE);
  // Set number of bytes in answer
  packet_tx->data[data_sz++] = numbers<<1;
  // Filling up answer with registers
  for(index = offset; index < offset+numbers; index++) {
    if(modbus_slave_get_input_register(index, &value) < 0)
      return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
    packet_tx->data[data_sz++] = value>>8;
    packet_tx->data[data_sz++] = value;
  } 
  return data_sz;
}

/// Function to generate answer to modbus read holding registers command
static unsigned char modbus_slave_read_holding_registers(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint16_t      offset =  MODBUS_BYTES2WORD(packet_rx->data[0], packet_rx->data[1]);
  uint16_t      numbers = MODBUS_BYTES2WORD(packet_rx->data[2], packet_rx->data[3]);
  int16_t       value;
  uint8_t       data_sz = 0;
  unsigned      index;

  // Check registers numbers
  if(numbers == 0 || numbers >0x7DU)
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_VALUE);
  // Set number of bytes in answer
  packet_tx->data[data_sz++] = numbers<<1;
#if 1
  // Filling up answer with registers
  for(index = offset; index < offset+numbers; index++) {
    if(modbus_slave_get_holding_register(index, &value) < 0)
      return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
    packet_tx->data[data_sz++] = value>>8;
    packet_tx->data[data_sz++] = value;
  }
#else
  if(modbus_slave_get_holding_registers(offset, numbers, (int16_t*)&(packet_tx->data[data_sz]))  < 0)
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
  data_sz += numbers << 1;
#endif
  return data_sz;
}

/// Function to generate answer to modbus write holding register command
static unsigned char modbus_slave_write_holding_register(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint16_t      offset =  MODBUS_BYTES2WORD(packet_rx->data[0], packet_rx->data[1]);
  int16_t       value =   MODBUS_BYTES2WORD(packet_rx->data[2], packet_rx->data[3]);
  uint8_t       data_sz = 0;

  // Filling up answer with registers
  if(modbus_slave_set_holding_register(offset, value) < 0)
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
  packet_tx->data[data_sz++] = offset>>8;
  packet_tx->data[data_sz++] = offset;
  packet_tx->data[data_sz++] = value>>8;
  packet_tx->data[data_sz++] = value;
  return data_sz;
}

/// Function to generate answer to modbus write multiple registers command
static unsigned char modbus_slave_write_holding_registers(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint16_t      offset =  MODBUS_BYTES2WORD(packet_rx->data[0], packet_rx->data[1]);
  uint16_t      numbers = MODBUS_BYTES2WORD(packet_rx->data[2], packet_rx->data[3]);
  uint8_t       data_sz = packet_rx->data[4];
  int16_t       value;
  unsigned      index;


  // Check registers numbers
  if(numbers == 0 || numbers >0x7DU || data_sz != (numbers <<1))
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_VALUE);
  data_sz = 5;
  // Filling up answer with registers
  for(index = offset; index < offset+numbers; index++) {
    value = MODBUS_BYTES2WORD(packet_rx->data[data_sz+0], packet_rx->data[data_sz+1]);
    data_sz += 2;
    if(modbus_slave_set_holding_register(index, value) < 0)
      return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
  } 
  data_sz = 0;  
  packet_tx->data[data_sz++] = offset>>8;
  packet_tx->data[data_sz++] = offset;
  packet_tx->data[data_sz++] = numbers>>8;
  packet_tx->data[data_sz++] = numbers;
  return data_sz;
}

#ifdef  MODBUS_HAS_RELAYS
/// Function to generate answer to modbus write coil command
static unsigned char modbus_write_single_coil(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint16_t      offset =  MODBUS_BYTES2WORD(packet_rx->data[0], packet_rx->data[1]);
  int16_t       value =   MODBUS_BYTES2WORD(packet_rx->data[2], packet_rx->data[3]);
  uint8_t       data_sz = 0;

  // Filling up answer with registers
  if(modbus_slave_set_coil(offset, value) < 0)
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
  packet_tx->data[data_sz++] = offset>>8;
  packet_tx->data[data_sz++] = offset;
  packet_tx->data[data_sz++] = value>>8;
  packet_tx->data[data_sz++] = value;
  return data_sz;  
}

/// Function to generate answer to modbus read coils command
static unsigned char modbus_slave_read_coils(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint16_t      offset =  MODBUS_BYTES2WORD(packet_rx->data[0], packet_rx->data[1]);
  uint16_t      numbers = MODBUS_BYTES2WORD(packet_rx->data[2], packet_rx->data[3]);
  int16_t       value;
  uint8_t       data_sz = 0;
  uint8_t       bit_mask = 0x01;
  uint8_t       data = 0;
  unsigned      index;

  // Check registers numbers
  if(numbers == 0 || numbers >0x7B0U)
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_VALUE);
  // Set number of bytes in answer
  packet_tx->data[data_sz++] = ((numbers - 1) / 8 + 1);
  // Filling up answer with registers
  for(index = offset; index < offset+numbers; index++) {
    if(modbus_slave_get_coil(index, &value) < 0)
      return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
    if(value)
      data |= bit_mask;
    bit_mask <<= 1;
    if(bit_mask == 0) {
      bit_mask = 0x01;
      packet_tx->data[data_sz++] = data;
      data = 0;
    }
  }
  if(bit_mask != 0x01)
    packet_tx->data[data_sz++] = data;

  return data_sz;
}
///
static unsigned char modbus_slave_read_inputs(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint16_t      offset =  MODBUS_BYTES2WORD(packet_rx->data[0], packet_rx->data[1]);
  uint16_t      numbers = MODBUS_BYTES2WORD(packet_rx->data[2], packet_rx->data[3]);
  int16_t       value;
  uint8_t       data_sz = 0;
  uint8_t       bit_mask = 0x01;
  uint8_t       data = 0;
  unsigned      index;

  // Check registers numbers
  if(numbers == 0 || numbers >0x7D0U)
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_VALUE);
  // Set number of bytes in answer
  packet_tx->data[data_sz++] = ((numbers - 1) / 8 + 1);
  // Filling up answer with registers
  for(index = offset; index < offset+numbers; index++) {
    if(modbus_slave_get_input(index, &value) < 0)
      return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
    if(value)
      data |= bit_mask;
    bit_mask <<= 1;
    if(bit_mask == 0) {
      bit_mask = 0x01;
      packet_tx->data[data_sz++] = data;
      data = 0;
    }
  }
  if(bit_mask != 0x01)
    packet_tx->data[data_sz++] = data;

  return data_sz;
}

///
static unsigned char modbus_slave_write_coils(modbus_packet_t*     packet_rx, modbus_packet_t*     packet_tx) {
  uint16_t      offset =  MODBUS_BYTES2WORD(packet_rx->data[0], packet_rx->data[1]);
  uint16_t      numbers = MODBUS_BYTES2WORD(packet_rx->data[2], packet_rx->data[3]);
  int16_t       value;
  uint8_t       data_index = 5;
  uint8_t       data_sz = 0;
  uint8_t       bit_mask = 0x01;
  unsigned      index;

  // Check registers numbers
  if(numbers == 0 || numbers >0x7B0U)
    return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_VALUE);

  // Filling up answer with registers
  for(index = offset; index < offset+numbers; index++) {
    value = (packet_rx->data[data_index] & bit_mask) ? 0x00FF : 0x0000;
    bit_mask <<= 1;
    if(bit_mask == 0) {
      data_index++;
      bit_mask = 0x01;
    }
    if(modbus_slave_set_coil(index, value) < 0)
      return modbus_slave_send_exception(packet_tx, MODBUS_ILLEGAL_DATA_ADDR);
  }
  packet_tx->data[data_sz++] = offset>>8;
  packet_tx->data[data_sz++] = offset;
  packet_tx->data[data_sz++] = numbers>>8;
  packet_tx->data[data_sz++] = numbers;
  return data_sz;
}
#endif  // MODBUS_HAS_RELAYS
