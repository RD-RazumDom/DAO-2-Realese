/**
  ******************************************************************************
  * @file    main.cpp
  * @author  Dmitry Rudakov
  * @version V1.1.0
  * @date    15-October-2014
  * @brief   Main program body
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdbool.h>
#include <malloc.h>
#include <stdlib.h>
#include "debug.h"

#include "stm32f2xx_conf.h"
#include "stm32f2x7_eth.h"
#include "stm32f2x7_bsp_i2c_ee.h"
#include "stm32f2x7_bsp_rtc.h"
#include "lwipopts.h"
#include "netconf.h"
#include "ethernetif.h"
#include "main.h"
#include "lwip/netif.h"
#include "lwip/sys.h"
#include "lwip/dhcp.h"
#include "bsp_stm32.hpp"
#include "modbus_slave.h"
#include "modbus_tcp_server.h"
#include "console.h"
#include "pt.h"
#include "ff.h"
#include "diskio.h"
#include "tftpserver.h"
#include "string.h"
#include "media.h"
#include "media_buffer.h"
#include "ftp_client.h"
#include "httpd.h"

/* Private define ------------------------------------------------------------*/
#define SYSTEMTICK_PERIOD_MS    10


#define CONFIG_SAVE_PREFIX      (0xAA55U)
#define CONFIG_MAX_ALLOWED_IPS     (10)

#define TIMER_UNCONFIGURE       (200U)
#define TIMER_CONFIGURE         (500U)

#define CONSOLE_UART_BAUDRATE   (115200)
#define CONSOLE_USART           (USART3)
#define CONSOLE_BUFFER_SZ       (128)

/*--------------- Messages ---------------*/
#define MESSAGE1   "      RazumDom      "
#define MESSAGE2   "     ModBus DAO     "
#define MESSAGE3   "                    "
#define MESSAGE4   "      Starting...   "

#define SCR_SAVE_CONFIG         (1)
#define SCR_RESET               (2)
#define SCR_FTP_DOWNLOAD        (3)

#define REVISION_MAIN           (0)
#define REVISION_SUB            (3)
#ifdef NDEBUG
  #define REVISION_DEBUG          (0)
#else
  #define REVISION_DEBUG          (1)
#endif //#ifdef NDEBUG
/// Device type, for each firmware type
/// FIXME
#define DEVICE_TYPE             (0x00D)


#define HTTPD_REQ_OK            "/200.html"
#define HTTPD_REQ_FAIL			NULL

/* Private typedef -----------------------------------------------------------*/

//typedef struct vsd_state_s {
//  uint8_t       status;
//  uint8_t       play_state;
//  uint8_t       play_status;
//  uint8_t       play_file[VSD_FILE_SZ];
//} vsd_state_t;
bool Ain1Dbl;
bool Ain2Dbl;
bool Ain3Dbl;
bool Ain4Dbl;

typedef struct modbus_config_s {
  uint16_t       unit_address;
  uint8_t        serial_baudrate;
  uint8_t        serial_options;
  struct ip_addr ip_addr;
  struct ip_addr ip_mask;
  struct ip_addr ip_gw;
  struct ip_addr allowed_ips[CONFIG_MAX_ALLOWED_IPS];
} modbus_config_t;

#define HTTPD_ACCOUNTS_SZ		(2)
#define HTTPD_USERNAME_SZ		(36)
#define HTTPD_PASSWORD_SZ		(36)

typedef struct httpd_user_auth_s {
	char		name[HTTPD_USERNAME_SZ];
	char		password[HTTPD_PASSWORD_SZ];
}httpd_user_auth_t;

typedef struct httpd_config_s {
	httpd_user_auth_t		users[HTTPD_ACCOUNTS_SZ];
} httpd_config_t;


typedef struct program_config_s {
  uint16_t              prefix;
  modbus_config_t       modbus;
  media_buffer_cfg_t    media;
  ftpc_config_t         ftpc;
  httpd_config_t		httpd;
  //uint8_t                    earspeaker;
  /* Must be last field */
  uint16_t              crc;
} __attribute__((packed)) program_config_t ;

/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/
static __IO uint32_t local_time = 0; /* this variable is used to create a time reference incremented by 10ms */
static uint32_t timing_delay;
/* In memory configuration */
program_config_t        config;

//====================
#define sEE_BACKUP_ADDRESS1        (0x000)
//#define sEE_BACKUP_ADDRESS2        (0x100)
//#define sEE_BACKUP_SIZE            (20 * sizeof(uint32_t))
volatile uint16_t sEE_NumDataReadWrite = 0;

//====================

//static vsd_state_t      vsd_state;

static __IO bool        reset_mcu = false;
static __IO bool        update_backup = false;
static __IO bool        is_eeprom_busy = false;
static bool             is_network_up = false;
static uint32_t         blink_timer = TIMER_UNCONFIGURE;

#define ERROR_FLAG_NONETWORK            (0x0001)
#define ERROR_FLAG_NOSDCARD             (0x0002)
#define ERROR_FLAG_VS1053_NOINIT        (0x0004)

static uint16_t         errors_flags = 0;

static FATFS            _sd_fatfs;
FATFS*                  sd_fatfs = &_sd_fatfs;

static media_handle_t           media_handle;
static media_buffer_handle_t    buffer_handler;

static ftpc_handle_t             ftpc_handle;

static bool                     is_stopped = false;

typedef struct scr_handle_s {
  uint16_t              cmd;
  int16_t               res;
  volatile bool         complete;
  pbuf*                 rx;
  /* Protothreads */
  lc_t                  lc;
} scr_handle_t;

static scr_handle_t     scr_pt = { 0, 0, false, 0 };

BSP::PortA      PortA; // FIXME - due to missing call to static member constructor in template!!!!
BSP::PortB      PortB; // FIXME - due to missing call to static member constructor in template!!!!
BSP::PortC      PortC; // FIXME - due to missing call to static member constructor in template!!!!
BSP::PortE      PortE; // FIXME - due to missing call to static member constructor in template!!!!
BSP::PortD      PortD; // FIXME - due to missing call to static member constructor in template!!!!


BSP::CLed<BSP::CSTM32Pin<BSP::PortE, GPIO_Pin_7>, true> statusLed;
BSP::CInputPin<BSP::CSTM32Pin<BSP::PortA, GPIO_Pin_9>> controlButton;
BSP::CInputPin<BSP::CSTM32Pin<BSP::PortC, GPIO_Pin_0>> AIN1;//if(AIN1.getValue() == false)
BSP::CInputPin<BSP::CSTM32Pin<BSP::PortC, GPIO_Pin_2>> AIN2;
BSP::CInputPin<BSP::CSTM32Pin<BSP::PortC, GPIO_Pin_3>> AIN3;
BSP::CInputPin<BSP::CSTM32Pin<BSP::PortA, GPIO_Pin_0>> AIN4;
BSP::COutputPin<BSP::CSTM32Pin<BSP::PortD, GPIO_Pin_4>> relayMP3;

/*BSP::CLed<BSP::CSTM32Pin<BSP::PortC, GPIO_Pin_7>, true> statusLed;
BSP::CInputPin<BSP::CSTM32Pin<BSP::PortC, GPIO_Pin_6>> controlButton;
*/

/* Private function prototypes -----------------------------------------------*/
static void systick_init(void);
static void config_read(void);
static void config_process(void);
static void network_init(bool use_default);
static void network_process(void);
static int _console_hal_init(void);
static int _console_getchar(void);
static uint32_t _get_baudrate(uint8_t baudrate);

extern "C" {
  int _console_putchar(int ch);
  const char* parse_ip(const char* str, struct ip_addr* ip_addr);
  uint16_t mySSIHandler(int iIndex, char *pcInsert, int iInsertLen);
}

static int help_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]);
static int netstat_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]);
static int fat_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]);
static int date_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]);
static int mem_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]);
static int mp3_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]);
static int ftpc_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]);


static int scr_process(scr_handle_t* pt);
extern "C" {
  static err_t src_ftpc_cb_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err);
  static void src_ftpc_cb_error(void * arg, err_t err);
}

static void    debug_dump_memory(uint8_t* buf, int sz);
/* Private functions ---------------------------------------------------------*/



/* Private classes   ---------------------------------------------------------*/
console_func_desc_t     usart_func_desc[] = {
    {"help", &help_cmd, "Usage: help <some command>"},
    {"netstat", &netstat_cmd, "Usage: netstat"},
    {"mount", &fat_cmd, "Usage: mount <path>"},
    {"umount", &fat_cmd, "Usage: umount <path>"},
    {"ls", &fat_cmd, "Usage: ls"},
    {"cd", &fat_cmd, "Usage: cd <path>"},
    {"rm", &fat_cmd, "Usage: rm <path>"},
    {"date", &date_cmd, "Usage: date <new date>"},
    {"mem", &mem_cmd, "Usage: mem"},
    {"mp3", &mp3_cmd, "Usage: mp3 <cmd> <param>"},
    {"ftpc", &ftpc_cmd, "Usage: ftpc <command> <param>"},
    /* Last entry */
    { NULL, NULL, NULL }
};
static char             usart_console_buffer_in[CONSOLE_BUFFER_SZ];

static console_handle_t usart_console = {
    CONSOLE_NONE,
    usart_func_desc,
    usart_console_buffer_in,
    CONSOLE_BUFFER_SZ,
    &_console_hal_init,
    &_console_getchar,
    &_console_putchar
};

static const char *CGIPlayHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]);
static const char *CGIStopHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]);
static const char *CGIPauseHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]);
static const char *CGIVolumeHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]);
static const char *CGIAuthChangeHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]);

static const tCGI myCGIs[] = {
    { "/play.cgi", CGIPlayHandler },
    { "/pause.cgi", CGIPauseHandler },
    { "/stop.cgi", CGIStopHandler },
    { "/volume.cgi", CGIVolumeHandler },
	{ "/authchange.cgi", CGIAuthChangeHandler },
};

static const char* mySSITags[] = {
    // Max string length is LWIP_HTTPD_MAX_TAG_NAME_LEN bytes
    "FW_REV",           //0 0.02
    "MD_STATE_N",       //1 0...N
    "MD_STATE_S",       //2 STOPED...
    "MD_SRC_N",         //3 0...N
    "MD_SRC_S",         //4 SD...
    "MD_SRC_DIR",       //5
    "MD_SRC_FILE",      //6
    "MD_STATUS_S",      //7
    "MD_VOLUME",        //8
    "MD_SRC_URL",       //9
	"MD_SD_LIST",		//10
	"MD_MODE_N",		//11
	"MD_MODE_S",		//12
	"HT_USR0",			//13
	"HT_PWD0",			//14
	"HT_USR1",			//15
	"HT_PWD1"			//16
};

static const char* md_states_strings[] = { "STOPED", "PLAYING", "PAUSED", "INITIALIZED", "FAILURE", "NONE" };
static const char* md_sources_strings[] = { "SD", "FTP", "RTS", "NONE" };
static const char* md_modes_strings[] = {"SINGLE", "REPEAT"};

uint16_t mySSIHandler(int iIndex, char *pcInsert, int iInsertLen
#if LWIP_HTTPD_SSI_MULTIPART
        , u16_t current_tag_part, u16_t *next_tag_part
#endif /* LWIP_HTTPD_SSI_MULTIPART */
		) {
  uint16_t      res =0;
  const char*         tmp;
  const char*         tmp2;

  switch(iIndex) {
  case 0:
    res = snprintf(pcInsert, iInsertLen, "%d.%02d", REVISION_MAIN, REVISION_SUB);
    break;
  case 1:
    res = snprintf(pcInsert, iInsertLen, "%d", media_get_state(buffer_handler.hnd));
    break;
  case 2:
    assert(media_get_state(buffer_handler.hnd) < sizeof(md_states_strings)/sizeof(md_states_strings[0]));
    res = snprintf(pcInsert, iInsertLen, "%s", md_states_strings[media_get_state(buffer_handler.hnd)]);
    break;
  case 3:
    res = snprintf(pcInsert, iInsertLen, "%d", config.media.source);
    break;
  case 4:
    assert(config.media.source < sizeof(md_sources_strings)/sizeof(md_sources_strings[0]));
    res = snprintf(pcInsert, iInsertLen, "%s", md_sources_strings[config.media.source]);
    break;
  case 5:
    res = snprintf(pcInsert, iInsertLen, "%s", config.media.source_dir);
    break;
  case 6:
    res = snprintf(pcInsert, iInsertLen, "%s", buffer_handler.filename);
    break;
  case 7:
    assert(media_get_state(buffer_handler.hnd) < sizeof(md_states_strings)/sizeof(md_states_strings[0]));
    assert(config.media.source < sizeof(md_sources_strings)/sizeof(md_sources_strings[0]));
    assert(config.media.play_mode < sizeof(md_modes_strings)/sizeof(md_modes_strings[0]));
    if((config.media.source == MEDIA_SRC_NONE) || (config.media.source == MEDIA_SRC_SD)) {
      tmp = "";
    } else {
      tmp = config.media.source_dir;
    }
    if((config.media.source == MEDIA_SRC_FTP) || (config.media.source == MEDIA_SRC_SD)) {
      tmp2 = buffer_handler.filename;
    } else {
      tmp2 = "";
    }
    res = snprintf(pcInsert, iInsertLen, "[%s - %s] %s %s%s",
    		md_states_strings[media_get_state(buffer_handler.hnd)], md_modes_strings[config.media.play_mode],
				md_sources_strings[config.media.source], tmp, tmp2);
    break;
  case 8:
    res = snprintf(pcInsert, iInsertLen, "%d", media_get_volume(buffer_handler.hnd));
    break;
  case 9:
    switch(config.media.source) {
    case MEDIA_SRC_FTP:
      res = snprintf(pcInsert, iInsertLen, "ftp://%d.%d.%d.%d/%s",
          (uint8_t)(config.ftpc.ip_addr.addr),  (uint8_t)(config.ftpc.ip_addr.addr>>8), (uint8_t)(config.ftpc.ip_addr.addr >> 16),  (uint8_t)(config.ftpc.ip_addr.addr>>24),
            config.media.source_dir);
      break;
    case MEDIA_SRC_RTS:
      res = snprintf(pcInsert, iInsertLen, "rts://%s", config.media.source_dir);
      break;
    case MEDIA_SRC_SD:
      res = snprintf(pcInsert, iInsertLen, "sd://%s", buffer_handler.filename);
      break;
    case MEDIA_SRC_NONE:
    default:
      break;
    }
    break;
  case 10:
#if LWIP_HTTPD_SSI_MULTIPART
	  if(1) {
		DIR 		dir;
		FILINFO		finfo;
		int 		err = f_opendir(&dir, "/");
		uint16_t	index = 0;

//		err = (err == FR_OK) ? f_readdir(&dir, NULL) : err;
		err = (err == FR_OK) ? f_readdir(&dir, &finfo) : err;

		while(err == FR_OK) {
			if (finfo.fname[0]) {
				if(index >= current_tag_part) {
					if((finfo.fattrib & AM_DIR) == 0) {
						int rest 	= iInsertLen - res;
						int req_len = snprintf(&pcInsert[res], rest, "\"%s\",", finfo.fname);

						if(req_len >= rest)
							break;
						res += req_len;
					}
					*next_tag_part = ++index;
				}
			} else {
				break;
			}
			err = f_readdir(&dir, &finfo);
		}
	  }
#endif //#LWIP_HTTPD_SSI_MULTIPART
   	break;
  case 11:
    res = snprintf(pcInsert, iInsertLen, "%d", config.media.play_mode);
    break;
  case 12:
    assert(config.media.play_mode < sizeof(md_modes_strings)/sizeof(md_modes_strings[0]));
    res = snprintf(pcInsert, iInsertLen, "%s", md_modes_strings[config.media.play_mode]);
    break;
  case 13:
    res = snprintf(pcInsert, iInsertLen, "%s", config.httpd.users[0].name);
    break;
  case 14:
    res = snprintf(pcInsert, iInsertLen, "%s", config.httpd.users[0].password);
    break;
  case 15:
    res = snprintf(pcInsert, iInsertLen, "%s", config.httpd.users[1].name);
    break;
  case 16:
    res = snprintf(pcInsert, iInsertLen, "%s", config.httpd.users[1].password);
    break;
  default:
    break;
  }
  return res;
}


/*

const station_names station1 = { "http://tuner.hit104.de:80"        , "Hit FM 104"       };   // hit104.de 80.237.210.79
const station_names station2 = { "http://tuner.classical102.com:80" , "Classical 102"    };   // classical102.com
const station_names station3 = { "http://errorfm.com:8002"          , "errorFM Music"    };   // errorfm.com

*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{
  /*!< At this stage the microcontroller clock setting is already configured,
       this is done through SystemInit() function which is called from
       startup file (startup_stm32f2xx.s) before to branch to application main.
       To reconfigure the default setting of SystemInit() function, refer to
       system_stm32f2xx.c file
     */

  /* Check if the system has resumed from IWDG reset */
//  if (RCC_GetFlagStatus(RCC_FLAG_IWDGRST) != RESET)
//  {
    /* IWDGRST flag set */

    /* Clear reset flags */
//    RCC_ClearFlag();
//  }
#ifdef NDEBUG
  /* Enable write access to IWDG_PR and IWDG_RLR registers */
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
  /* IWDG counter clock: LSI/32 */
  IWDG_SetPrescaler(IWDG_Prescaler_32);

  IWDG_SetReload(2500); //1500ms
  /* Reload IWDG counter */
  IWDG_ReloadCounter();
  /* Enable IWDG (the LSI oscillator will be enabled by hardware) */
  IWDG_Enable();
#endif

  relayMP3.setValue(true);//(false)
  /* Initialize debug environment */
  debug_init();
  debug_puts(MESSAGE1);
  debug_puts(MESSAGE2);
  debug_puts(MESSAGE3);

  SystemCoreClockUpdate();
  debug_printf("System clock: %uHz\n", SystemCoreClock);
  /* Indicate the end of initialization */
  statusLed.setValue(true);
  /* Reload IWDG counter */
  IWDG_ReloadCounter();
  /* System timer */
  systick_init();
  /* RTC */
  RTC_Config();
  /* Initialize the I2C EEPROM driver */
  sEE_Init();
  /* Read the configuration from RTC backup registers or from EEPROM */
  config_read();
  /* Network initialization */
  network_init(controlButton.getValue() == false);
  /* Initialize Modbus slave on RTU */

  modbus_slave_init(config.modbus.unit_address,_get_baudrate(config.modbus.serial_baudrate), config.modbus.serial_options);
  /* Initialize Modbus slave on TCP */
  modbus_tcp_server_init(config.modbus.unit_address);
  /* Reload IWDG counter */
  IWDG_ReloadCounter();
  /* Indicate the loop */
  debug_puts(MESSAGE4);
  /* Console */
  console_init(&usart_console);
  /* Enable write access to IWDG_PR and IWDG_RLR registers */
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
#ifndef NDEBUG
  IWDG_SetReload(500); //400...540ms
#else
  IWDG_SetReload(250); //200...250ms
#endif //#ifndef NDEBUG

  /* Mount file system on SD card */
  if(f_mount(sd_fatfs, "0:", 1) != FR_OK) {
      errors_flags |= ERROR_FLAG_NOSDCARD;
      debug_puts("Failed to mount sd-card!");
  }
  /* TFTP server initialization */
  tftpd_init();

  /* FTP client */
  ftpc_init(&ftpc_handle, &config.ftpc);

  /* HTTPD */
  http_set_ssi_handler(mySSIHandler, mySSITags, sizeof(mySSITags)/sizeof(mySSITags[0]));
  http_set_cgi_handlers(myCGIs, sizeof(myCGIs)/sizeof(myCGIs[0]));
  httpd_init();

  /* Media subsystem */
  if(media_init(&media_handle) != MEDIA_OK) {
      errors_flags |= ERROR_FLAG_VS1053_NOINIT;
      debug_puts("Failed to initialize media server");
  }

  media_buffer_init(&buffer_handler, &media_handle, &ftpc_handle);
  /* SCR thread initialization*/
  PT_INIT(&scr_pt);

  /* Infinite loop */
  while (1)
  {
    /* Reload IWDG counter */
    if((reset_mcu == false) || (update_backup == true))
      IWDG_ReloadCounter();
    /* Turn On-Off  amplifier */
    relayMP3.setValue(media_handle.state != MEDIA_PLAYING);
    /* Networks */
    network_process();
    /* Modbus RTU slave */
    modbus_slave_process();
    /* System Control Register */
    scr_process(&scr_pt);
    /* Configuration */
    config_process();
    /* Console on USART */
    console_process(&usart_console);
    /* Media server */
    media_process(&media_handle);
    /* Buffer processing */
    media_buffer_process(&buffer_handler);
    /* FTP client */
    ftpc_process(&ftpc_handle);
    int16_t get_coil;

    modbus_slave_get_coil(1, &get_coil);
    if((AIN1.getValue() == false)&&(Ain1Dbl==false)){
    	Ain1Dbl=true;
    	if(!get_coil) modbus_slave_set_coil(1, 1);
    	else          modbus_slave_set_coil(1, 0);
    }else if((AIN1.getValue() == true)){
    	Ain1Dbl=false;
    }

    modbus_slave_get_coil(2, &get_coil);
    if((AIN2.getValue() == false)&&(Ain2Dbl==false)){
    	Ain2Dbl=true;
    	if(!get_coil) modbus_slave_set_coil(2, 1);
    	else          modbus_slave_set_coil(2, 0);
    }else if((AIN2.getValue() == true)){
    	Ain2Dbl=false;
    }

    modbus_slave_get_coil(3, &get_coil);
    if((AIN3.getValue() == false)&&(Ain3Dbl==false)){
    	Ain3Dbl=true;
    	if(!get_coil) modbus_slave_set_coil(3, 1);
    	else    	  modbus_slave_set_coil(3, 0);
    }else if((AIN3.getValue() == true)){
    	Ain3Dbl=false;
    }

    modbus_slave_get_coil(4, &get_coil);
    if((AIN4.getValue() == false)&&(Ain4Dbl==false)){
    	Ain4Dbl=true;
    	if(!get_coil) modbus_slave_set_coil(4, 1);
    	else       	  modbus_slave_set_coil(4, 0);
    }else if((AIN4.getValue() == true)){
    	Ain4Dbl=false;
    }
    /* Media repeat subsystem*/
    if(media_get_state(&media_handle) == MEDIA_STOPED) {
        if(buffer_handler.error != 0)
          is_stopped = true;
        if((is_stopped == false) && (config.media.play_mode == MEDIA_MODE_REPEAT)) {
            media_buffer_open(&buffer_handler, &config.media, buffer_handler.filename);
            media_exec_cmd(&media_handle, MEDIA_CMD_PLAY);
        } else {
            is_stopped = true;
        }
    }

  }
}

/**
  * @brief  Inserts a delay time.
  * @param  nCount: number of 10ms periods to wait for.
  * @retval None
  */
void delay(uint32_t wait_ms)
{
  /* Capture the current local time */
  timing_delay = local_time + wait_ms;

  /* wait until the desired delay finish */
  while(timing_delay > local_time)
  {
      /* Reload IWDG counter */
      IWDG_ReloadCounter();
  }
}

/**
  * @brief  Updates the system local time
  * @param  None
  * @retval None
  */
void time_update(void)
{
  local_time += SYSTEMTICK_PERIOD_MS;
}

u32_t sys_now(void) {
  return  local_time;
}


/**
  * @brief  Setup timer
  * @param  None
  * @retval None
  */
static void systick_init(void) {
  RCC_ClocksTypeDef RCC_Clocks;
  /* Configure Systick clock source as HCLK */
  SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);

  /* SystTick configuration: an interrupt every 10ms */
  RCC_GetClocksFreq(&RCC_Clocks);
  SysTick_Config(RCC_Clocks.HCLK_Frequency / 100);

}

/**
  * @brief  Set memory configuration
  * @param  None
  * @retval None
  */
static void config_assign_variables(void) {
  /// TODO
  if(config.modbus.unit_address > 0x00FFU)
    config.modbus.unit_address = MODBUS_DEFAULT_ADDRESS;
  //memset(&vsd_state, 0, sizeof(vsd_state));
}


#define HTTPD_DEF_USER0_NAME		"admin"
#define HTTPD_DEF_USER0_PASSWORD	"admin"
#define HTTPD_DEF_USER1_NAME		"user"
#define HTTPD_DEF_USER1_PASSWORD	"user"


/**
  * @brief  Set default memory configuration
  * @param  None
  * @retval None
  */
static void config_assign_variables_default(void) {

  memset(&config, 0, sizeof(config));

  config.prefix                 = CONFIG_SAVE_PREFIX;
  config.modbus.unit_address    = MODBUS_DEFAULT_ADDRESS;

  IP4_ADDR(&config.modbus.ip_addr, IP_ADDR0, IP_ADDR1, IP_ADDR2, IP_ADDR3);
  IP4_ADDR(&config.modbus.ip_mask, NETMASK_ADDR0, NETMASK_ADDR1, NETMASK_ADDR2, NETMASK_ADDR3);
  IP4_ADDR(&config.modbus.ip_gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
  // Allow access for any device in same subnet
  IP4_ADDR(&config.modbus.allowed_ips[0], IP_ADDR0, IP_ADDR1, IP_ADDR2, 255);
  // Set default users and passwords
  memcpy(config.httpd.users[0].name, HTTPD_DEF_USER0_NAME, sizeof(HTTPD_DEF_USER0_NAME));
  memcpy(config.httpd.users[0].password, HTTPD_DEF_USER0_PASSWORD, sizeof(HTTPD_DEF_USER0_PASSWORD));
  memcpy(config.httpd.users[1].name, HTTPD_DEF_USER1_NAME, sizeof(HTTPD_DEF_USER1_NAME));
  memcpy(config.httpd.users[1].password, HTTPD_DEF_USER1_PASSWORD, sizeof(HTTPD_DEF_USER1_PASSWORD));

}


/**
  * @brief  Read configuration
  * @param  None
  * @retval None
  */
static void config_read(void) {
  /* Check for valid configuration in RAM */
  if(config.prefix != CONFIG_SAVE_PREFIX) {
      // Trying to read configuration from EEPROM
      debug_puts("config: RAM is empty!");
      /* Set the Number of data to be read - All configuration */
      sEE_NumDataReadWrite = sizeof(config);
      /* Read from I2C EEPROM from sEE_BACKUP_ADDRESS1 */
      sEE_ReadBuffer((uint8_t*)&config, sEE_BACKUP_ADDRESS1, (uint16_t *)(&sEE_NumDataReadWrite));
      /* Wait for EEPROM reading... */
      while(sEE_NumDataReadWrite != 0) {
          /* Reload IWDG counter */
          IWDG_ReloadCounter();
      }
      if(modbus_calc_crc((uint8_t*)&config, sizeof(config) - sizeof(config.crc)) != config.crc) {
          debug_puts("config: Configuration in the EEPROM is corrupted!");
          config_assign_variables_default();
          update_backup = true;
      }
  }
  config_assign_variables();
}

/**
  * @brief  Set network parameters
  * @param  ipaddr - Device IPv4 address
  * @param  ipmask - Device IPv4 mask
  * @param  ipgw -   Device IPv4 gateway
  * @retval None
  * @note   After call, this function will sets reset to reset MCU after a short timeout
  */
void config_set_network(struct ip_addr* ipaddr,  struct ip_addr* ipmask, struct ip_addr* ipgw)  {
  config.modbus.ip_addr = *ipaddr;
  config.modbus.ip_mask = *ipmask;
  config.modbus.ip_gw = *ipgw;
  /* Update EEPROM */
  update_backup = true;
  /* Reset MCU after a while */
  reset_mcu  = true;
}

/**
  * @brief  Get network parameters
  * @param  ipaddr - Device IPv4 address
  * @param  ipmask - Device IPv4 mask
  * @param  ipgw -   Device IPv4 gateway
  * @retval None
  */
void config_get_network(struct ip_addr* ipaddr,  struct ip_addr* ipmask, struct ip_addr* ipgw)  {
  *ipaddr = config.modbus.ip_addr;
  *ipmask = config.modbus.ip_mask;
  *ipgw = config.modbus.ip_gw;
}

/**
  * @brief  Get an IPv4 address which allows use Modbus
  * @param  None
  * @retval None
  */
int config_get_allow_ip(struct ip_addr* ipaddr, unsigned index) {
  if(index >= CONFIG_MAX_ALLOWED_IPS)
    return 0;
  *ipaddr = config.modbus.allowed_ips[index];
  return 1;
}

/**
  * @brief  Set an IPv4 address which allows use Modbus
  * @param  None
  * @retval None
  */
int config_set_allow_ip(struct ip_addr* ipaddr, unsigned index) {
  if(index >= CONFIG_MAX_ALLOWED_IPS)
    return 0;
  config.modbus.allowed_ips[index] = *ipaddr;
  /* Update EEPROM */
  update_backup = true;
  return 1;
}

/**
  * @brief  Get device status
  * @param  None
  * @retval Device status
  */
uint16_t        get_device_status(void) {
  return 0;
}

/**
  * @brief  Example of timeout situation management.
  * @param  None.
  * @retval None.
  */
uint32_t sEE_TIMEOUT_UserCallback(void)
{
  /* Use application may try to recover the communication by resetting I2C
    peripheral (calling the function I2C_SoftwareResetCmd()) then restart
    the transmission/reception from a previously stored recover point.
    For simplicity reasons, this example only shows a basic way for errors
    managements which consists of stopping all the process and requiring system
    reset. */

  /* Block communication and all processes */
  while (1)
  {
  }
  return 0;
}

/**
  * @brief  Check current configuration setting and update it into EEPROM if is necessary.
  * @param  None.
  * @retval None.
  */
static void config_process(void) {
  static enum { IDLE, START_WRITE, WAIT_WRITE } state = IDLE;
  uint16_t crc;

  /// FIXME Rewrite to read from the EEPROM by blocks and check with RAM

  switch(state) {
  case IDLE:
    if(update_backup == false)
      break;
    state = START_WRITE;
    is_eeprom_busy = true;
  case START_WRITE:
    update_backup = false;
    crc =  modbus_calc_crc((uint8_t*)&config, sizeof(config) - sizeof(config.crc));
    if(config.crc != crc) {
        config.crc = crc;
        sEE_WriteBuffer((uint8_t*)&config, sEE_BACKUP_ADDRESS1, sizeof(config));
    }
    state = WAIT_WRITE;
    break;
  case WAIT_WRITE:
    /// TODO
    state = (update_backup == false) ? IDLE : START_WRITE;
    is_eeprom_busy = update_backup;
    break;
  }
}
/**
  * @brief  Network initialization.
  * @param  None.
  * @retval None.
  */
static void network_init(bool use_default) {
  struct ip_addr ip_addr;
  struct ip_addr ip_mask;
  struct ip_addr ip_gw;

  /* configure Ethernet */
  ETH_BSP_Config();
  /* Reload IWDG counter */
  IWDG_ReloadCounter();
  /* Initialize the LwIP stack */
  if(use_default == false){
    /* If button is not pressed then use saved network configuration */
    config_get_network(&ip_addr, &ip_mask, &ip_gw);
  } else {
    /* If button is  pressed then use default network configuration */
    IP4_ADDR(&ip_addr, IP_ADDR0, IP_ADDR1, IP_ADDR2, IP_ADDR3);
    IP4_ADDR(&ip_mask, NETMASK_ADDR0, NETMASK_ADDR1, NETMASK_ADDR2, NETMASK_ADDR3);
    IP4_ADDR(&ip_gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
    config_set_network(&ip_addr, &ip_mask, &ip_gw);
  }

  netconf_init(&ip_addr, &ip_mask, &ip_gw);
}

/**
  * @brief  Handle network runtimes.
  * @param  None.
  * @retval None.
  */
static void network_process(void) {
  static uint32_t link_timer = 0;

  /* Check network state */
  uint16_t phy_status;
  if (local_time - link_timer >= 500U)
  {
      link_timer =  local_time;
      phy_status = ETH_ReadPHYRegister(PHY_ADDRESS, PHY_BSR);
      is_network_up = ((phy_status & PHY_Linked_Status) != 0);
  }

  if(is_network_up == false) {
      if(((phy_status = ETH_ReadPHYRegister(PHY_ADDRESS, PHY_BCR)) & PHY_Restart_AutoNegotiation) == 0U ) {
          ETH_WritePHYRegister(PHY_ADDRESS, PHY_BCR, PHY_Restart_AutoNegotiation);
      }
  }

  if(netif_is_link_up(&eth0) && (is_network_up == false)) {
      errors_flags |= ERROR_FLAG_NONETWORK;
      netif_set_link_down(&eth0);
      debug_puts("Down");
  } else if((netif_is_link_up(&eth0) == 0) && (is_network_up == true)) {
      if(ETH_BSP_Config() == ETH_SUCCESS) {
        errors_flags &= (uint16_t)~ERROR_FLAG_NONETWORK;
        ethernetif_init(&eth0);
        netif_set_link_up(&eth0);
        debug_puts("Up");
      }
  }

  /* check if any packet received */
  while (ETH_CheckFrameReceived())
  {
    /* process received Ethernet packet */
    netconf_pkt_handle();
  }
  /* handle periodic timers for LwIP */
  netconf_periodic_handle(local_time);

  /* Blink by LED after network is initialized */
  if((local_time - blink_timer) > ((is_network_up == true) ? TIMER_CONFIGURE : TIMER_UNCONFIGURE)) {
      blink_timer = local_time;
      statusLed.setValue(statusLed.getValue());
  }

}

int  modbus_slave_get_input_register(uint16_t index, int16_t* value) {
  switch(index) {
  case 9000:
      *value = REVISION_MAIN;
      break;
    case 9001:
      *value = REVISION_SUB;
      break;
    case 9002:
      *value = REVISION_DEBUG;
      break;
    case 9003:
      *value = DEVICE_TYPE;
      break;
    default:
      *value = 0;
      return 0;
  }
  return 0;
}

int  modbus_slave_get_holding_register(uint16_t index, int16_t* value) {
  if(index < sizeof(config.modbus)/sizeof(int16_t)) {                       /* Fields in  uint16_t*/
    *value = ((int16_t*)&config.modbus)[index];
  }else if((index >= 100) && (index < (100 + 16))){      /* Fields in  uint8_t*/
      if(index == 101)
        *value = (int16_t)media_get_state(&media_handle);
      else if(index == 102)
        *value = (int16_t)buffer_handler.error;
      else if(index >= 103 && index < (103+13))
        *value = (int16_t)buffer_handler.filename[index-103];
      else
        *value = 0;
  }else if(index == 120) {
      *value = scr_pt.cmd;
  }else if(index == 121) {
      *value = scr_pt.res;
  }else if(index == 122) {//SB_FREQLIMIT 3:0 Lower limit frequency in 10 Hz steps (2..15)
      *value = media_get_bass_control(&media_handle)&0x000F;
  }else if(index == 123) {//SB_AMPLITUDE 7:4 Bass Enhancement in 1 dB steps (0..15, 0 = off)
      *value = (media_get_bass_control(&media_handle)>>4)&0x000F;
  }else if(index == 124) {//ST_FREQLIMIT 11:8 Lower limit frequency in 1000 Hz steps (1..15)
      *value = (media_get_bass_control(&media_handle)>>8)&0x000F;
  }else if(index == 125) {//ST_AMPLITUDE 15:12 Treble Control in 1.5 dB steps (-8..7, 0 = off)
      *value = (media_get_bass_control(&media_handle)>>12)&0x000F;
  }else if(index == 126) {     // Volume
     *value = media_get_volume(&media_handle);
     //media_set_earspeaker(&media_handle, control);
  }else if(index == 127) {     //earspeaker
     *value = ((media_get_earspeaker(&media_handle)>>4)&1) | ((media_get_earspeaker(&media_handle)>>6)&2);
  } else if((index >= 200) && (index < (200 + sizeof(config.media)/sizeof(uint8_t)))){     /* Fields in  uint8_t*/
      index -= 200;
      *value = ((uint8_t*)&config.media)[index];
  }else if((index >= 400) && (index < 402)){    /* Fields in  uint16_t*/
      index -= 400;
      *value = ((uint16_t*)&config.ftpc.ip_addr)[index];
  }else if((index >= 402) && (index < (402 + FTPC_USER_SZ + FTPC_PASS_SZ))){    /* Fields in  uint8_t*/
      index -= 402;
      *value = ((uint8_t*)config.ftpc.user)[index];
  }
  else {
    *value = 0;
    return 0;
  }
  return 1;
}

int  modbus_slave_set_holding_register(uint16_t index, int16_t value) {
  if(index < sizeof(config.modbus)/sizeof(int16_t)) {                                       /* Fields in  uint16_t*/
    ((int16_t*)&config.modbus)[index] = value;
    update_backup = true;/* Update EEPROM */
  } else if((index >= 100) && (index < (100 + 16))){      /* Fields in  uint8_t*/
      if(index == 101) {
    	media_state_t md_state = media_get_state(&media_handle);
        switch(value) {
        case MEDIA_CMD_PLAY:
            is_stopped = false;
            if((md_state != MEDIA_FAILURE) && (md_state != MEDIA_NONE) && (md_state != MEDIA_PAUSED))
              media_buffer_open(&buffer_handler, &config.media, (config.media.source == MEDIA_SRC_RTS) ?  NULL : buffer_handler.filename);
            break;
        case MEDIA_CMD_STOP:
          is_stopped = true;
        case MEDIA_CMD_PAUSE:
        default:
          break;
        }
        media_exec_cmd(&media_handle, (media_cmd_t)value);
        if(value == MEDIA_CMD_STOP)
            media_buffer_close(&buffer_handler);
      } else if(index >= 103 && index < (103+13)) {
        buffer_handler.filename[index-103] = value;
      } else {

      }
  } else if(index == 120) {
      scr_pt.cmd = value;
  } else if(index == 122) { //SB_FREQLIMIT 3:0 Lower limit frequency in 10 Hz steps (2..15)
	  uint16_t control = media_get_bass_control(&media_handle);
	  control = (control & 0xFFF0) | (value & 0x000FU);
	  media_set_bass_control(&media_handle, control);
  } else if(index == 123) { //SB_AMPLITUDE 7:4 Bass Enhancement in 1 dB steps (0..15, 0 = off)
	  uint16_t control = media_get_bass_control(&media_handle);
	  control = (control & 0xFF0F) | ((value& 0x0F) << 4);
	  media_set_bass_control(&media_handle, control);
  } else if(index == 124) { //ST_FREQLIMIT 11:8 Lower limit frequency in 1000 Hz steps (1..15)
	  uint16_t control = media_get_bass_control(&media_handle);
	  control = (control & 0xF0FF) | ((value& 0x0F) << 8);
	  media_set_bass_control(&media_handle, control);
  } else if(index == 125) { //ST_AMPLITUDE 15:12 Treble Control in 1.5 dB steps (-8..7, 0 = off)
	  uint16_t control = media_get_bass_control(&media_handle);
	  control = (control & 0x0FFF) | ((value& 0x0F) << 12);
	  media_set_bass_control(&media_handle, control);
  } else if(index == 126) {     // Volume
      if(value < 0) value = 0;
      if(value >= UINT8_MAX) value = 0xFE;
      media_set_volume(&media_handle, value);
      //update_backup = true;/* Update EEPROM */
  } else if(index == 127) { //EARSPEAKER
	  uint16_t control = ((value&1)?0x10:0) |((value&2)?0x80:0); //(value&1)0x10:0 |(value&2)0x80:0
	  media_set_earspeaker(&media_handle, control);
  } else if((index >= 200) && (index < (200 + sizeof(config.media)/sizeof(uint8_t)))){    /* Fields in  uint8_t*/
      index -= 200;
      ((uint8_t*)&config.media)[index] = value;
  } else if((index >= 400) && (index < 402)){    /* Fields in  uint16_t*/
      index -= 400;
      ((uint16_t*)&config.ftpc.ip_addr)[index] = value;
  }else if((index >= 402) && (index < (402 + FTPC_USER_SZ + FTPC_PASS_SZ))){    /* Fields in  uint8_t*/
      index -= 402;
      ((uint8_t*)config.ftpc.user)[index] = value;
  }
  else {
      return -1;
  }
  //update_backup = true;
  return 1;
}

int  modbus_slave_set_coil(uint16_t index, int16_t value) {
  bool val = (value != 0);
  char  filename[MEDIA_FILE_SZ];

  snprintf(filename, sizeof(filename), "%d.mp3", index);

  media_exec_cmd(&media_handle, MEDIA_CMD_STOP);
  media_buffer_close(&buffer_handler);
  is_stopped = true;

  if(val == true) {
    if(media_buffer_open(&buffer_handler, &config.media, filename) != MEDIA_OK)
      return -1;
    is_stopped = false;
    media_exec_cmd(&media_handle, MEDIA_CMD_PLAY);
  }
  return 0;
}

int  modbus_slave_get_coil(uint16_t index, int16_t* value) {
  bool val = false;
  bool the_same;
  char  filename[MEDIA_FILE_SZ];

  snprintf(filename, sizeof(filename), "%d.mp3", index);

  the_same = (strncmp(filename, buffer_handler.filename, sizeof(filename)) == 0);

  if(the_same == true) {
      val = (media_get_state(&media_handle) == MEDIA_PLAYING);
  }

  *value = (val) ? 0x0001 : 0x0000;
  return 0;
}


int  modbus_slave_get_input(uint16_t index, int16_t* value) {
  bool val = false;
  *value = (val) ? 0x0001 : 0x0000;
  return 0;
}



static int _console_hal_init(void) {
//  NVIC_InitTypeDef NVIC_InitStructure;
  USART_InitTypeDef USART_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  /* Enable GPIO clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

  /* Enable UART clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

  /* Connect PXx to USARTx_Tx */
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_USART3);

  /* Connect PXx to USARTx_Rx */
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_USART3);

  /* Configure USART Tx as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_Init(GPIOD, &GPIO_InitStructure);

  /* Configure USART Rx as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_Init(GPIOD, &GPIO_InitStructure);

  /* USART configuration */
  USART_InitStructure.USART_BaudRate = CONSOLE_UART_BAUDRATE;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(CONSOLE_USART, &USART_InitStructure);
  /* NVIC configuration */
#if 0
  /* Enable the USARTx Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  USART_ITConfig(CONSOLE_USART, USART_IT_TC, ENABLE);
  USART_ITConfig(CONSOLE_USART, USART_IT_TXE, DISABLE);
  USART_ITConfig(CONSOLE_USART, USART_IT_RXNE, ENABLE);
#endif //#if 0
  /* Enable USART */
  USART_Cmd(CONSOLE_USART, ENABLE);

  return 0;
}

static int _console_getchar(void) {
  int res = -1;
  if(USART_GetFlagStatus(CONSOLE_USART, USART_FLAG_RXNE) == SET)
    res = USART_ReceiveData(CONSOLE_USART);
  return res;
}

/*static*/ int _console_putchar(int ch) {
  if(USART_GetFlagStatus(CONSOLE_USART, USART_FLAG_TXE) == RESET)
    return -1;
  USART_SendData(CONSOLE_USART, (uint8_t)ch);
  return 0;
}

static int help_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]) {
  const char* help = "No such command or help for it!";
  console_func_desc_t* func_desc;

  PT_BEGIN(pt);

  if(argc == 2) {
    func_desc = console_find_function(usart_func_desc, argv[1]);
    if(func_desc != NULL)
      help = func_desc->help;
    CONSOLE_PUTS(pt, (char*)help);
  } else {
    //func_desc = console_find_function(usart_func_desc, "help");
    CONSOLE_PUTS(pt, "Supported commands:" CONSOLE_NEW_LINE);
    pt->p_hnd = usart_func_desc;
    while(((console_func_desc_t*)(pt->p_hnd))->func != NULL) {
      help = ((console_func_desc_t*)(pt->p_hnd))->name;
      CONSOLE_PUTS(pt, (char*)help);
      CONSOLE_PUTS(pt, CONSOLE_NEW_LINE);
      func_desc = (console_func_desc_t*)pt->p_hnd;
      pt->p_hnd = ++func_desc;
    }
  }

  PT_END(pt);
}


static int netstat_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]) {
  uint8_t iptab[4];
  uint32_t IPaddress;

  PT_BEGIN(pt);
  CONSOLE_PUTS(pt, "Link is ");
  CONSOLE_PUTS(pt, (char*)((is_network_up) ? "UP" : "DOWN"));
  IPaddress = eth0.ip_addr.addr;
  iptab[0] = (uint8_t)(IPaddress >> 24);
  iptab[1] = (uint8_t)(IPaddress >> 16);
  iptab[2] = (uint8_t)(IPaddress >> 8);
  iptab[3] = (uint8_t)(IPaddress);
  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, CONSOLE_NEW_LINE "IP address - %d.%d.%d.%d" CONSOLE_NEW_LINE, iptab[3], iptab[2], iptab[1], iptab[0]);
  CONSOLE_PUTS(pt, usart_console_buffer_in);

  IPaddress = eth0.gw.addr;
  iptab[0] = (uint8_t)(IPaddress >> 24);
  iptab[1] = (uint8_t)(IPaddress >> 16);
  iptab[2] = (uint8_t)(IPaddress >> 8);
  iptab[3] = (uint8_t)(IPaddress);
  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Gateway    - %d.%d.%d.%d" CONSOLE_NEW_LINE, iptab[3], iptab[2], iptab[1], iptab[0]);
  CONSOLE_PUTS(pt, usart_console_buffer_in);

  IPaddress = eth0.netmask.addr;
  iptab[0] = (uint8_t)(IPaddress >> 24);
  iptab[1] = (uint8_t)(IPaddress >> 16);
  iptab[2] = (uint8_t)(IPaddress >> 8);
  iptab[3] = (uint8_t)(IPaddress);
  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Net mask   - %d.%d.%d.%d" CONSOLE_NEW_LINE, iptab[3], iptab[2], iptab[1], iptab[0]);
  CONSOLE_PUTS(pt, usart_console_buffer_in);

  PT_END(pt);
}


static int fat_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]) {
  static DIR dir;
  FILINFO finfo;
  int err;

  PT_BEGIN(pt);

  if(strncmp(argv[0], "mount", CONSOLE_BUFFER_SZ) == 0) {
      if(argc == 2) {
          err = f_mount(sd_fatfs, argv[1], 1);
          if(err != 0) {
              snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Mount fail - %d", err);
              CONSOLE_PUTS(pt, usart_console_buffer_in);
          } else {
              if ((err = f_opendir(&dir, "/")) != FR_OK)
              {
                  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Cannot open root dir - %d", err);
                  CONSOLE_PUTS(pt, usart_console_buffer_in);
              }
          }

      } else {
          CONSOLE_PUTS(pt, "Usage: mount path, there path is 0:");
      }
  } else if(strncmp(argv[0], "umount", CONSOLE_BUFFER_SZ) == 0) {
      if(argc == 2) {
          err = f_mount(NULL, argv[1], 1);
          if(err != 0) {
              snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Umount fail - %d", err);
              CONSOLE_PUTS(pt, usart_console_buffer_in);
          }
      } else {
          CONSOLE_PUTS(pt, "Usage: umount path, there path is 0:");
      }
  } else if(strncmp(argv[0], "ls", CONSOLE_BUFFER_SZ) == 0) {
      err = f_readdir(&dir, NULL);
      for(;;) {
              err = f_readdir(&dir, &finfo);
              if ((err != FR_OK) || !finfo.fname[0]) break;
              snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "%c%c%c%c%c %u/%02u/%02u %02u:%02u %9lu  %-12s  %s" CONSOLE_NEW_LINE,
                              (finfo.fattrib & AM_DIR) ? 'D' : '-',
                              (finfo.fattrib & AM_RDO) ? 'R' : '-',
                              (finfo.fattrib & AM_HID) ? 'H' : '-',
                              (finfo.fattrib & AM_SYS) ? 'S' : '-',
                              (finfo.fattrib & AM_ARC) ? 'A' : '-',
                              (finfo.fdate >> 9) + 1980, (finfo.fdate >> 5) & 15, finfo.fdate & 31,
                              (finfo.ftime >> 11), (finfo.ftime >> 5) & 63,
                              finfo.fsize, finfo.fname,
                              "");
              CONSOLE_PUTS(pt, usart_console_buffer_in);
      }

  }else if(strncmp(argv[0], "cd", CONSOLE_BUFFER_SZ) == 0) {
      if(argc == 1)
        argv[1] = "/";
      if ((err = f_opendir(&dir, argv[1])) != FR_OK)
      {
          snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Cannot open dir - %s", argv[1]);
          CONSOLE_PUTS(pt, usart_console_buffer_in);
      }
  } else if(strncmp(argv[0], "rm", CONSOLE_BUFFER_SZ) == 0) {
      if(argc == 2) {
          if((err = f_unlink(argv[1])) != FR_OK) {
              snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Cannot remove file - %s (%d)", argv[1], err);
              CONSOLE_PUTS(pt, usart_console_buffer_in);
          }

      }
  }
  PT_END(pt);
};

static int date_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]) {
  RTC_TimeTypeDef RTC_TimeStructure;
  RTC_DateTypeDef RTC_DateStructure;

  PT_BEGIN(pt);
  if(argc == 1) {
      /* Get the current Time */
      RTC_GetTime(RTC_Format_BIN, &RTC_TimeStructure);
      RTC_GetDate(RTC_Format_BIN, &RTC_DateStructure);
      snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ,"The current time is :  %.2d:%.2d:%.2d %.2d/%.2d/%.4d",
          RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds,
          RTC_DateStructure.RTC_Date, RTC_DateStructure.RTC_Month, RTC_DateStructure.RTC_Year + 2000
          );
      CONSOLE_PUTS(pt, usart_console_buffer_in);
  }
  PT_END(pt);
}

#ifdef __cplusplus
 extern "C" {
#endif
  extern char _Heap_Begin; // Defined by the linker.
  extern char _Heap_Limit; // Defined by the linker.
#ifdef __cplusplus
 }
#endif


static int mem_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]) {
  struct mallinfo mi;
  PT_BEGIN(pt);
  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Heap begin 0x%lX, ends 0x%lX" CONSOLE_NEW_LINE, (uint32_t)&_Heap_Begin, (uint32_t)&_Heap_Limit);
  CONSOLE_PUTS(pt, usart_console_buffer_in);
  mi = mallinfo();
  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ,
      "Total non-mmapped bytes (arena):       %d" CONSOLE_NEW_LINE
      "# of free chunks (ordblks):            %d" CONSOLE_NEW_LINE
      "# of free fastbin blocks (smblks):     %d" CONSOLE_NEW_LINE,
      mi.arena, mi.ordblks, mi.smblks);
  CONSOLE_PUTS(pt, usart_console_buffer_in);
  mi = mallinfo();
  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ,
      "# of mapped regions (hblks):           %d" CONSOLE_NEW_LINE
      "Bytes in mapped regions (hblkhd):      %d" CONSOLE_NEW_LINE
      "Max. total allocated space (usmblks):  %d" CONSOLE_NEW_LINE,
      mi.hblks, mi.hblkhd, mi.usmblks);
  CONSOLE_PUTS(pt, usart_console_buffer_in);
  mi = mallinfo();
  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ,
      "Free bytes held in fastbins (fsmblks): %d" CONSOLE_NEW_LINE
      "Total allocated space (uordblks):      %d" CONSOLE_NEW_LINE
      "Total free space (fordblks):           %d" CONSOLE_NEW_LINE,
      mi.fsmblks, mi.uordblks, mi.fordblks);
  CONSOLE_PUTS(pt, usart_console_buffer_in);
  mi = mallinfo();
  snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ,
      "Topmost releasable block (keepcost):   %d" CONSOLE_NEW_LINE,
      mi.keepcost);
  CONSOLE_PUTS(pt, usart_console_buffer_in);

  PT_END(pt);
}

static int mp3_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]) {
  int   res;

  PT_BEGIN(pt);
  if(argc == 1) {
      CONSOLE_PUTS(pt, "Usage: mp3 <cmd> <param>");
      PT_EXIT(pt);
  }
  if(strncmp(argv[1], "play", CONSOLE_BUFFER_SZ) == 0) {
      if(argc == 4) {
          if(strncmp(argv[2], "ftp", CONSOLE_BUFFER_SZ) == 0) {
            config.media.source = MEDIA_SRC_FTP;
          } else if(strncmp(argv[2], "sd", CONSOLE_BUFFER_SZ) == 0) {
            config.media.source = MEDIA_SRC_SD;
          } else if(strncmp(argv[2], "rts", CONSOLE_BUFFER_SZ) == 0) {
            config.media.source = MEDIA_SRC_RTS;
          } else {
              CONSOLE_PUTS(pt, "Unknown source, supported types - ftp, sd, rts");
              PT_EXIT(pt);
          }
          if((res = media_buffer_open(&buffer_handler, &config.media, argv[3])) != MEDIA_OK) {
              snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Failed to open file - %d" CONSOLE_NEW_LINE, res);
              CONSOLE_PUTS(pt, usart_console_buffer_in);
              PT_EXIT(pt);
          }
          update_backup = true;
          is_stopped    = false;
          media_exec_cmd(&media_handle, MEDIA_CMD_PLAY);

      } else {
          CONSOLE_PUTS(pt, "Usage: mp3 play <source> <path>");
      }

  }else if(strncmp(argv[1], "stop", CONSOLE_BUFFER_SZ) == 0) {
      if(argc == 2) {
        media_exec_cmd(&media_handle, MEDIA_CMD_STOP);
        res = media_buffer_close(&buffer_handler);
        is_stopped = true;
        if(res != MEDIA_OK) {
            snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Failed to close file - %d" CONSOLE_NEW_LINE, res);
            CONSOLE_PUTS(pt, usart_console_buffer_in);
        }
      }
  } else if(strncmp(argv[1], "status", CONSOLE_BUFFER_SZ) == 0) {
      if(media_get_state(&media_handle) != MEDIA_INITIALIZED)
        strncpy(usart_console_buffer_in, ((media_get_state(&media_handle) == MEDIA_PLAYING) ? "Playing" : "Stop"), sizeof(usart_console_buffer_in));
      else
        strncpy(usart_console_buffer_in, "Initialized", sizeof(usart_console_buffer_in));
      CONSOLE_PUTS(pt, usart_console_buffer_in);
  } else if(strncmp(argv[1], "pause", CONSOLE_BUFFER_SZ) == 0) {
      media_exec_cmd(&media_handle, MEDIA_CMD_PAUSE);
  }
  PT_END(pt);
}

static int ftpc_cmd(console_cmd_fnc_handle_t* pt, int argc, char* argv[]) {
  static const char* ftpc_statuses[] = { "IDLE", "WAIT_CONNECTION", "CONNECTED", "TIMEOUT", "READY",  "OPEN", "TRANSFERRING", "CLOSE", "NONE" };

  PT_BEGIN(pt);

  if(argc == 1) {
      CONSOLE_PUTS(pt, "Usage: ftpc <command> <param>");
      PT_EXIT(pt);
  }

  if(strncmp(argv[1], "connect", CONSOLE_BUFFER_SZ) == 0) {
      if(argc != 5) {
        CONSOLE_PUTS(pt, "Usage: ftpc connect <ip address> <user> <password>");
        PT_EXIT(pt);
      }
      if(parse_ip(argv[2], &config.ftpc.ip_addr) == NULL) {
        CONSOLE_PUTS(pt, "Cannot parse IPv4 address!");
        PT_EXIT(pt);
      }
      strncpy(config.ftpc.user, argv[3], sizeof(config.ftpc.user));
      strncpy(config.ftpc.pass, argv[4], sizeof(config.ftpc.pass));

      // Save FTPC configuration
      update_backup = true;

      CONSOLE_PUTS(pt, "Trying to connect...");
      if(ftpc_connect(&ftpc_handle, &config.ftpc.ip_addr, config.ftpc.user, config.ftpc.pass) != FTPC_OK) {
        CONSOLE_PUTS(pt, "Cannot connect to host!");
        PT_EXIT(pt);
      }
      PT_WAIT_WHILE(pt, ftpc_is_busy(&ftpc_handle));
      if(ftpc_handle.state == FTPC_IDLE) {
          snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "Failed! (%d)", ftpc_handle.error);
          CONSOLE_PUTS(pt, usart_console_buffer_in);
      } else {
        CONSOLE_PUTS(pt, "Success!");
      }
  } else if(strncmp(argv[1], "status", CONSOLE_BUFFER_SZ) == 0) {
      snprintf(usart_console_buffer_in, CONSOLE_BUFFER_SZ, "%s - %d" CONSOLE_NEW_LINE, ftpc_statuses[ftpc_handle.state], ftpc_handle.error);
      CONSOLE_PUTS(pt, usart_console_buffer_in);
  } else if(strncmp(argv[1], "close", CONSOLE_BUFFER_SZ) == 0) {
      if(ftpc_disconnect(&ftpc_handle)) {
          CONSOLE_PUTS(pt, "Waiting for closing...");
          PT_WAIT_WHILE(pt, ftpc_is_busy(&ftpc_handle));
      } else {
          CONSOLE_PUTS(pt, "Wrong state!");
      }
  }else if(strncmp(argv[1], "cwd", CONSOLE_BUFFER_SZ) == 0) {
      if(argc != 3) {
          CONSOLE_PUTS(pt, "Usage: ftpc cwd <path>");
          PT_EXIT(pt);
      }
      strncpy((char*)config.media.source_dir, argv[2], sizeof(config.media.source_dir));
      ftpc_cwd(&ftpc_handle, argv[2]);
      CONSOLE_PUTS(pt, "Changing directory...");
      PT_WAIT_WHILE(pt, ftpc_is_busy(&ftpc_handle));
      if(ftpc_handle.error != 0) {
          CONSOLE_PUTS(pt, "Failed!");
      }
      // Save FTPC configuration
      update_backup = true;
  }

  PT_END(pt);
}

const char* parse_ip(const char* str, struct ip_addr* ip_addr) {
  unsigned      index;
  uint8_t       ip[4];
  char*         str_beg = (char*)str;
  char*         str_end;

  assert(str != NULL);
  assert(ip_addr != NULL);

  for(index = 0; index < sizeof(ip)/sizeof(ip[0]); index++) {
    ip[index] = strtol(str_beg, &str_end, 0);
    if(str_beg == str_end)
      return NULL;
    str_beg = str_end;
    ++str_beg;
  }

  IP4_ADDR(ip_addr, ip[0], ip[1], ip[2], ip[3]);

  return str_beg;
}

static void    debug_dump_memory(uint8_t* buf, int sz) {
  int col;

  while(sz) {
      debug_puts("");
      for(col = 0; col < 8 && sz; col++, sz--, buf++)
        debug_printf("0x%02X ", *buf);
  }
}
static err_t src_ftpc_cb_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err) {
  scr_handle_t*        pt = (scr_handle_t*)arg;

  assert(pt != NULL);

  if(p == NULL) {
    pt->complete = true;
  } else if(err == ERR_OK) {
      if(pt->rx == NULL) {
          pt->rx = p;
      } else {
          pbuf_cat(pt->rx, p);
      }
  }

  return err;
}

static void src_ftpc_cb_error(void * arg, err_t err) {
  scr_handle_t*        pt = (scr_handle_t*)arg;

  assert(pt != NULL);
  pt->complete = true;
  pt->res = FTPC_ERR_EXEC;
}

static int scr_process(scr_handle_t* pt) {
  UINT          br;
  pbuf*         pbuf_temp;

  PT_BEGIN(pt);

  while(1) {
    pt->rx = NULL;
    pt->cmd = 0;

    PT_WAIT_WHILE(pt, (pt->cmd == 0));

    if(pt->cmd == SCR_SAVE_CONFIG) {
        update_backup = true;
        PT_WAIT_WHILE(pt, (update_backup == true));
        pt->res = 0;
    } else if(pt->cmd == SCR_RESET) {
        // TODO
        pt->res = 0;
        NVIC_SystemReset();
    } else if(pt->cmd == SCR_FTP_DOWNLOAD) {
        pt->res = 0;
        debug_puts("Closing current connection...");
        // We will use ftpc->data_pcb, so no playing while downloading the file
        media_exec_cmd(&media_handle, MEDIA_CMD_STOP);
        media_buffer_close(&buffer_handler);
        ftpc_close(&ftpc_handle);
        is_stopped = true;
        PT_WAIT_WHILE(pt, ftpc_is_busy(&ftpc_handle));
        if(ftpc_connect(&ftpc_handle, &config.ftpc.ip_addr, config.ftpc.user, config.ftpc.pass) != FTPC_OK) {
          debug_puts("Cannot connect to host!");
          pt->res = FTPC_ERR_CONNECT;
          PT_EXIT(pt);
        }
        debug_puts("Trying to connect...");
        PT_WAIT_WHILE(pt, ftpc_is_busy(&ftpc_handle));

        if(ftpc_handle.state == FTPC_IDLE) {
            debug_printf("Failed! (%d)", ftpc_handle.error);
            pt->res = ftpc_handle.error;
            PT_EXIT(pt);
        }
        debug_puts("Success!");
        debug_puts("scr_process: Connected");

        if(strnlen(config.media.source_dir, MEDIA_DIR_SZ)) {
          debug_puts("Changing directory...");
          ftpc_cwd(&ftpc_handle, config.media.source_dir);
          PT_WAIT_WHILE(pt, ftpc_is_busy(&ftpc_handle));
          if(ftpc_handle.error != 0) {
              debug_puts("Failed!");
              pt->res = MEDIA_ERR_NONEXIST;
              ftpc_close(&ftpc_handle);
              PT_EXIT(pt);
          }
        }

        if(f_open(&buffer_handler.mp3_file, buffer_handler.filename, FA_WRITE | FA_CREATE_ALWAYS) != FR_OK) {
            debug_puts("scr_process: failed to create file on SD");
            pt->res = MEDIA_ERR_MEMORY;
            ftpc_close(&ftpc_handle);
            PT_EXIT(pt);
        }

        debug_puts("scr_process: Opening file...");

        if(!ftpc_retrieve(&ftpc_handle, buffer_handler.filename)) {
            debug_puts("scr_process: failed");
            pt->res = MEDIA_ERR_NONEXIST;
            ftpc_close(&ftpc_handle);
            PT_EXIT(pt);
        }
        tcp_arg(ftpc_handle.data_pcb, (void*)pt);
        tcp_recv(ftpc_handle.data_pcb, src_ftpc_cb_recv);
        tcp_err(ftpc_handle.data_pcb, src_ftpc_cb_error);
        pt->complete = false;
        debug_puts("scr_process: Opened");
        debug_puts("scr_process: Start download...");

        PT_WAIT_WHILE(pt, ftpc_is_busy(&ftpc_handle));

        if((ftpc_handle.state != FTPC_READY) || (ftpc_handle.error != FTPC_OK)) {
            debug_puts("scr_process: failed to open file at server");
            pt->res = MEDIA_ERR_NONEXIST;
            ftpc_close(&ftpc_handle);
            PT_EXIT(pt);
        }
        while(pt->complete == false) {
          PT_WAIT_WHILE(pt, (pt->complete == false) && (pt->rx == NULL));
          while(pt->rx != NULL) {
            if(f_write(&buffer_handler.mp3_file, pt->rx->payload, pt->rx->len, &br) != FR_OK) {
                pt->res = FTPC_ERR_MEMORY;
                pt->complete = true;
            }
            /* chop first pbuf from chain */
            pbuf_temp = pt->rx;
            pt->rx         = pt->rx->next;
            if(pt->rx != NULL)
                pbuf_ref(pt->rx);
            /* we can read more data now */
            tcp_recved(ftpc_handle.data_pcb, pbuf_temp->len);
            /* try to free pbuf */
            pbuf_free(pbuf_temp);
          }
        }
        debug_printf("scr_process: Complete -%d", pt->res);
        if(pt->rx != NULL)
          pbuf_free(pt->rx);
        ftpc_close(&ftpc_handle);
        f_close(&buffer_handler.mp3_file);
    }
  }
  PT_END(pt);
}

static uint32_t _get_baudrate(uint8_t baudrate) {
  switch(baudrate) {
  case Baud19200:
    return 19200UL;
  case Baud38400:
    return 38400UL;
  case Baud57600:
    return 57600UL;
  case Baud115200:
    return 115200UL;
  case Baud230400:
    return 230400;

  case Baud9600:
  default:
    return MODBUS_UART_BAUDRATE;
  }

}

const char *CGIPlayHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]) {
  if(iNumParams == 1) {
      media_buffer_source_t     src = MEDIA_SRC_NONE;
      const char*                     buf = pcValue[0];
      struct ip_addr            dest_ip;
      // Try to find protocol...
      if(strstr(buf, "rts://") == buf) {
          buf += 6;
          src = MEDIA_SRC_RTS;
      } else if(strstr(buf, "ftp://") == buf) {
          buf += 6;
          src = MEDIA_SRC_FTP;
      }else if(strstr(buf,"sd://") == buf) {
          buf += 5;
          src = MEDIA_SRC_SD;
      } else {
    	  return HTTPD_REQ_FAIL;
      }


      switch(src) {
      case MEDIA_SRC_RTS:
        strncpy(config.media.source_dir, buf, sizeof(config.media.source_dir));
        break;
      case MEDIA_SRC_FTP:
        if((buf = parse_ip(buf, &dest_ip)) == NULL)
            break;
        strncpy(config.media.source_dir, buf, sizeof(config.media.source_dir));
      case MEDIA_SRC_SD:
        strncpy(buffer_handler.filename, buf, sizeof(buffer_handler.filename));
        break;
      case MEDIA_SRC_NONE:
      default:
        break;
      }
      config.media.source = src;
  }
  modbus_slave_set_holding_register(101, MEDIA_CMD_PLAY);
  return HTTPD_REQ_OK;
}

const char *CGIStopHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]) {
  modbus_slave_set_holding_register(101, MEDIA_CMD_STOP);
  return HTTPD_REQ_OK;
}

const char *CGIPauseHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]) {
  modbus_slave_set_holding_register(101, MEDIA_CMD_PAUSE);
  return HTTPD_REQ_OK;
}

const char *CGIVolumeHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]) {
  if(iNumParams == 1)
      media_set_volume(&media_handle, atoi(pcValue[0]));
  else
    return NULL;
  return HTTPD_REQ_OK;
}

const char *CGIAuthChangeHandler(int iIndex, int iNumParams, char *pcParam[], char *pcValue[]) {
  // id=0, user='dfd', password='wwewe'
  errno = 0;

  if((iNumParams == 3) && (strcmp(pcParam[0], "id") == 0) && (strcmp(pcParam[1], "user") == 0) && (strcmp(pcParam[2], "password") == 0)) {
	  unsigned id = strtol(pcValue[0], NULL, 10);

	  if(errno != 0)
		  return NULL;

	  if((id >= HTTPD_ACCOUNTS_SZ)
			  || (strlen(pcValue[1]) >= HTTPD_USERNAME_SZ)
				  || (strlen(pcValue[2]) >= HTTPD_PASSWORD_SZ))
		  return NULL;
	  strncpy(config.httpd.users[id].name, pcValue[1], HTTPD_USERNAME_SZ);
	  strncpy(config.httpd.users[id].password, pcValue[2], HTTPD_PASSWORD_SZ);
	  update_backup = true;
  } else
	  return NULL;
  return HTTPD_REQ_OK;
}

int http_auth_page(const char *uri, const char *user, const char *pass) {
	unsigned int index;

	if((user == NULL) || (pass == NULL))
		return -1;

	for(index = 0; index < HTTPD_ACCOUNTS_SZ; index++) {
		if(strcmp(user, config.httpd.users[index].name) == 0) {
			if(strcmp(pass, config.httpd.users[index].password) == 0)
				return index;
		}
	}
	return -2;
}
