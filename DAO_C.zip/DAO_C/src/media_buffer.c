/*
 * media_buffer.c
 *
 *  Created on: 23 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "media_buffer.h"
#include "web_radio.h"
#include "debug.h"


extern const char* parse_ip(const char* str, struct ip_addr* ip_addr);

static err_t ftpc_cb_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err);
static err_t ftpc_cb_connected(void *arg, struct tcp_pcb *tpcb, err_t err);
//static err_t ftpc_cb_sent(void *arg, struct tcp_pcb *tpcb, u16_t len);
//static err_t ftpc_cb_poll(void *arg, struct tcp_pcb *tpcb);
static void ftpc_cb_error(void * arg, err_t err);


int media_buffer_init(media_buffer_handle_t* pt, media_handle_t* hnd, ftpc_handle_t* ftpc_hnd) {

  assert(pt != NULL);
  assert(hnd != NULL);
  assert(ftpc_hnd != NULL);

  PT_INIT(pt);
  PT_SEM_INIT(&pt->data_ready, 0);

  pt->error     = MEDIA_OK;
  pt->data_pcb  = NULL;
  pt->p_tx      = NULL;
  pt->p_rx      = NULL;
  pt->cfg       = NULL;
  pt->hnd       = hnd;
  pt->ftpc_hnd  = ftpc_hnd;

  return MEDIA_OK;
}


int media_buffer_process(media_buffer_handle_t* pt) {
  err_t         err;
  UINT          br;
  static struct pbuf* p;
  char*         ptr;

  assert(pt != NULL);
  assert(pt->hnd != NULL);


  PT_BEGIN(pt);
  while(pt->source != MEDIA_SRC_NONE) {

      PT_WAIT_WHILE(pt, (pt->cfg == NULL));
      PT_SEM_WAIT(pt, &pt->hnd->buffer_empty);
      PT_WAIT_WHILE(pt, (pt->cfg == NULL));

      if(pt->source == MEDIA_SRC_SD) {
        //PT_SEM_WAIT(pt, &pt->hnd->buffer_empty);
        if((f_read(&pt->mp3_file, (void*)pt->hnd->buffer, sizeof(pt->hnd->buffer), &br) == FR_OK) && (br > 0)) {
            pt->hnd->buffer_sz = br;
            PT_SEM_SIGNAL(pt, &pt->hnd->buffer_full);
        } else  {
            media_exec_cmd(pt->hnd, MEDIA_CMD_STOP);
            f_close(&pt->mp3_file);
        }

      } else if(pt->source == MEDIA_SRC_FTP) {
          if(pt->ftpc_hnd->data_pcb == NULL) {
              if(pt->ftpc_hnd->state == FTPC_ABORT) {
                  PT_WAIT_WHILE(pt, ftpc_is_busy(pt->ftpc_hnd));
              }
              if(pt->ftpc_hnd->state == FTPC_CLOSE) {
                  PT_WAIT_WHILE(pt, ftpc_is_busy(pt->ftpc_hnd));
              }
              if(pt->ftpc_hnd->state == FTPC_IDLE) {                    // Not connected
                  PT_WAIT_WHILE(pt, ftpc_is_busy(pt->ftpc_hnd));
                  debug_puts("media_buffer: Trying to connect...");
                  if(ftpc_connect(pt->ftpc_hnd, &pt->ftpc_hnd->cfg->ip_addr, pt->ftpc_hnd->cfg->user, pt->ftpc_hnd->cfg->pass) == FTPC_OK) {
                      PT_WAIT_WHILE(pt, ftpc_is_busy(pt->ftpc_hnd));
                  }
              }
              if(pt->ftpc_hnd->state != FTPC_READY) {
                  media_exec_cmd(pt->hnd, MEDIA_CMD_STOP);
                  pt->error = MEDIA_ERR_NONEXIST;
                  PT_EXIT(pt);
              }
              debug_puts("media_buffer: Connected");

              if(strnlen(pt->cfg->source_dir, MEDIA_DIR_SZ)) {
                ftpc_cwd(pt->ftpc_hnd, pt->cfg->source_dir);
                debug_puts("Changing directory...");
                PT_WAIT_WHILE(pt, ftpc_is_busy(pt->ftpc_hnd));
                if(pt->ftpc_hnd->error != 0) {
                    debug_puts("Failed!");
                    pt->error = MEDIA_ERR_NONEXIST;
                    PT_EXIT(pt);
                }
              }

              debug_puts("media_buffer: Opening file...");
              if(!ftpc_retrieve(pt->ftpc_hnd, pt->filename)) {
                  media_exec_cmd(pt->hnd, MEDIA_CMD_STOP);
                  debug_puts("media_buffer: failed");
                  pt->error = MEDIA_ERR_NONEXIST;
                  PT_EXIT(pt);
              }

              tcp_arg(pt->ftpc_hnd->data_pcb, (void*)pt);
              tcp_recv(pt->ftpc_hnd->data_pcb, ftpc_cb_recv);

              PT_WAIT_WHILE(pt, ftpc_is_busy(pt->ftpc_hnd));
              if((pt->ftpc_hnd->state != FTPC_READY) || (pt->ftpc_hnd->error != FTPC_OK)) {
                  media_exec_cmd(pt->hnd, MEDIA_CMD_STOP);
                  pt->error = MEDIA_ERR_NONEXIST;
                  PT_EXIT(pt);
              }
              debug_puts("media_buffer: Opened");
          }
          PT_WAIT_WHILE(pt, pt->p_rx == NULL);
          //PT_SEM_WAIT(pt, &pt->hnd->buffer_empty);

          // Only support pbuf size less then 2*MEDIA_BUFFER_SZ
          assert(pt->p_rx->len <= 2*sizeof(pt->hnd->buffer));

          pt->hnd->buffer_sz = (pt->p_rx->len < sizeof(pt->hnd->buffer)) ? pt->p_rx->len : sizeof(pt->hnd->buffer);
          memcpy(pt->hnd->buffer, pt->p_rx->payload, pt->hnd->buffer_sz);
          /// DEBUG          f_write(&pt->mp3_file, (void*)pt->hnd->buffer, pt->hnd->buffer_sz, &br);
          PT_SEM_SIGNAL(pt, &pt->hnd->buffer_full);

          if(pt->hnd->buffer_sz < pt->p_rx->len) {
              PT_SEM_WAIT(pt, &pt->hnd->buffer_empty);
              memcpy(pt->hnd->buffer, pt->p_rx->payload + pt->hnd->buffer_sz, pt->p_rx->len - pt->hnd->buffer_sz);
              /// DEBUG              f_write(&pt->mp3_file, (void*)(pt->p_rx->payload + pt->hnd->buffer_sz), pt->p_rx->len - pt->hnd->buffer_sz, &br);
              pt->hnd->buffer_sz = pt->p_rx->len - pt->hnd->buffer_sz;
              PT_SEM_SIGNAL(pt, &pt->hnd->buffer_full);
          }
          /* chop first pbuf from chain */
          p         = pt->p_rx;
          pt->p_rx  = pt->p_rx->next;
          if(pt->p_rx != NULL)
              pbuf_ref(pt->p_rx);
          /* we can read more data now */
          tcp_recved(pt->ftpc_hnd->data_pcb, p->len);
          /* try hard to free pbuf */
          PT_WAIT_WHILE(pt, pbuf_free(p) == 0);
      } else if(pt->source == MEDIA_SRC_RTS) {
          PT_WAIT_WHILE(pt, (pt->data_pcb != NULL) && (pt->data_pcb->state != ESTABLISHED ));
          debug_puts("connected");
          err = tcp_write(pt->data_pcb, "GET ", sizeof("GET ")-1, 1);
          if(((ptr = memchr(pt->cfg->source_dir, (int)'/', MEDIA_DIR_SZ)) != NULL) && (*++ptr != 0)) {
              err = (err != ERR_OK) ? err : tcp_write(pt->data_pcb, ptr, strnlen(ptr, MEDIA_DIR_SZ), 1);
          }else {
              err = (err != ERR_OK) ? err : tcp_write(pt->data_pcb, "/", 1, 1);
          }
          err = (err != ERR_OK) ? err : tcp_write(pt->data_pcb, " HTTP/1.0\r\n" "Host: ", sizeof(" HTTP/1.0\r\n" "Host: ")-1, 1);
          if((ptr = memchr(pt->cfg->source_dir, (int)'/', MEDIA_DIR_SZ)) != NULL) {
              err = (err != ERR_OK) ? err : tcp_write(pt->data_pcb, pt->cfg->source_dir, ptr - pt->cfg->source_dir, 1);
          }
          err = (err != ERR_OK) ? err : tcp_write(pt->data_pcb, "\r\nAccept: */*\r\n" "User-Agent: DAO\r\n" "Connection: close\r\n" "\r\n", sizeof("\r\nAccept: */*\r\n" "User-Agent: DAO\r\n" "Connection: close\r\n" "\r\n")-1, 1);
          if(err != ERR_OK){
             debug_puts("media_buffer: Cannot write command");
             pt->error = MEDIA_ERR_NONEXIST;
             PT_EXIT(pt);
          }
          while(1) {
            PT_WAIT_WHILE(pt, pt->p_rx == NULL);
            // Only support pbuf size less then 2*MEDIA_BUFFER_SZ
            assert(pt->p_rx->len <= 2*sizeof(pt->hnd->buffer));
            pt->hnd->buffer_sz = (pt->p_rx->len < sizeof(pt->hnd->buffer)) ? pt->p_rx->len : sizeof(pt->hnd->buffer);
            memcpy(pt->hnd->buffer, pt->p_rx->payload, pt->hnd->buffer_sz);
            PT_SEM_SIGNAL(pt, &pt->hnd->buffer_full);

            if(pt->hnd->buffer_sz < pt->p_rx->len) {
                PT_SEM_WAIT(pt, &pt->hnd->buffer_empty);
                memcpy(pt->hnd->buffer, pt->p_rx->payload + pt->hnd->buffer_sz, pt->p_rx->len - pt->hnd->buffer_sz);
                pt->hnd->buffer_sz = pt->p_rx->len - pt->hnd->buffer_sz;
                PT_SEM_SIGNAL(pt, &pt->hnd->buffer_full);
            }
            /* chop first pbuf from chain */
            p         = pt->p_rx;
            pt->p_rx  = pt->p_rx->next;
            if(pt->p_rx != NULL)
                pbuf_ref(pt->p_rx);
            /* we can read more data now */
            tcp_recved(pt->data_pcb, p->len);
            /* try hard to free pbuf */
            PT_WAIT_WHILE(pt, pbuf_free(p) == 0);
            PT_SEM_WAIT(pt, &pt->hnd->buffer_empty);
          }
      }

  }
  PT_END(pt);
}

int media_buffer_open(media_buffer_handle_t* pt,  media_buffer_cfg_t*  cfg, const char* url) {
  char*                 ptr;
  uint16_t              port = MEDIA_BUFFER_DEFAULT_RTS_PORT;
  struct ip_addr        dest_ip;

  assert(pt != NULL);
  assert(cfg != NULL);

  media_buffer_close(pt);

  pt->error = MEDIA_OK;
  pt->cfg   = cfg;
  pt->source= pt->cfg->source;

  // Copy file name or path
  switch(pt->cfg->source) {
  case MEDIA_SRC_SD:
  case MEDIA_SRC_FTP:
    // Check if url is not the same as pt->filename
    if(pt->filename != url)
      strncpy(pt->filename, url, sizeof(pt->filename));
    // Check file name length
    if(strnlen(pt->filename, sizeof(pt->filename)) == sizeof(pt->filename))
      pt->filename[sizeof(pt->filename) -1] = 0;
    break;
  case MEDIA_SRC_RTS:
    if(url != NULL)
      strncpy(pt->cfg->source_dir, url, sizeof(pt->cfg->source_dir));
    break;
  case MEDIA_SRC_NONE:
  default:
    break;
  }
  // Trying to access to resource...
  switch(pt->cfg->source) {
  case MEDIA_SRC_SD:
    pt->error = (f_open(&pt->mp3_file, url, FA_READ) == FR_OK) ? MEDIA_OK : MEDIA_ERR_NONEXIST;
    break;
  case MEDIA_SRC_FTP:
    pt->ftpc_hnd->filename = pt->filename;
    if(pt->p_rx != NULL) {
        if(pt->ftpc_hnd->data_pcb != NULL)
          tcp_recved(pt->ftpc_hnd->data_pcb, pt->p_rx->len);
        pbuf_free(pt->p_rx);
        pt->p_rx = NULL;
    }
    /// DEBUG    pt->error = (f_open(&pt->mp3_file, "test.mp3", FA_WRITE | FA_CREATE_NEW) == FR_OK) ? MEDIA_OK : MEDIA_ERR_NONEXIST;
    break;
  case MEDIA_SRC_RTS:
    /* create new tcp pcb */
    pt->data_pcb  = tcp_new();
    pt->p_rx      = NULL;
    pt->p_tx      = NULL;
    if (pt->data_pcb == NULL) {
        pt->error = MEDIA_ERR_MEMORY;
        return FTPC_ERR_MEMORY;
    }
    tcp_arg(pt->data_pcb, (void*)pt);
    tcp_recv(pt->data_pcb, ftpc_cb_recv);
    tcp_err(pt->data_pcb, ftpc_cb_error);

    /* connect to destination address/port */
    if(parse_ip(pt->cfg->source_dir, &dest_ip) == NULL) {
      debug_puts("Cannot parse IPv4 address!");
      pt->error   = MEDIA_ERR_CONFIG;
    } else {
      if((ptr = memchr(pt->cfg->source_dir, (int)':', MEDIA_DIR_SZ)) != NULL) {
          ++ptr;
          port = strtol(ptr, &ptr, 0);
      }
      if((pt->error = tcp_connect(pt->data_pcb, &dest_ip, port, ftpc_cb_connected)) != ERR_OK) {
        pt->error = FTPC_ERR_CONNECT;
        tcp_arg(pt->data_pcb, NULL);
        tcp_recv(pt->data_pcb, NULL);
        tcp_err(pt->data_pcb, NULL);
        tcp_abort(pt->data_pcb);
        pt->data_pcb = NULL;
      }
    }
    break;
  default:
    pt->cfg     = NULL;
    pt->error   = MEDIA_ERR_CONFIG;
    break;
  }
  return pt->error;
}

int media_buffer_close(media_buffer_handle_t* pt) {

  assert(pt != NULL);

  if(pt->cfg != NULL) {
    switch(pt->source){
    case MEDIA_SRC_SD:
      f_close(&pt->mp3_file);
      break;
    case MEDIA_SRC_FTP:
      ftpc_data_close(pt->ftpc_hnd);
      /// DEBUG      f_close(&pt->mp3_file);
      break;
    case MEDIA_SRC_RTS:
      if(pt->data_pcb != NULL) {
          tcp_arg(pt->data_pcb, NULL);
          tcp_recv(pt->data_pcb, NULL);
      //    tcp_sent(pt->data_pcb, NULL);
      //    tcp_poll(pt->data_pcb, NULL, 0);
          tcp_err(pt->data_pcb, NULL);
          tcp_abort(pt->data_pcb);
          pt->data_pcb = NULL;
      }
      if(pt->p_tx != NULL) {
        pbuf_free(pt->p_tx);
        pt->p_tx = NULL;
      }
      break;
    default:
      break;
    }
    // Restart processing
    if(pt->p_rx != NULL) {
      pbuf_free(pt->p_rx);
      pt->p_rx = NULL;
    }
    pt->cfg    = NULL;
    pt->source = MEDIA_SRC_NONE;
    debug_puts("media_buffer: closed");
  }
  PT_INIT(pt);
  return MEDIA_OK;
}

static err_t ftpc_cb_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err) {
  media_buffer_handle_t*        pt = arg;

  assert(pt != NULL);

  if((err == ERR_OK) && (p != NULL)) {
      if(pt->p_rx == NULL) {
          pt->p_rx = p;
      } else {
          pbuf_cat(pt->p_rx, p);
      }
  }

  if(p == NULL) {
      media_exec_cmd(pt->hnd, MEDIA_CMD_STOP);
      media_buffer_close(pt);
  }
  return err;
}

static err_t ftpc_cb_connected(void *arg, struct tcp_pcb *tpcb, err_t err) {
  media_buffer_handle_t*        pt = arg;

  assert(pt != NULL);

  if(err != ERR_OK) {
      media_exec_cmd(pt->hnd, MEDIA_CMD_STOP);
      media_buffer_close(pt);
      pt->error = err;
      debug_printf("media_buffer: connection failed - %d\n", err);
      err  = ERR_ABRT;
  } else {
      pt->data_pcb   = tpcb;
      debug_puts("media_buffer: connected");
  }
  return err;
}

static void ftpc_cb_error(void * arg, err_t err) {
  media_buffer_handle_t*        pt = arg;

  assert(pt != NULL);

  media_exec_cmd(pt->hnd, MEDIA_CMD_STOP);
  media_buffer_close(pt);
  pt->error = err;
  debug_printf("media_buffer: connection failed - %d\n", err);
  err  = ERR_ABRT;
}
