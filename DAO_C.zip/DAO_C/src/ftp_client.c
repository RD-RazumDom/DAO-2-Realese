/*
 * ftp_client.c
 *
 *  Created on: 29 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */
#include "ftp_client.h"
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "debug.h"

#define FTPC_OP_READ_TIMEOUT         (100)
#define FTPC_OP_SENT_TIMEOUT         (100)
#define FTPC_OP_SENT_READ_TIMEOUT    (100)
#define FTPC_COMMAND_BUFFER_SZ       (100)

#define FTPC_FLAG_READING            (0x01)
#define FTPC_FLAG_SENDING            (0x02)


#define FTPC_MSG_WELCOME             "220"
#define FTPC_MSG_LOGIN_OK            "230"
#define FTPC_MSG_USER_OK             "331"
#define FTPC_MSG_PASV_OK             "227"
#define FTPC_MSG_RETR_OK             "150"
#define FTPC_MSG_QUIT_OK             "221"
#define FTPC_MSG_TRNS_OK             "226"
#define FTPC_MSG_CWD_OK              "250"
#define FTPC_MSG_ABOR_OK             "250"
#define FTPC_MSG_ABORT               "421"
#define FTPC_MSG_DATA_FAIL           "426"

#define FTPC_DEFAULT_FILE            "/DAO/10.mp3"//"/home/dimion/tmp/ftp/Breathe.mp3"

#define FTPC_START_READING(_pt, _timeout)       { _pt->flags |= FTPC_FLAG_READING; _pt->timeout= _timeout; PT_WAIT_WHILE(_pt, _pt->flags & FTPC_FLAG_READING);}
#define FTPC_FREE_RD_BUFFER(_pt)                { tcp_recved(_pt->ctrl_pcb, _pt->p_rx->tot_len); pbuf_free(_pt->p_rx); _pt->p_rx = NULL;}
#define FTPC_START_SENDING(_pt, _timeout)       { _pt->flags |= FTPC_FLAG_SENDING; _pt->timeout= _timeout; PT_WAIT_WHILE(_pt, _pt->flags & FTPC_FLAG_SENDING);}
#define FTPC_START_SENDING_READING(_pt, _timeout) { _pt->flags |= (FTPC_FLAG_SENDING |  FTPC_FLAG_READING); _pt->timeout= _timeout; PT_WAIT_WHILE(_pt, _pt->flags & (FTPC_FLAG_SENDING |  FTPC_FLAG_READING));}
#define FTPC_CHECK_TIMEOUT(_pt)                 { if(_pt->state == FTPC_TIMEOUT) { debug_puts("Timeout"); PT_EXIT(_pt);}}

static err_t ftpc_cb_connected(void *arg, struct tcp_pcb *tpcb, err_t err);
static err_t ftpc_cb_data_connected(void *arg, struct tcp_pcb *tpcb, err_t err);
static void ftpc_cb_error(void * arg, err_t err);
static void ftpc_cb_data_error(void * arg, err_t err);
static err_t ftpc_cb_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err);
static err_t ftpc_cb_sent(void *arg, struct tcp_pcb *tpcb, u16_t len);
static err_t ftpc_cb_poll(void *arg, struct tcp_pcb *tpcb);
static int ftpc_prepare_cmd_buffer(char *cmd, char *arg, struct pbuf* buf);
static err_t ftpc_send_cmd(ftpc_handle_t* pt, char *cmd, char *arg);
static int ftpc_parse_pasv_answer(char* buf, int buf_sz, struct ip_addr* dest_ip);

void ftpc_init(ftpc_handle_t* pt, ftpc_config_t* cfg) {

  assert(pt != NULL);
  assert(cfg != NULL);

  PT_INIT(pt);

  pt->state     = FTPC_IDLE;
  pt->cfg       = cfg;
  pt->data_pcb  = NULL;
  pt->p_rx      = NULL;
  pt->p_tx      = NULL;
}

static int ftpc_prepare_cmd_buffer(char *cmd, char *arg, struct pbuf* buf) {
  int cmd_len;

  assert(cmd != NULL);
  assert(buf != NULL);

  if (arg != NULL) {
      cmd_len = snprintf(buf->payload, buf->len, "%s %s\r\n", cmd, arg);
  } else {
      cmd_len = snprintf(buf->payload, buf->len, "%s\r\n", cmd);
  }

  assert(cmd_len <= buf->len);

  return cmd_len;
}

int  ftpc_process(ftpc_handle_t* pt) {
  struct ip_addr dest_ip;
  uint16_t      data_port;

  assert(pt != NULL);
  assert(pt->cfg != NULL);

  PT_BEGIN(pt);

  while(1) {

      ftpc_close(pt);

      while(1) {
          // Wait for a command
          PT_WAIT_WHILE(pt, (pt->state == FTPC_READY) || ((pt->state == FTPC_IDLE)));

          if(pt->state == FTPC_CONNECTED) {                                               // Trying to connect to server
              // Wait welcome
              FTPC_START_READING(pt, FTPC_OP_READ_TIMEOUT);
              FTPC_CHECK_TIMEOUT(pt);

              if(strncmp(pt->p_rx->payload, FTPC_MSG_WELCOME, sizeof(FTPC_MSG_WELCOME)-1) != 0) {
                  debug_puts("ftpc: No welcome message from server!");
                  pt->error = FTPC_ERR_CONNECT;
                  PT_EXIT(pt);
              }
              FTPC_FREE_RD_BUFFER(pt);

              // Try to login
              pt->p_tx = pbuf_alloc(PBUF_RAW, FTPC_COMMAND_BUFFER_SZ, PBUF_POOL);
              if(pt->p_tx == NULL) {
                  debug_puts("ftpc: Cannot allocate memory for command buffer!");
                  pt->error = FTPC_ERR_MEMORY;
                  PT_EXIT(pt);
              }

              // Send user name
              /// FIXME Change user
              if((pt->error = ftpc_send_cmd(pt, "USER", pt->cfg->user)) != ERR_OK) {
                  pt->error = FTPC_ERR_AUTHORIZATION;
                  PT_EXIT(pt);
              }
              FTPC_START_SENDING_READING(pt, FTPC_OP_SENT_READ_TIMEOUT);
              FTPC_CHECK_TIMEOUT(pt);

              if(strncmp(pt->p_rx->payload, FTPC_MSG_USER_OK, sizeof(FTPC_MSG_USER_OK)-1) == 0){
                  // Send password name
                  FTPC_FREE_RD_BUFFER(pt);
                  if((pt->error = ftpc_send_cmd(pt, "PASS", pt->cfg->pass)) != ERR_OK) {
                      pt->error = FTPC_ERR_AUTHORIZATION;
                      PT_EXIT(pt);
                  }
                  FTPC_START_SENDING_READING(pt, FTPC_OP_SENT_READ_TIMEOUT);
                  FTPC_CHECK_TIMEOUT(pt);
              }

              if(strncmp(pt->p_rx->payload, FTPC_MSG_LOGIN_OK, sizeof(FTPC_MSG_LOGIN_OK)-1) != 0) {
                  debug_puts("ftpc: Cannot authorized on server!");
                  pt->error = FTPC_ERR_AUTHORIZATION;
                  PT_EXIT(pt);
              }
              FTPC_FREE_RD_BUFFER(pt);

              pt->state = FTPC_READY;

          } else if(pt->state == FTPC_OPEN) {                                         // Trying to read file
            // Changing mode to passive...
            if((pt->error = ftpc_send_cmd(pt, "PASV", NULL)) != ERR_OK)
                PT_EXIT(pt);
            FTPC_START_SENDING_READING(pt, FTPC_OP_SENT_READ_TIMEOUT);
            FTPC_CHECK_TIMEOUT(pt);
            if(strncmp(pt->p_rx->payload, FTPC_MSG_PASV_OK, sizeof(FTPC_MSG_PASV_OK)-1) != 0) {
                debug_puts("ftpc: Cannot set passive mode!");
                pt->error = FTPC_ERR_SETUP;
                PT_EXIT(pt);
            }

            if((data_port = ftpc_parse_pasv_answer(pt->p_rx->payload, pt->p_rx->len, &dest_ip)) == 0) {
                debug_puts("ftpc: Cannot parse port in passive mode!");
                pt->error = FTPC_ERR_SETUP;
                PT_EXIT(pt);
            }
            FTPC_FREE_RD_BUFFER(pt);

            // Open data connection
            if((pt->error = tcp_connect(pt->data_pcb, &dest_ip, data_port, ftpc_cb_data_connected)) != ERR_OK) {
                debug_puts("ftpc: Cannot connect data pcb!");
                PT_EXIT(pt);
            }
            // Ask for file
            if((pt->error = ftpc_send_cmd(pt, "RETR", pt->filename)) != ERR_OK)
                PT_EXIT(pt);
            FTPC_START_SENDING_READING(pt, FTPC_OP_SENT_READ_TIMEOUT);
            FTPC_CHECK_TIMEOUT(pt);
            if(strncmp(pt->p_rx->payload, FTPC_MSG_RETR_OK, sizeof(FTPC_MSG_RETR_OK)-1) != 0) {
                debug_puts("ftpc: Cannot ask file name!");
                pt->error = FTPC_ERR_SETUP;
                PT_EXIT(pt);
            }
            FTPC_FREE_RD_BUFFER(pt);

            pt->state = FTPC_READY;

          } else if(pt->state == FTPC_CLOSE) {                                          // Closing connection
            tcp_close(pt->data_pcb);
            if((pt->error = ftpc_send_cmd(pt, "QUIT", NULL)) != ERR_OK)
                PT_EXIT(pt);
            FTPC_START_SENDING_READING(pt, FTPC_OP_SENT_READ_TIMEOUT);
            FTPC_CHECK_TIMEOUT(pt);
            if(strncmp(pt->p_rx->payload, FTPC_MSG_QUIT_OK, sizeof(FTPC_MSG_QUIT_OK)-1) != 0) {
                debug_puts("ftpc: Quit failed!");
                pt->error = 0;
            }
            FTPC_FREE_RD_BUFFER(pt);
            ftpc_close(pt);
            PT_EXIT(pt);

          } else if(pt->state == FTPC_CHANGING_DIR) {                                   // Changing current directory
              PT_WAIT_WHILE(pt, pt->flags & (FTPC_FLAG_SENDING |  FTPC_FLAG_READING));
              FTPC_CHECK_TIMEOUT(pt);
              if(strncmp(pt->p_rx->payload, FTPC_MSG_CWD_OK, sizeof(FTPC_MSG_CWD_OK)-1) != 0) {
                  pt->error = FTPC_ERR_EXEC;
              }
              FTPC_FREE_RD_BUFFER(pt);
              pt->state = FTPC_READY;
          }
#if 1
          else if(pt->state == FTPC_ABORT) {                                          // Abort command
              PT_WAIT_WHILE(pt, pt->flags & (FTPC_FLAG_SENDING |  FTPC_FLAG_READING));
              FTPC_CHECK_TIMEOUT(pt);
              if(strncmp(pt->p_rx->payload, FTPC_MSG_ABOR_OK, sizeof(FTPC_MSG_ABOR_OK)-1) != 0) {
                  pt->error = FTPC_ERR_EXEC;
              }
              FTPC_FREE_RD_BUFFER(pt);
              pt->state = FTPC_READY;
          }
#endif
          else if(pt->state == FTPC_WAIT_CONNECTION) {                                // Wait connection
              PT_WAIT_WHILE(pt, pt->state == FTPC_WAIT_CONNECTION);
          }else {                                                                       // Unknown state
              debug_puts("ftpc: Wrong state!");
              pt->state = FTPC_READY;
          }
          debug_puts("ftpc: Success!");
      }
  }

  PT_END(pt);
}

int  ftpc_connect(ftpc_handle_t* pt, struct ip_addr* dest_ip, char* user, char* pass) {

  assert(pt != NULL);
  assert(pt->cfg != NULL);
  assert(user != NULL);
  assert(pass != NULL);

  if(pt->state != FTPC_IDLE)
    return FTPC_ERR_INVALID_STATE;

  /// Copy credential
  pt->cfg->ip_addr = *dest_ip;
  strncpy(pt->cfg->user, user, FTPC_USER_SZ);
  strncpy(pt->cfg->pass, pass, FTPC_PASS_SZ);

  /* create new tcp pcb */
  pt->ctrl_pcb  = tcp_new();
  pt->p_rx      = NULL;
  pt->p_tx      = NULL;

  if (pt->ctrl_pcb == NULL) {
      pt->error = FTPC_ERR_MEMORY;
      return FTPC_ERR_MEMORY;
  }

  tcp_arg(pt->ctrl_pcb, (void*)pt);
  tcp_recv(pt->ctrl_pcb, ftpc_cb_recv);
  tcp_sent(pt->ctrl_pcb, ftpc_cb_sent);
  tcp_poll(pt->ctrl_pcb, ftpc_cb_poll, 1);
  tcp_err(pt->ctrl_pcb, ftpc_cb_error);

  /* connect to destination address/port */
  if((pt->error = tcp_connect(pt->ctrl_pcb, dest_ip, FTP_SERVER_PORT, ftpc_cb_connected)) != ERR_OK)
    return FTPC_ERR_CONNECT;

  pt->state = FTPC_WAIT_CONNECTION;

  return FTPC_OK;
}


static err_t ftpc_cb_connected(void *arg, struct tcp_pcb *tpcb, err_t err) {
  ftpc_handle_t* pt = arg;

  assert(pt != NULL);

  if(err != ERR_OK) {
      ftpc_close(pt);
      pt->error = err;
      debug_printf("ftpc: connection failed - %d\n", err);
      err  = ERR_ABRT;
  } else {
      pt->state = FTPC_CONNECTED;
      pt->ctrl_pcb   = tpcb;
      debug_puts("ftpc: connected");
  }
  return err;
}

static err_t ftpc_cb_data_connected(void *arg, struct tcp_pcb *tpcb, err_t err) {

  if(err != ERR_OK) {
      debug_printf("ftpc: data connection failed - %d\n", err);
      err  = ERR_ABRT;
  } else {
      debug_puts("ftpc: data connected");
  }
  return err;
}


static void ftpc_cb_error(void * arg, err_t err) {
  ftpc_handle_t* pt = arg;

  assert(pt != NULL);

  ftpc_close(pt);
  pt->error = err;
  debug_printf("ftpc: error - %d\n", err);
}

void  ftpc_close(ftpc_handle_t* pt) {

  assert(pt != NULL);

  if(pt->state == FTPC_IDLE)
    return;

  ftpc_data_close(pt);

  // Disable callbacks
  tcp_recv(pt->ctrl_pcb, NULL);
  tcp_sent(pt->ctrl_pcb, NULL);
  tcp_poll(pt->ctrl_pcb, NULL, 0);
  tcp_err(pt->ctrl_pcb, NULL);
  // Abort connection and free memory
  tcp_abort(pt->ctrl_pcb);

  // Free buffers
  if(pt->p_rx != NULL)
    pbuf_free(pt->p_rx);
  if(pt->p_tx != NULL)
    pbuf_free(pt->p_tx);
  // Set default state
  pt->state     = FTPC_IDLE;
  pt->p_rx      = NULL;
  pt->p_tx      = NULL;
  pt->ctrl_pcb  = NULL;
  pt->flags     = 0;
  pt->timeout   = 0;

  debug_puts("ftpc: closed");
}

static err_t ftpc_cb_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err) {
  ftpc_handle_t* pt = arg;

  assert(pt != NULL);

  if(err == ERR_OK) {
    if(pt->flags & FTPC_FLAG_READING) {
        // Ignore message about data failure
        if(strncmp(p->payload, FTPC_MSG_DATA_FAIL, sizeof(FTPC_MSG_DATA_FAIL)-1) == 0) {
            tcp_recved(tpcb, p->tot_len);
            pbuf_free(p);
        } else {
          pt->p_rx      = p;
          pt->flags     &= ~FTPC_FLAG_READING;
          if((pt->flags & (FTPC_FLAG_READING | FTPC_FLAG_SENDING)) == 0)
            pt->timeout   = 0;
        }
    } else {
        if(strncmp(p->payload, FTPC_MSG_ABORT, sizeof(FTPC_MSG_ABORT)-1) == 0) {
            pt->error = FTPC_ERR_CONNECT;
            PT_INIT(pt);
        };
        tcp_recved(tpcb, p->tot_len);
        pbuf_free(p);
    }

    //debug_puts("ftpc: received");
  }
  return err;
}

static err_t ftpc_cb_sent(void *arg, struct tcp_pcb *tpcb, u16_t len) {
  ftpc_handle_t* pt = arg;

  assert(pt != NULL);
  pt->flags     &= ~FTPC_FLAG_SENDING;
  if((pt->flags & (FTPC_FLAG_READING | FTPC_FLAG_SENDING)) == 0)
    pt->timeout   = 0;
  //debug_puts("ftpc: sent");
  return ERR_OK;
}

static err_t ftpc_cb_poll(void *arg, struct tcp_pcb *tpcb) {
  ftpc_handle_t* pt = arg;

  assert(pt != NULL);

  if(pt->flags & (FTPC_FLAG_READING | FTPC_FLAG_SENDING)) {
    if((pt->timeout > 0) && (--pt->timeout == 0)) {
        pt->state         = FTPC_TIMEOUT;
        pt->flags         &= ~(FTPC_FLAG_READING | FTPC_FLAG_SENDING);
        pt->timeout       = 0;
    }
  }
  //debug_puts("ftpc: poll");
  return ERR_OK;

}
static err_t ftpc_send_cmd(ftpc_handle_t* pt, char *cmd, char *arg) {
  int   res;
  err_t err;

  res = ftpc_prepare_cmd_buffer(cmd, arg, pt->p_tx);
  if((err = tcp_write(pt->ctrl_pcb, pt->p_tx->payload, res, 1)) != ERR_OK) {
      debug_puts("ftpc: Cannot write command");
      return err;
  }
  return err;
}

// "227 Entering Passive Mode (192,168,1,18,5,8)" port=5*256+8
static int ftpc_parse_pasv_answer(char* buf, int buf_sz, struct ip_addr* dest_ip) {
  uint8_t       ip[4];
  char*         str_beg;
  char*         str_end;
  int           index;
  int           dest_port = 0;

  assert(buf != NULL);
  assert(dest_ip != NULL);

  if((str_beg = memchr(buf, '(', buf_sz)) == NULL)
    return 0;

  for(index = 0; index < 6; index++) {
    ++str_beg;
    switch(index) {
    case 0:
    case 1:
    case 2:
    case 3:
      ip[index] = strtol(str_beg, &str_end, 0);
      break;
    case 4:
      dest_port = strtol(str_beg, &str_end, 0)*256;
      break;
    case 5:
      dest_port += strtol(str_beg, &str_end, 0);
      break;
    }
    if(str_beg == str_end)
      return 0;
    str_beg = str_end;
  }

  IP4_ADDR(dest_ip, ip[0], ip[1], ip[2], ip[3]);

  return dest_port;
}

static void ftpc_cb_data_error(void * arg, err_t err) {
  debug_printf("ftpc: data error - %d\n", err);
}


bool ftpc_is_busy(ftpc_handle_t* pt) {
  assert(pt != NULL);
  return !((pt->state == FTPC_IDLE) || (pt->state == FTPC_READY));
}

int  ftpc_disconnect(ftpc_handle_t* pt) {
  assert(pt != NULL);
  if(pt->state == FTPC_READY)
    pt->state = FTPC_CLOSE;
  else
    return 0;
  return 1;
}

int ftpc_cwd(ftpc_handle_t* pt, const char* path) {
  assert(pt != NULL);
  assert(path != NULL);

  if(pt->state != FTPC_READY)
    return 0;

  if((pt->error = ftpc_send_cmd(pt, "CWD", path)) != ERR_OK)
    return 0;

  pt->flags |= (FTPC_FLAG_READING | FTPC_FLAG_SENDING);
  pt->timeout= FTPC_OP_SENT_READ_TIMEOUT;

  pt->state = FTPC_CHANGING_DIR;
  return 1;
}

int  ftpc_retrieve(ftpc_handle_t* pt, char* filename) {
  assert(pt != NULL);
  assert(filename != NULL);

  if(pt->state != FTPC_READY)
    return 0;

  ftpc_data_close(pt);

  if((pt->data_pcb  = tcp_new()) == NULL) {
      pt->error = FTPC_ERR_MEMORY;
      return FTPC_ERR_MEMORY;
  }

  tcp_err(pt->data_pcb, ftpc_cb_data_error);

  pt->filename = filename;

  pt->state = FTPC_OPEN;
  return 1;
}
#if 1
int  ftpc_abort(ftpc_handle_t* pt) {
  assert(pt != NULL);

  if((pt->error = ftpc_send_cmd(pt, "ABOR", NULL)) != ERR_OK)
    return 0;

  pt->flags |= (FTPC_FLAG_READING | FTPC_FLAG_SENDING);
  pt->timeout= FTPC_OP_SENT_READ_TIMEOUT;

  pt->state = FTPC_ABORT;

  return 1;
}
#endif
int  ftpc_data_close(ftpc_handle_t* pt) {
  assert(pt != NULL);

  if(pt->data_pcb == NULL)
    return 0;

  tcp_recv(pt->data_pcb, NULL);
  tcp_sent(pt->data_pcb, NULL);
  tcp_poll(pt->data_pcb, NULL, 0);
  tcp_err(pt->data_pcb, NULL);
  // Abort connection and free memory
  tcp_abort(pt->data_pcb);

  pt->data_pcb = NULL;

  return 1;
}
