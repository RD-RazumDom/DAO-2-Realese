/**
  ******************************************************************************
  * @file    netconf.c
  * @author
  * @version
  * @date
  * @brief   Network connection configuration
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "lwip/mem.h"
#include "lwip/memp.h"
#include "lwip/tcp.h"
#include "lwip/udp.h"
#include "netif/etharp.h"
#include "lwip/dhcp.h"
#include "lwip/timers.h"
#include "lwip/init.h"
#include "ethernetif.h"
#include "main.h"
#include "netconf.h"
#include <stdio.h>
#include "debug.h"


/* Private typedef -----------------------------------------------------------*/
#define MAX_DHCP_TRIES        5

/* Private define ------------------------------------------------------------*/
typedef enum 
{ 
  DHCP_START=0,
  DHCP_WAIT_ADDRESS,
  DHCP_ADDRESS_ASSIGNED,
  DHCP_TIMEOUT,
  DHCP_STOP
} 
DHCP_State_TypeDef;
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
struct netif eth0;
//uint32_t TCPTimer = 0;
//uint32_t ARPTimer = 0;

#ifdef USE_DHCP
//uint32_t DHCPfineTimer = 0;
//uint32_t DHCPcoarseTimer = 0;
DHCP_State_TypeDef DHCP_state = DHCP_START;
#endif

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Initializes the lwIP stack
  * @param  None
  * @retval None
  */
void netconf_init(struct ip_addr *ipaddr, struct ip_addr *netmask, struct ip_addr *gw)
{

  lwip_init();

#ifdef USE_DHCP
  if(ipaddr->addr == 0) {
    netmask->addr = 0;
    gw->addr = 0;
  } else
#endif //USE_DHCP
  {
  #ifndef NDEBUG
    uint8_t iptab[4];
    char iptxt[20];
  #endif // #ifndef NDEBUG
     DHCP_state = DHCP_STOP;
  #ifndef NDEBUG
     iptab[0] = ip4_addr4(ipaddr);
     iptab[1] = ip4_addr3(ipaddr);
     iptab[2] = ip4_addr2(ipaddr);
     iptab[3] = ip4_addr1(ipaddr);

     snprintf((char*)iptxt, sizeof(iptxt), "  %d.%d.%d.%d", iptab[3], iptab[2], iptab[1], iptab[0]);

     debug_puts("  Static IP address   ");
     debug_puts(iptxt);
  #endif //#ifndef NDEBUG

  }


  /* - netif_add(struct netif *netif, struct ip_addr *ipaddr,
            struct ip_addr *netmask, struct ip_addr *gw,
            void *state, err_t (* init)(struct netif *netif),
            err_t (* input)(struct pbuf *p, struct netif *netif))
    
   Adds your network interface to the netif_list. Allocate a struct
  netif and pass a pointer to this structure as the first argument.
  Give pointers to cleared ip_addr structures when using DHCP,
  or fill them with sane numbers otherwise. The state pointer may be NULL.

  The init function pointer must point to a initialization function for
  your ethernet netif interface. The following code illustrates it's use.*/
  netif_add(&eth0, ipaddr, netmask, gw, NULL, &ethernetif_init, &ethernet_input);

  /*  Registers the default network interface.*/
  netif_set_default(&eth0);
#ifdef USE_DHCP
  if(ipaddr->addr == 0)
    dhcp_start(&eth0);
  else
#endif
    netif_set_up(&eth0);
}

/**
  * @brief  Called when a frame is received
  * @param  None
  * @retval None
  */
void netconf_pkt_handle(void)
{
  /* Read a received packet from the Ethernet buffers and send it to the lwIP for handling */
  err_t err = ethernetif_input(&eth0);
  if(err != ERR_OK) {
      debug_printf("netconf_pkt_handle: %d\n", err);
  }
}

/**
  * @brief  LwIP periodic tasks
  * @param  localtime the current LocalTime value
  * @retval None
  */
void netconf_periodic_handle(__IO uint32_t localtime)
{

  sys_check_timeouts();

  switch(eth0.dhcp->state){
  case  DHCP_BOUND:
    if(DHCP_state != DHCP_ADDRESS_ASSIGNED) {
#ifndef NDEBUG
      uint32_t IPaddress = eth0.ip_addr.addr;
      uint8_t iptab[4];
      char iptxt[20];
#endif //#ifndef NDEBUG
      DHCP_state = DHCP_ADDRESS_ASSIGNED;
#ifndef NDEBUG
      iptab[0] = (uint8_t)(IPaddress >> 24);
      iptab[1] = (uint8_t)(IPaddress >> 16);
      iptab[2] = (uint8_t)(IPaddress >> 8);
      iptab[3] = (uint8_t)(IPaddress);

      snprintf((char*)iptxt, sizeof(iptxt), " %d.%d.%d.%d", iptab[3], iptab[2], iptab[1], iptab[0]);

      /* Display the IP address */
      debug_puts("IP address assigned ");
      debug_puts("  by a DHCP server  ");
      debug_puts(iptxt);
#endif //#ifndef NDEBUG
    }
    break;

  }
}


/*****END OF FILE****/
