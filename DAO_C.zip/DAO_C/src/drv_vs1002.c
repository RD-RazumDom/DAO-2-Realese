/*************************************************************************
 *    File name   : drv_vs1002.c
 *    Description : VS1002 driver
**************************************************************************/
#include <stdint.h>
#include <stdbool.h>
#include "stm32f2xx.h"
#include "drv_vs1002.h"

#define MP3_VER(var)       ((var)?var:MP3_Pass)
#define MP3_SHORT(var)     ((var)?MP3_Fault:MP3_Pass)

#define MP3_RET(var) return((MP3_STATUS_VERBOSE?MP3_VER(var):MP3_SHORT(var)))

//#define MP3_BOOT_SEL  GPIO_Pin_7  // PB7
#define MP3_RST       GPIO_Pin_3  // PE3
#define MP3_RST_PORT  GPIOE       // PE3

#define MP3_DATA_RQ   GPIO_Pin_6  // PD6
#define MP3_DATA_RQ_PORT   GPIOD  // PD6
//#define MP3_GPIO1     GPIO_Pin_12  // PB12, this pin should be LOW when releasing reset

#define MP3_CS        GPIO_Pin_7  // PD7
#define MP3_CS_PORT   GPIOD       // PD7
#define MP3_DCS       GPIO_Pin_5  // PD5
#define MP3_DCS_PORT  GPIOD  // PD5

#define MP3_MOSI      GPIO_Pin_5  // PB5
#define MP3_MISO      GPIO_Pin_4  // PB5
#define MP3_SCLK      GPIO_Pin_3  // PB3

#define MP3_MOSI_Source      GPIO_PinSource5  // PB5
#define MP3_MISO_Source      GPIO_PinSource4  // PB5
#define MP3_SCLK_Source      GPIO_PinSource3  // PB3

#define MP3_SPI_PORT  GPIOB
#define MP3_SPI       SPI3


bool PlayFile = 0;     // Play in progress


/*************************************************************************
 * Function Name: MP3_Reset
 * Parameters: bool Select
 * Return: none
 *
 * Description: MP3 reset and disable booting from external EEPROM, released reset is only pulled up by resistor
 * Select = true  - Reset the VS1002
 * Select = false - Release reset of the VS1002
 *
 *************************************************************************/
static void MP3_Reset (bool Select)
{
  GPIO_InitTypeDef  GPIO_InitStructure;

  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Pin = MP3_RST;

  if(Select) {
#ifdef       MP3_BOOT_SEL
	  // Set the Boot select low
	  GPIO_WriteBit(GPIOB, MP3_BOOT_SEL,Bit_RESET);
	  	
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);
#endif //MP3_BOOT_SEL
	  GPIO_WriteBit(MP3_RST_PORT, MP3_RST, Bit_RESET); // make 0
  }
  else {
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	  GPIO_Init(MP3_RST_PORT, &GPIO_InitStructure);
  }
}

/*************************************************************************
 * Function Name: MP3_DReq
 * Parameters: none
 * Return: bool
 *
 * Description: Return state of the DREQ line
 *
 *************************************************************************/
bool MP3_DReq (void)
{
  return(GPIO_ReadInputDataBit(MP3_DATA_RQ_PORT, MP3_DATA_RQ) == Bit_SET);
}

/*************************************************************************
 * Function Name: MP3_ChipSelect
 * Parameters: bool Select
 * Return: none
 *
 * Description: MP3 chip select control
 * Select = true  - Chip is enable - command
 * Select = false - Chip is disable - data
 *
 *************************************************************************/
static inline
void MP3_ChipSelect (bool Select)
{
  GPIO_WriteBit(MP3_CS_PORT, MP3_CS, Select ? Bit_RESET : Bit_SET);
}

/*************************************************************************
 * Function Name: MP3_SetClockFreq
 * Parameters: uint32_t Frequency
 * Return: uint32_t
 *
 * Description: Set SPI ckl frequency
 *
 *************************************************************************/
static inline
uint32_t MP3_SetClockFreq (uint32_t Frequency)
{
uint32_t Div = 2;
uint32_t DivVal = 0;
RCC_ClocksTypeDef Clk;

  RCC_GetClocksFreq(&Clk);

  while((Frequency * Div) <=  Clk.PCLK2_Frequency)
  {
    Div <<= 1;
    if (++DivVal == 7)
    {
      break;
    }
  }

  MP3_SPI->CR1 = (MP3_SPI->CR1 & ~(0x7 << 3)) | ((DivVal&0x7) << 3);

  // Return real frequency
  return(Clk.PCLK2_Frequency/Div);
}

/*************************************************************************
 * Function Name: MP3_TranserByte
 * Parameters: uint8_t ch
 * Return: uint16_t
 *
 * Description: Read 8 bits from SPI
 *
 *************************************************************************/
uint16_t MP3_TranserByte (uint8_t ch)
{
  SPI_I2S_SendData(MP3_SPI, ch);
  while(SPI_I2S_GetFlagStatus(MP3_SPI, SPI_I2S_FLAG_RXNE) == RESET);
  return(SPI_I2S_ReceiveData(MP3_SPI));
}

/*************************************************************************
 * Function Name: Mp3ModuleInit
 * Parameters: none
 * Return: MP3_Status_t
 *          MP3_Pass, MP3_Fault or MP3_WrongRev, MP3_NotComm
 *
 * Description: Initialize MP3 module (VS1002)
 *
 *************************************************************************/
static inline
MP3_Status_t Mp3ModuleInit (void)
{
SPI_InitTypeDef   SPI_InitStructure;
GPIO_InitTypeDef  GPIO_InitStructure;
uint32_t i;

  // Initialize MP3_SPI, Timer1 and IO
  // Enable GPIO clocks
  RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOB
                        | RCC_AHB1Periph_GPIOD
                        | RCC_AHB1Periph_GPIOE
                        , ENABLE);
  // Enable MP3_SPI, Timer1
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3
                        , ENABLE);
  // Deinitializes the SPI1
  SPI_I2S_DeInit(MP3_SPI);

  // Release reset of GPIOs
  RCC_AHB1PeriphResetCmd(  RCC_AHB1Periph_GPIOB
                        | RCC_AHB1Periph_GPIOD
                        | RCC_AHB1Periph_GPIOE
                         , DISABLE);

  // Configure Boot and chip select pin
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Pin   =  MP3_CS;
  GPIO_Init(MP3_CS_PORT, &GPIO_InitStructure);

#ifdef MP3_BOOT_SEL
  MP3_BOOT_SEL | ;
#endif

  // Configure data chip select pin
  GPIO_InitStructure.GPIO_Pin = MP3_DCS;
  GPIO_Init(MP3_DCS_PORT, &GPIO_InitStructure);
  GPIO_WriteBit(MP3_DCS_PORT, MP3_DCS, Bit_SET);

#ifdef MP3_GPIO1
  // The following is a workaround, because the audio codec does not start properly when pin is not LOW when releasing reset,
  // i.e. audio codec starts in MIDI mode with GPIO0 = 0, and GPIO1 = 1
  // Configure GPIO1 to be LOW when releasing reset
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Pin = MP3_GPIO1;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  GPIO_WriteBit(GPIOB, MP3_GPIO1, Bit_RESET);
#endif //MP3_GPIO1

  // Configure data request pin
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Pin = MP3_DATA_RQ;
  GPIO_Init(MP3_DATA_RQ_PORT, &GPIO_InitStructure);

  // Configure MP3_SPI_CLK, MP3_SPI_MOSI and MP3_SPI_MISO pins
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Pin = MP3_SCLK | MP3_MOSI | MP3_MISO;
  GPIO_Init(MP3_SPI_PORT, &GPIO_InitStructure);

  GPIO_PinAFConfig(MP3_SPI_PORT, MP3_SCLK_Source, GPIO_AF_SPI3);
  GPIO_PinAFConfig(MP3_SPI_PORT, MP3_MOSI_Source, GPIO_AF_SPI3);
  GPIO_PinAFConfig(MP3_SPI_PORT, MP3_MISO_Source, GPIO_AF_SPI3);

  // SPI init
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(MP3_SPI, &SPI_InitStructure);

  // Disable DMA
  SPI_I2S_DMACmd(MP3_SPI,SPI_I2S_DMAReq_Rx,DISABLE);
  SPI_I2S_DMACmd(MP3_SPI,SPI_I2S_DMAReq_Tx,DISABLE);

  // Clock Freq <= 2MHz
  MP3_SetClockFreq(MP3_CLK_FREQ);

  // Enable MP3_SPI
  SPI_Cmd(MP3_SPI, ENABLE);

  // Deselect chip
  MP3_ChipSelect(0);

  // Deinitialization MP3 module (VS1002)
  MP3_Reset(1);
  delay(100);
  MP3_Reset(0);
  delay(100);

  // Wait XRESET inactive to DREQ low (<= 400us)
  for(i = 8;i;--i)
  {
    if (!MP3_DReq())
    {
      break;
    }
    delay(1);
  }
//  if (!i)
//  {
//    MP3_RET(MP3_NotComm);
//  }

  // Wait XRESET inactive to software ready (<= 4ms)
  for(i = 80;i;--i)
  {
    if (MP3_DReq())
    {
      break;
    }
    delay(1);
  }
  if (!i)
  {
    MP3_RET(MP3_NotComm);
  }

  // Wait 100ms
  delay(100);

  // Get the chip ID
  Mp3SendCmd(Mp3CmdGetRevision,&i);
  if (i != MP3_VS1002_REV)
  {
    MP3_RET(MP3_WrongRev);
  }
  // Init Clk
  i = 0x9800; // 12.288MHz * 2
  Mp3SendCmd(Mp3CmdSetClkReg,&i);
  // Init Mode
  // VS1002 native SPI modes, Share SPI chip select
  i = 0x0C00 |
     (MP3_PLUS_V_ENA?1UL<<7:0); // +V mode
  Mp3SendCmd(Mp3CmdSetModeReg,&i);

  PlayFile = 0;

  MP3_RET(MP3_Pass);
}

/*************************************************************************
 * Function Name: Mp3Transmit
 * Parameters: uint32_t* pData , uint32_t Size,
 *             bool StreamMode, bool SrcAddInc
 * Return: none
 *
 * Description: Transmit data
 *
 *************************************************************************/
static
void Mp3Transmit(uint32_t* pData , uint32_t Size, bool StreamMode, bool SrcAddInc)
{
uint32_t Tmp;
int32_t iSize = Size;
  MP3_ChipSelect(0);

  while(iSize > 0)
  {
    if(StreamMode)
      while(!MP3_DReq());
    for(int i = 8; i; --i)
    {
      Tmp = *pData;
      MP3_TranserByte(Tmp    );
      if(--iSize <= 0) break;
      MP3_TranserByte(Tmp>> 8);
      if(--iSize <= 0) break;
      MP3_TranserByte(Tmp>>16);
      if(--iSize <= 0) break;
      MP3_TranserByte(Tmp>>24);
      if(--iSize <= 0) break;
      if(SrcAddInc)
      {
        ++pData;
      }
    }
  }
}

/*************************************************************************
 * Function Name: Mp3SendCmd
 * Parameters: MP3_Cmd_t Cmd, uint32_t* pData
 * Return: none
 *
 * Description: Send command to the MP3 module (VS1002)
 *
 *************************************************************************/
void Mp3SendCmd (MP3_Cmd_t Cmd, uint32_t* pData)
{
uint32_t Tmp,Size;
pMp3Stream_t pMp3Stream;

  switch (Cmd)
  {
  case Mp3CmdPowerUp:
    *pData = Mp3ModuleInit();
    break;
  case Mp3CmdPowerDown:
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_ReadCmd);
    MP3_TranserByte(MP3_STATUS);
    Tmp = (MP3_TranserByte(0) << 8) & 0xFF00;
    Tmp|=  MP3_TranserByte(0)       & 0x00FF;
    MP3_ChipSelect(0);
    // Set SS APDOWN2 bit (3)
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_WriteCmd);
    MP3_TranserByte(MP3_STATUS);
    MP3_TranserByte(Tmp >> 8);
    MP3_TranserByte(Tmp | (1UL<<3));
    MP3_ChipSelect(0);
    // Wait 10ms
    delay(10);
    // Reset VS1002
    MP3_Reset(1);
    break;
  case Mp3CmdGetRevision:
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_ReadCmd);
    MP3_TranserByte(MP3_STATUS);
    MP3_TranserByte(0);
    Tmp = MP3_TranserByte(0);
    *pData = (Tmp>>4) & 0x7;
    MP3_ChipSelect(0);
    break;
  case Mp3CmdSetClkReg:
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_WriteCmd);
    MP3_TranserByte(MP3_CLOCKF);
    MP3_TranserByte(*pData>>8);
    MP3_TranserByte(*pData   );
    MP3_ChipSelect(0);
    break;
  case Mp3CmdSetModeReg:
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_WriteCmd);
    MP3_TranserByte(MP3_MODE);
    MP3_TranserByte(*pData>>8);
    MP3_TranserByte(*pData   );
    MP3_ChipSelect(0);
    break;
  case Mp3CmdSetVol:
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_WriteCmd);
    MP3_TranserByte(MP3_VOL);
    MP3_TranserByte(*pData>>8);
    MP3_TranserByte(*pData   );
    MP3_ChipSelect(0);
    break;
  case Mp3CmdTstSin:
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_ReadCmd);
    MP3_TranserByte(MP3_MODE);
    Tmp = (MP3_TranserByte(0) << 8) & 0xFF00;
    Tmp|=  MP3_TranserByte(0)       & 0x00FF;
    MP3_ChipSelect(0);
    // Set test bit
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_WriteCmd);
    MP3_TranserByte(MP3_MODE);
    MP3_TranserByte(Tmp >> 8);
    MP3_TranserByte(Tmp | (1UL << 5));
    MP3_ChipSelect(0);
    if(*pData)
    {
      // Send test command sequence
      MP3_TranserByte(0x53);
      MP3_TranserByte(0xEF);
      MP3_TranserByte(0x6E);
      MP3_TranserByte(*pData);
      MP3_TranserByte(0x00);
      MP3_TranserByte(0x00);
      MP3_TranserByte(0x00);
      MP3_TranserByte(0x00);
    }
    else
    {
      // Send exit form the test command sequence
      MP3_TranserByte(0x45);
      MP3_TranserByte(0x78);
      MP3_TranserByte(0x69);
      MP3_TranserByte(0x74);
      MP3_TranserByte(0x00);
      MP3_TranserByte(0x00);
      MP3_TranserByte(0x00);
      MP3_TranserByte(0x00);
    }
    delay(100);
    // Clear test bit
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_WriteCmd);
    MP3_TranserByte(MP3_MODE);
    MP3_TranserByte(Tmp>>8);
    MP3_TranserByte(Tmp   );
    MP3_ChipSelect(0);
    break;
  case Mp3CmdPlay:
    // Wait until data transfer is active
    pMp3Stream = (pMp3Stream_t)pData;
    if (pMp3Stream->Size)
    {
      // for synchronization
      MP3_ChipSelect(1);
      if(!PlayFile)
      {
        Size = VS1002_BUFFER_SIZE/2;
        Size = MIN(pMp3Stream->Size,Size);
        PlayFile = 1;
        if((pMp3Stream->Size -= Size) == 0)
        {
          break;
        }
      }
      Mp3Transmit(pMp3Stream->pStream,pMp3Stream->Size, true, true);
      break;
    }
  case Mp3CmdPlayStop:
    MP3_ChipSelect(1);
    // Init Transfer of 2048 zero (clear on-chip buffer)
    Tmp = 0;
    Mp3Transmit(&Tmp,2048, false, false);
    PlayFile = 0;
    break;
  case Mp3CmdWideStereo:
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_ReadCmd);
    MP3_TranserByte(MP3_MODE);
    Tmp = (MP3_TranserByte(0) << 8) & 0xFF00;
    Tmp|=  MP3_TranserByte(0)       & 0x00FF;
    MP3_ChipSelect(0);
    if(*pData)
    {
      Tmp |= 1;
    }
    else
    {
      Tmp &= ~1;
    }
    // Set test bit
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_WriteCmd);
    MP3_TranserByte(MP3_MODE);
    MP3_TranserByte(Tmp >> 8);
    MP3_TranserByte(Tmp | (1UL << 5));
    MP3_ChipSelect(0);
    break;
  case Mp3CmdLoudness:
    Tmp = *pData?0x8A:0;
    MP3_ChipSelect(1);
    MP3_TranserByte(MP3_WriteCmd);
    MP3_TranserByte(MP3_BASS);
    MP3_TranserByte(Tmp>>8);
    MP3_TranserByte(Tmp   );
    MP3_ChipSelect(0);
    break;
  }
}

