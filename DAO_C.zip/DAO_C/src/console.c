/*
 * console.c
 *
 *  Created on: 08 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */
#include "console.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "debug.h"


static console_func_desc_t* console_process_command(console_handle_t* pt);


void console_init(console_handle_t* pt) {
  int res = 0;

  assert(pt != NULL);

  PT_INIT(pt);

  if(pt->init != NULL)
      res = pt->init();
  /* Initialize internal data structures */
  pt->state            = (res < 0) ? CONSOLE_FAIL : CONSOLE_INIT;
  pt->buffer_in_index  = 0;
  pt->child.getch      = pt->getch;
  pt->child.putch      = pt->putch;
}


int console_process(console_handle_t* pt) {
  int ch;

  assert(pt != NULL);

  PT_BEGIN(pt);

  if((pt->state == CONSOLE_FAIL) || (pt->state == CONSOLE_NONE))
    PT_EXIT(pt);

  CONSOLE_PUTS(pt, CONSOLE_PROMT_LINE);
  pt->state = CONSOLE_PROCESS;

  while(1) {
    PT_WAIT_WHILE(pt,((ch = pt->getch()) == -1));

    if((ch == ASCII_LF) || (ch == ASCII_CR)) {
      pt->buffer_in[pt->buffer_in_index] = 0;
      if(pt->buffer_in_index) {
        CONSOLE_PUTS(pt, CONSOLE_NEW_LINE);
        pt->child_desc = console_process_command(pt);
        if(pt->child_desc != NULL) {
          PT_SPAWN(pt, &pt->child, pt->child_desc->func(&pt->child, pt->argc, pt->argv));
        } else {
          CONSOLE_PUTS(pt, "Unknown command - ");
          CONSOLE_PUTS(pt, pt->argv[0]);
        }
        pt->buffer_in_index = 0;
      }
      CONSOLE_PUTS(pt, CONSOLE_PROMT_LINE);
    } else if((ch == ASCII_DEL) || (ch == ASCII_BS)) {
      if(pt->buffer_in_index) {
        CONSOLE_PUTS(pt, CONSOLE_BACKSPACE);
        pt->buffer_in_index--;
      }
      pt->buffer_in[pt->buffer_in_index] = 0;
    } else {
      if(pt->buffer_in_index < (pt->buffer_in_sz-1)) {
        pt->buffer_in[pt->buffer_in_index] = ch;
        PT_WAIT_WHILE(pt, pt->putch(pt->buffer_in[pt->buffer_in_index]) == -1);
        pt->buffer_in_index++;
      } else {
          /// FIXME Show error message
      }
    }
  }

  PT_END(pt);
}



static console_func_desc_t* console_process_command(console_handle_t* pt) {
  char* s;

  if(pt->buffer_in_index == 0)
    return NULL;

  pt->argc = 0;

  for(s = pt->buffer_in; *s != 0; s++) {
      if(isspace((int)*s))
        continue;
      pt->argv[pt->argc++] = s;
      if(pt->argc >= CONSOLE_MAX_ARGC)
        break;
      while(!isspace((int)*s) && ((int)*s != 0))
        s++;
      if(*s != 0)
        *s = 0;
      else
        break;
  };

  if(pt->argc != 0)
    return console_find_function(pt->func_desc, pt->argv[0]);
  return NULL;
}

console_func_desc_t* console_find_function(console_func_desc_t* func_descs, const char* name) {

  assert(func_descs != NULL);
  assert(name != NULL);

  while(func_descs->name != NULL ) {
      if(strncmp(func_descs->name, name, CONSOLE_FUNC_NAME_MAX_LENGTH) == 0)
        break;
      func_descs++;
  }
  if(func_descs->name == NULL)
    func_descs = NULL;
  return func_descs;
}
