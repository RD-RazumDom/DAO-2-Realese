/*
 * media.c
 *
 *  Created on: 22 дек. 2014 г.
 *      Author: Dmitry Rudakov
 */
#include <stdlib.h>
#include <assert.h>
#include "media.h"
#include "drv_vs1002.h"
#include "debug.h"

#define MEDIA_DEFAULT_VOLUME            (0x18)

int media_init(media_handle_t* pt) {
  uint32_t  mp3_param;

  assert(pt != NULL);

  PT_INIT(pt);
  PT_SEM_INIT(&pt->buffer_empty, 0);
  PT_SEM_INIT(&pt->buffer_full, 0);

  pt->state = MEDIA_FAILURE;

  /* VS1053 */
  Mp3SendCmd(Mp3CmdPowerUp, &mp3_param);
  if(mp3_param != 0) {
      debug_printf("Failed to initialize vs1053 - %d\n", mp3_param);
      return MEDIA_FAIL;
  }

  pt->volume = MEDIA_DEFAULT_VOLUME;
  mp3_param = pt->volume | (((uint32_t)pt->volume) << 8);
  Mp3SendCmd(Mp3CmdSetVol, &mp3_param);

  pt->bass_control= 0;
  mp3_param = pt->bass_control;
  Mp3SendCmd(Mp3CmdLoudness, &mp3_param);

  pt->state = MEDIA_INITIALIZED;
  return MEDIA_OK;
}

int media_process(media_handle_t* pt) {
#if 0
  Mp3Stream_t                stream;
#endif
  uint32_t                   Tmp;
  static int                 iSize;
  static uint32_t*           pData;

  assert(pt != NULL);

  PT_BEGIN(pt);

  while(1) {
    if(pt->state == MEDIA_FAILURE)
        PT_EXIT(pt);

    if(pt->state == MEDIA_PLAYING) {
      PT_SEM_WAIT(pt, &pt->buffer_full);

      assert(pt->buffer_sz);
      assert(pt->buffer != NULL);
#if 0
      PT_WAIT_WHILE(pt, (MP3_DReq() == 0));
      stream.Size = pt->buffer_sz;
      stream.pStream = pt->buffer;
      stream.PlaySpeed = Mp3PlayNorm;
      Mp3SendCmd(Mp3CmdPlay,(uint32_t*)&stream);
#else
      iSize = pt->buffer_sz;
      pData = pt->buffer;

      while((iSize > 0) && (pt->state == MEDIA_PLAYING))
      {
        PT_WAIT_WHILE(pt, (MP3_DReq() == 0));
        for(int i = 8; i > 0; --i)
        {
          Tmp = *pData;
          MP3_TranserByte(Tmp    );
          if(--iSize <= 0) break;
          MP3_TranserByte(Tmp>> 8);
          if(--iSize <= 0) break;
          MP3_TranserByte(Tmp>>16);
          if(--iSize <= 0) break;
          MP3_TranserByte(Tmp>>24);
          if(--iSize <= 0) break;
          ++pData;
        }
      }
#endif
      if(pt->state == MEDIA_PLAYING)
        PT_SEM_SIGNAL(pt, &pt->buffer_empty);

    } else {
        PT_YIELD(pt);
    }
  }
  PT_END(pt);
}

int media_exec_cmd(media_handle_t* pt, media_cmd_t cmd) {

  assert(pt != NULL);

  switch(cmd) {
  case MEDIA_CMD_STOP:
    if((pt->state == MEDIA_PLAYING) || (pt->state == MEDIA_PAUSED)) {
        Mp3SendCmd(Mp3CmdPlayStop, NULL);
        pt->state = MEDIA_STOPED;
        PT_INIT(pt);
        PT_SEM_INIT(&pt->buffer_empty, 0);
        PT_SEM_INIT(&pt->buffer_full, 0);
    }
    break;
  case MEDIA_CMD_PLAY:
    if((pt->state == MEDIA_STOPED) || (pt->state == MEDIA_PAUSED) || ((pt->state == MEDIA_INITIALIZED))) {
        pt->state = MEDIA_PLAYING;
        PT_SEM_SIGNAL(pt, &pt->buffer_empty);
    }
    break;
  case MEDIA_CMD_PAUSE:
    if(pt->state == MEDIA_PLAYING) {
        pt->state = MEDIA_PAUSED;
    }
    break;
  }
  return MEDIA_OK;
}

media_state_t media_get_state(media_handle_t* pt) {

  assert(pt != NULL);

  return pt->state;
}

int media_set_volume(media_handle_t* pt, uint8_t volume) {
  uint32_t  mp3_param;

  pt->volume = 0xFE - volume;

  mp3_param = (pt->volume/2) | (((uint32_t)pt->volume/2) << 8);

  Mp3SendCmd(Mp3CmdSetVol, &mp3_param);

  return pt->volume;
}


uint8_t media_get_volume(media_handle_t* pt) {
  return 0xFEU - pt->volume;
}


int media_set_bass_control(media_handle_t* pt, uint16_t control) {
	uint32_t  mp3_param;

	pt->bass_control= control;

	mp3_param = pt->bass_control;

	Mp3SendCmd(Mp3CmdLoudness, &mp3_param);
	return pt->bass_control;
}

uint16_t media_get_bass_control(media_handle_t* pt) {
	return pt->bass_control;
}
int media_set_earspeaker(media_handle_t* pt, uint16_t control) {
	uint32_t  mp3_param;

	pt->earspeaker= control;

	mp3_param = 0x0C00 | pt->earspeaker;

	Mp3SendCmd(Mp3CmdSetModeReg, &mp3_param);
	return pt->earspeaker;
}
uint16_t media_get_earspeaker(media_handle_t* pt) {
	return pt->earspeaker;
}
