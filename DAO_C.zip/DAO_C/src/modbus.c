/**
  ******************************************************************************
  * @file    modbus.c 
  * @author  Dmitry Rudakov
  * @brief   Provide API for general ModBus functionality
  ******************************************************************************
 **/ 

#include "modbus.h"

/// Calculate CRC for packet
uint16_t modbus_calc_crc(uint8_t* packet, uint16_t  data_sz) {
  uint16_t crc = 0xFFFFU, i = 0;
  uint8_t  j;

  while (i < data_sz)
  {
    crc ^= packet[i];
    i++;
    j = 8;
    while (j > 0)
    {
      j--;
      if (crc & 1)
      {
        crc >>= 1;
        crc ^= (uint16_t)0xA001U;
      }
      else
        crc >>= 1;
    }
  }
  return crc;
}
