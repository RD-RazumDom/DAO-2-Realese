

#include "lwip/debug.h"
#include "lwip/stats.h"
#include "lwip/tcp.h"
#include "modbus_slave.h"
#include "modbus_tcp_server.h"
#include "netconf.h"
#include "debug.h"

#if LWIP_TCP

static struct tcp_pcb *modbus_tcp_server_pcb;
static uint8_t modbus_address = MODBUS_DEFAULT_ADDRESS;

/* ECHO protocol states */
enum modbus_tcp_server_states
{
  ES_NONE = 0,
  ES_ACCEPTED,
  ES_RECEIVED,
  ES_CLOSING
};

typedef struct modbus_tcp_header_s {
  /* Transaction Identifier  */
  uint16_t      transaction_id;
  /* Protocol Identifier */
  uint16_t      protocol_id;
  /* Number of following bytes (length)*/
  uint16_t      length;
} modbus_tcp_header_t;

struct modbus_tcp_packet_s {
  /* Header */
  modbus_tcp_header_t   header;
  /* Modbus RTU packet */
  modbus_packet_t       packet;
};


/* structure for maintaing connection infos to be passed as argument
   to LwIP callbacks*/
struct modbus_tcp_server_s
{
  u8_t state;             /* current connection state */
  struct tcp_pcb *pcb;    /* pointer on the current tcp_pcb */
  struct pbuf *p_rx;         /* pointer on the received pbuf */
  struct pbuf *p_tx;         /* pointer to be transmitted pbuf */
  struct modbus_tcp_packet_s      modbus_tcp_packet;
};


static err_t modbus_tcp_server_accept(void *arg, struct tcp_pcb *newpcb, err_t err);
static err_t modbus_tcp_server_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err);
static void modbus_tcp_server_error(void *arg, err_t err);
static err_t modbus_tcp_server_poll(void *arg, struct tcp_pcb *tpcb);
static err_t modbus_tcp_server_sent(void *arg, struct tcp_pcb *tpcb, u16_t len);
static void modbus_tcp_server_send(struct tcp_pcb *tpcb, struct modbus_tcp_server_s *es);
static void modbus_tcp_server_connection_close(struct tcp_pcb *tpcb, struct modbus_tcp_server_s *es);
static err_t modbus_tcp_process_pbuf(struct tcp_pcb *tpcb, struct modbus_tcp_server_s* es);



/**
  * @brief  Initializes the tcp echo server
  * @param  None
  * @retval None
  */
void modbus_tcp_server_init(uint8_t unit)
{
  modbus_address = unit;
  /* create new tcp pcb */
  modbus_tcp_server_pcb = tcp_new();

  if (modbus_tcp_server_pcb != NULL)
  {
    err_t err;
    
    /* bind echo_pcb to port MODBUS_TCP_PORT */
    err = tcp_bind(modbus_tcp_server_pcb, IP_ADDR_ANY, MODBUS_TCP_PORT);
    
    if (err == ERR_OK)
    {
      /* start tcp listening for echo_pcb */
      modbus_tcp_server_pcb = tcp_listen(modbus_tcp_server_pcb);
      
      /* initialize LwIP tcp_accept callback function */
      tcp_accept(modbus_tcp_server_pcb, modbus_tcp_server_accept);
    }
    else 
    {
        debug_printf("Can not bind pcb\n");
    }
  }
  else
  {
      debug_printf("Can not create new pcb\n");
  }
}

/**
  * @brief  This function is the implementation of tcp_accept LwIP callback
  * @param  arg: not used
  * @param  newpcb: pointer on tcp_pcb struct for the newly created tcp connection
  * @param  err: not used 
  * @retval err_t: error status
  */
static err_t modbus_tcp_server_accept(void *arg, struct tcp_pcb *newpcb, err_t err)
{
  err_t ret_err;
  unsigned index;
  struct modbus_tcp_server_s *es;
  struct ip_addr allow_ip;

  LWIP_UNUSED_ARG(arg);
  LWIP_UNUSED_ARG(err);

  /// FIXME Check allowed IPs
  for(index = 0; (ret_err = config_get_allow_ip(&allow_ip, index)) != 0; index++) {
      if(newpcb->remote_ip.addr == allow_ip.addr)
        break;
      if(ip_addr_isbroadcast(&allow_ip, &eth0))
          break;
  }
  if(ret_err == 0)
    return ERR_ABRT;

  /* set priority for the newly accepted tcp connection newpcb */
  tcp_setprio(newpcb, TCP_PRIO_MIN);

  /* allocate structure es to maintain tcp connection informations */
  es = (struct modbus_tcp_server_s *)mem_malloc(sizeof(struct modbus_tcp_server_s));
  if (es != NULL)
  {

    es->state = ES_ACCEPTED;
    es->pcb = newpcb;
    es->p_rx = NULL;
    es->p_tx = NULL;

    /* pass newly allocated es structure as argument to newpcb */
    tcp_arg(newpcb, es);
    
    /* initialize lwip tcp_recv callback function for newpcb  */ 
    tcp_recv(newpcb, modbus_tcp_server_recv);
    
    /* initialize lwip tcp_err callback function for newpcb  */
    tcp_err(newpcb, modbus_tcp_server_error);
    
    /* initialize lwip tcp_poll callback function for newpcb */
    tcp_poll(newpcb, modbus_tcp_server_poll, 1);
    
    ret_err = ERR_OK;
  }
  else
  {
    /* return memory error */
    ret_err = ERR_MEM;
  }
  return ret_err;  
}


/**
  * @brief  This function is the implementation for tcp_recv LwIP callback
  * @param  arg: pointer on a argument for the tcp_pcb connection
  * @param  tpcb: pointer on the tcp_pcb connection
  * @param  pbuf: pointer on the received pbuf
  * @param  err: error information regarding the received pbuf
  * @retval err_t: error code
  */
static err_t modbus_tcp_server_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err)
{
  struct modbus_tcp_server_s *es;
  err_t ret_err;

  LWIP_ASSERT("arg != NULL",arg != NULL);
  
  es = (struct modbus_tcp_server_s *)arg;
  
  /* if we receive an empty tcp frame from client => close connection */
  if (p == NULL)
  {
    /* remote host closed connection */
    es->state = ES_CLOSING;
    if(es->p_rx == NULL)
    {
       /* we're done sending, close connection */
       modbus_tcp_server_connection_close(tpcb, es);
    }
    else
    {
      /* we're not done yet */
      /* acknowledge received packet */
      tcp_sent(tpcb, modbus_tcp_server_sent);
      
      /* send remaining data*/
      modbus_tcp_process_pbuf(tpcb, es);
    }
    ret_err = ERR_OK;
  }   
  /* else : a non empty frame was received from client but for some reason err != ERR_OK */
  else if(err != ERR_OK)
  {
    /* free received pbuf*/
    if (p != NULL)
    {
      es->p_rx = NULL;
      pbuf_free(p);
    }
    ret_err = err;
  }
  else if(es->state == ES_ACCEPTED)
  {

    /* first data chunk in p_rx->payload */
    es->state = ES_RECEIVED;
    
    /* store reference to incoming pbuf (chain) */
    es->p_rx = p;
    
    /* initialize LwIP tcp_sent callback function */
    tcp_sent(tpcb, modbus_tcp_server_sent);
    /* process input packet */
    modbus_tcp_process_pbuf(tpcb, es);
    ret_err = ERR_OK;
  }
  else if (es->state == ES_RECEIVED)
  {
    /* more data received from client and previous data has been already sent*/
    if(es->p_rx == NULL)
    {
      es->p_rx = p;
      /* process input packet */
      modbus_tcp_process_pbuf(tpcb, es);
    }
    else
    {
      struct pbuf *ptr;

      /* chain pbufs to the end of what we recv'ed previously  */
      ptr = es->p_rx;
      pbuf_chain(ptr,p);
      /* process input packet */
      modbus_tcp_process_pbuf(tpcb, es);
    }
    ret_err = ERR_OK;
  }
  
  /* data received when connection already closed */
  else
  {
    /* Acknowledge data reception */
    tcp_recved(tpcb, p->tot_len);
    /* free pbuf and do nothing */
    es->p_rx = NULL;
    pbuf_free(p);
    ret_err = ERR_OK;
  }
  return ret_err;
}

/**
  * @brief  This function implements the tcp_err callback function (called
  *         when a fatal tcp_connection error occurs. 
  * @param  arg: pointer on argument parameter 
  * @param  err: not used
  * @retval None
  */
static void modbus_tcp_server_error(void *arg, err_t err)
{
  struct modbus_tcp_server_s *es;

  LWIP_UNUSED_ARG(err);

  es = (struct modbus_tcp_server_s *)arg;
  if (es != NULL)
  {
    /*  free es structure */
    mem_free(es);
  }
}

/**
  * @brief  This function implements the tcp_poll LwIP callback function
  * @param  arg: pointer on argument passed to callback
  * @param  tpcb: pointer on the tcp_pcb for the current tcp connection
  * @retval err_t: error code
  */
static err_t modbus_tcp_server_poll(void *arg, struct tcp_pcb *tpcb)
{
  err_t ret_err;
  struct modbus_tcp_server_s *es;

  es = (struct modbus_tcp_server_s *)arg;
  if (es != NULL)
  {
    if (es->p_rx != NULL)
    {
      /* there is a remaining pbuf (chain) , try to send data */
      modbus_tcp_server_send(tpcb, es);
    }
    else
    {
      /* no remaining pbuf (chain)  */
      if(es->state == ES_CLOSING)
      {
        /*  close tcp connection */
        modbus_tcp_server_connection_close(tpcb, es);
      }
    }
    ret_err = ERR_OK;
  }
  else
  {
    /* nothing to be done */
    tcp_abort(tpcb);
    ret_err = ERR_ABRT;
  }
  return ret_err;
}

/**
  * @brief  This function implements the tcp_sent LwIP callback (called when ACK
  *         is received from remote host for sent data) 
  * @param  None
  * @retval None
  */
static err_t modbus_tcp_server_sent(void *arg, struct tcp_pcb *tpcb, u16_t len)
{
  struct modbus_tcp_server_s *es;

  LWIP_UNUSED_ARG(len);

  es = (struct modbus_tcp_server_s *)arg;
  
  if(es->p_tx != NULL)
  {
    /* still got pbufs to send */
    modbus_tcp_server_send(tpcb, es);
  }
  else
  {
    /* if no more data to send and client closed connection*/
    if(es->state == ES_CLOSING)
      modbus_tcp_server_connection_close(tpcb, es);
  }
  return ERR_OK;
}


/**
  * @brief  This function is used to send data for tcp connection
  * @param  tpcb: pointer on the tcp_pcb connection
  * @param  es: pointer on echo_state structure
  * @retval None
  */
static void modbus_tcp_server_send(struct tcp_pcb *tpcb, struct modbus_tcp_server_s *es)
{
  struct pbuf *ptr;
  err_t wr_err = ERR_OK;
 
  while ((wr_err == ERR_OK) &&
         (es->p_tx != NULL) &&
         (es->p_tx->len <= tcp_sndbuf(tpcb)))
  {
    
    /* get pointer on pbuf from es structure */
    ptr = es->p_tx;

    /* enqueue data for transmission */
    wr_err = tcp_write(tpcb, ptr->payload, ptr->len, 1);
    
    if (wr_err == ERR_OK)
    {
      u16_t plen;

      plen = ptr->len;
     
      /* continue with next pbuf in chain (if any) */
      es->p_tx = ptr->next;
      
      if(es->p_tx != NULL)
      {
        /* increment reference count for es->p_rx */
        pbuf_ref(es->p_tx);
      }
      
      /* free pbuf: will free pbufs up to es->p_rx (because es->p_rx has a reference count > 0) */
      pbuf_free(ptr);

   }
   else if(wr_err == ERR_MEM)
   {
      /* we are low on memory, try later / harder, defer to poll */
     es->p_tx = ptr;
   }
   else
   {
     /* other problem ?? */
   }
  }
}

/**
  * @brief  This functions closes the tcp connection
  * @param  tcp_pcb: pointer on the tcp connection
  * @param  es: pointer on echo_state structure
  * @retval None
  */
static void modbus_tcp_server_connection_close(struct tcp_pcb *tpcb, struct modbus_tcp_server_s *es)
{
  
  /* remove all callbacks */
  tcp_arg(tpcb, NULL);
  tcp_sent(tpcb, NULL);
  tcp_recv(tpcb, NULL);
  tcp_err(tpcb, NULL);
  tcp_poll(tpcb, NULL, 0);
  
  /* delete es structure */
  if (es != NULL)
  {
    mem_free(es);
  }  
  
  /* close tcp connection */
  tcp_close(tpcb);
}


static err_t modbus_tcp_process_pbuf(struct tcp_pcb *tpcb, struct modbus_tcp_server_s* es) {
  uint16_t length_rx, length_tx;
  err_t ret_err;

  /* Copy packet from pbuf into the modbus packet */
  ret_err = pbuf_copy_partial(es->p_rx,  &es->modbus_tcp_packet.header, sizeof(es->modbus_tcp_packet.header), 0);

  if(ret_err == sizeof(es->modbus_tcp_packet.header)) {
    length_rx = MODBUS_TCP_MAKE_WORD(es->modbus_tcp_packet.header.length);
    ret_err = pbuf_copy_partial(es->p_rx,  &es->modbus_tcp_packet.packet, length_rx, ret_err);
    if(ret_err == length_rx) {
        if((es->modbus_tcp_packet.packet.address == modbus_address) || (es->modbus_tcp_packet.packet.address == 0)) {
          length_tx = modbus_slave_process_msg(&es->modbus_tcp_packet.packet, &es->modbus_tcp_packet.packet) + 2/* Include unit address and function */;
          es->modbus_tcp_packet.header.length = MODBUS_TCP_MAKE_WORD(length_tx);
          /// FIXME Optimize memory consuming
          es->p_tx = pbuf_alloc(PBUF_RAW, length_tx + sizeof(modbus_tcp_header_t), PBUF_POOL);
          ret_err = pbuf_take(es->p_tx, &es->modbus_tcp_packet, length_tx + sizeof(modbus_tcp_header_t));

          /* send back received data */
          modbus_tcp_server_send(tpcb, es);
        }
        if(es->p_rx->tot_len == (length_rx + sizeof(es->modbus_tcp_packet.header))) {
          tcp_recved(tpcb, es->p_rx->tot_len);
        } else {
            /// FIXME
        }
        pbuf_free(es->p_rx);
        es->p_rx = NULL;
    }

  }
  return ret_err;
}
#endif /* LWIP_TCP */
