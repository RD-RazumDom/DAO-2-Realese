/*
 * web_radio.c
 *
 *  Created on: 22 янв. 2015 г.
 *      Author: Dmitry Rudakov
 */
#include "web_radio.h"


struct tcp_pcb* web_radio_connect(struct ip_addr* dest_ip, uint16_t port, const char* url) {
  struct tcp_pcb* pcb  = tcp_new();

  if(pcb == NULL)
    return pcb;


  return pcb;
}

